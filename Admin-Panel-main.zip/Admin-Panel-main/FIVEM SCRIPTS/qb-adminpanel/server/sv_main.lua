local QBCore = exports['qb-core']:GetCoreObject()
local PanelURL = "https://panel.aidanoh.art"

-------------------------------
-- Server Inital Load thread --
-------------------------------
Citizen.CreateThread(function()
    print("[^2SUCCESS^0] Resource Loaded")

    -- Refreshes table for recent disconenctions (Truncated every restart)
    MySQL.query('TRUNCATE table adminpanel_disconnections')
end)

---------------------------
-- Server Join Deferrals --
---------------------------
AddEventHandler('playerConnecting', function(name, setCallback, deferrals)
    local player = source
    local playerIdentifier = GetPlayerIdentifiers(player)

    deferrals.defer()
    Wait(0)
    deferrals.update(string.format('Hello %s. Loading Player Information', name))

    local License
        for _, v in pairs(playerIdentifier) do if string.find(v, "license") then License = v break end
    end
    
    local Steam
        for _, v in pairs(playerIdentifier) do if string.find(v, "steam") then Steam = v break end
    end

    local Discord
        for _, v in pairs(playerIdentifier) do if string.find(v, "discord") then Discord = v break end
    end

    if not Steam then
        deferrals.done('We could not detect Steam running in the background of your computer. Try launching it and reconnecting.')
    elseif not Discord then
        deferrals.done('We could not detect Discord running in the background of your computer. Try launching it and reconnecting.')
    elseif not License then
        deferrals.done('We could not detect a rockstar license. Try launching the rockstar application.')
    else
        local result = MySQL.Sync.fetchAll('SELECT * FROM adminpanel_players WHERE license = ?', { License })
        if result[1] then
            local id = MySQL.update.await('UPDATE adminpanel_players SET playername = ? WHERE license = ?', { GetPlayerName(player), License })
            local id2 = MySQL.update.await('UPDATE adminpanel_players SET discord = ? WHERE license = ?', { Discord, License })
            local id3 = MySQL.update.await('UPDATE adminpanel_players SET steam = ? WHERE license = ?', { Steam, License })
            PerformHttpRequest(PanelURL.."/checkban.php?license=".. License, function(err, resp, headers)
                local data = json.decode(resp)
                if data.banned == "true" then  
                    deferrals.done('\nERROR: You are banned and cannot connect to the server at this moment. \n Ban ID: '..data.banid..' \n Ban Expires: '..data.banexpires..' \nBanned By: '..data.bannedby..' \nBan Reason: '..data.reason..' ')
                else
                    deferrals.update(string.format('Hello %s. Loading Player Information', name))
                    Wait(1000)
                    deferrals.done()
                end
            end)
        else
            local id = MySQL.insert.await('INSERT into adminpanel_players (license, steam, discord, playername, firstjoin) VALUES (?, ?, ?, ?, ?)',{License, Steam, Discord, GetPlayerName(player), os.time})
            PerformHttpRequest(PanelURL.."/functions/checkban.php?license=".. License, function(err, resp, headers)
                local data = json.decode(resp)
                if data.banned == "true" then  
                    deferrals.done('\nERROR: You are banned and cannot connect to the server at this moment. \n Ban ID: '..data.banid..' \n Ban Expires: '..data.banexpires..' \nBanned By: '..data.bannedby..' \nBan Reason: '..data.reason..' ')
                else
                    deferrals.update(string.format('Hello %s. Loading Player Information', name))
                    Wait(1000)
                    deferrals.done()
                end
            end)
        end
    end
end)


---------------------------
--       Playtime        --
---------------------------

Citizen.CreateThread(function()
    while true do
        Wait(60000)
        for _, playerId in ipairs(GetPlayers()) do
            local License = QBCore.Functions.GetIdentifier(playerId, 'license')
            local name = GetPlayerName(playerId)
            local result = MySQL.Sync.fetchAll('SELECT * FROM adminpanel_players WHERE license = ?', { License })

            if result[1] then 
                for _, v in pairs(result) do
                    local newPlaytime = v.playtime+1 
                    MySQL.update.await('UPDATE adminpanel_players SET playtime = ? WHERE license = ? ', {newPlaytime, License})
                end
            end 
        end 
    end
end)

---------------------------------------
--       Player Disconnection        --
---------------------------------------
AddEventHandler('playerDropped', function(Reason)
	local player = source
    local playerName = GetPlayerName(player)
    local playerLicense = QBCore.Functions.GetIdentifier(player, 'license')

    MySQL.insert.await('INSERT into adminpanel_disconnections (serverid, playername, license, reason) VALUES (?, ?, ?, ?)',{player, playerName, playerLicense, Reason})
end)