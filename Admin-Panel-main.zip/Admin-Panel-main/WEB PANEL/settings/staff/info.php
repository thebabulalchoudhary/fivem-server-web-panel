<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$staffsession = $_GET["staffId"];
$result = $pdo->query("SELECT * FROM adminpanel_staff WHERE ID = '$staffsession'");
foreach($result as $row) 
{
    $staffId = $row["id"];
    $staffname = $row["username"];
    $discord = $row["discord"];
    $rockstar = $row["rockstar"];
    $created = $row["created"];
    $rank = $row["groupid"];
    $pchanges = $row["passwordchanges"];
    $accountisactive = $row["active"];
    $masterstatus = $row["master_account"];

    $active = "";
    switch($row["active"])
    {
        case "1": $active = "ACTIVE"; break;
        case "0": $active = "INACTIVE";break;
    }
}

$result2 = $pdo->query("SELECT * FROM adminpanel_players WHERE license = '$rockstar'");
foreach($result2 as $row2) 
{
    $playtime = $row2["playtime"];

    $d = floor ($playtime / 1440);
    $h = floor (($playtime - $d * 1440) / 60);
    $m = $playtime - ($d * 1440) - ($h * 60);
}

$result3 = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID = '$rank'");
foreach($result3 as $row3) {$staffgroupname = $row3["groupname"];}

$StatResult1 = $pdo->query("SELECT count(*) FROM adminpanel_notes WHERE punished_by='$staffId'"); 
$NotesCreatedStat = $StatResult1->fetchColumn();

$StatResult2 = $pdo->query("SELECT count(*) FROM adminpanel_bans WHERE bannedby='$staffId'"); 
$BansCreatedStat = $StatResult2->fetchColumn();

$StatResult3 = $pdo->query("SELECT count(*) FROM adminpanel_kicks WHERE punishedby='$staffId'"); 
$KicksCreatedStat = $StatResult3->fetchColumn();

if (isset($_POST['submit'])){
    $staffmember = $_GET["staffId"];
    $usernameUpdated = htmlentities($_POST['username']);
    $discordUpdated = htmlentities($_POST['discordid']);
    $rockstarUpdated = htmlentities($_POST['rockstar']);

    $stmt = $pdo->prepare('UPDATE adminpanel_staff SET username = ?, discord = ?, rockstar = ?  WHERE id = ?');
    $stmt->execute([ $usernameUpdated, $discordUpdated, $rockstarUpdated, $staffmember ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = ACCOUNT_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "ACCOUNT UPDATED LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "STAFF ACCOUNT UPDATED",
                "type" => "rich",
                "description" => "**$staffusername** has updated the account username and/or identifiers for **$usernameUpdated**",
                "url" => "$starturl",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Staff ID",
                        "value" => "$staffId",
                        "inline" => true
                    ],
                    [
                        "name" => "Old Username",
                        "value" => "$staffname",
                        "inline" => true
                    ],
                    [
                        "name" => "New Username",
                        "value" => "$usernameUpdated",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/settings/staff/info?staffId=$staffsession");
}

if (isset($_POST['submit_group'])){
    $staffmember = $_GET["staffId"];
    $groupFKUpdated = htmlentities($_POST['group']);

    $stmt = $pdo->prepare('UPDATE adminpanel_staff SET groupid = ? WHERE id = ?');
    $stmt->execute([ $groupFKUpdated, $staffmember ]);

    $result5 = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID = '$groupFKUpdated'");
    foreach($result5 as $row5) {$staffgroupnameupdated = $row5["groupname"];}
    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = ACCOUNT_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "ACCOUNT UPDATED LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "STAFF ACCOUNT UPDATED",
                "type" => "rich",
                "description" => "**$staffusername** has changed the account group for **$staffname**",
                "url" => "$starturl",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Staff ID",
                        "value" => "$staffId",
                        "inline" => true
                    ],
                    [
                        "name" => "Old Group",
                        "value" => "$staffgroupname",
                        "inline" => true
                    ],
                    [
                        "name" => "New Group",
                        "value" => "$staffgroupnameupdated",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/settings/staff/info?staffId=$staffsession");
}

if (isset($_POST['submit_password'])){
    $staffmember = $_GET["staffId"];
    $passwordhtmlentity = $_POST['password'];
    $passwordconfirmhtmlentity = $_POST['confirm_password'];

    if ($passwordhtmlentity == $passwordconfirmhtmlentity) {
        $stmt = $pdo->prepare('UPDATE adminpanel_staff SET password = ? WHERE id = ?');
        $password = password_hash($passwordhtmlentity, PASSWORD_DEFAULT);
        $stmt->execute([ $password, $staffmember ]);

        //Send Discord Webhook
            $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = ACCOUNT_UPDATED_LOGS;
            $hookObject = json_encode([
                "content" => "",
                "username" => "ACCOUNT UPDATED LOGS",
                "avatar_url" => AVATAR_URL,
                "tts" => false,
                "embeds" => [
                    [
                        "title" => "STAFF ACCOUNT UPDATED",
                        "type" => "rich",
                        "description" => "**$staffusername** has changed the password for **$staffname**",
                        "url" => "$starturl",
                        "color" => hexdec( HEX_CODE ),
                    ]
                ]

            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            $ch = curl_init();
            curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
            $response = curl_exec( $ch );curl_close( $ch );
            header("Location: ".PANEL_URL."/settings/staff/info?staffId=$staffsession");
        } 
    else {
        echo "WRONG";
    }
}

if (isset($_POST['submit_status'])){
    $staffmember = $_GET["staffId"];
    $activeaccount = "0";if(isset($_POST['accountStatusH'])){$activeaccount = "1";};

    $stmt = $pdo->prepare('UPDATE adminpanel_staff SET active = ? WHERE id = ?');
    $stmt->execute([ $activeaccount, $staffmember ]);
    
    //Send Discord Webhook
    $activewebhook = "";
    switch($activeaccount)
    {
        case "1": $activewebhook = "ACTIVE"; break;
        case "0": $activewebhook = "INACTIVE";break;
    }
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = ACCOUNT_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "ACCOUNT UPDATED LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "STAFF ACCOUNT UPDATED",
                "type" => "rich",
                "description" => "**$staffusername** has changed the account status for **$staffname**",
                "url" => "$starturl",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Current Status",
                        "value" => "$activewebhook",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/settings/staff/info?staffId=$staffsession");
}

$mygroup = $_SESSION['group'];
$PERMstaffManager = false;
$perm = $pdo->query("SELECT staffmanager FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["staffmanager"] == 1){
        $PERMstaffManager = true;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Staff Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../../assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-id icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Staff Information - <?php echo $staffname; ?>
                                <div class="page-title-subheading">This page shows information about a staff member.
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>View Staff Profile</span>
                        </a>
                    </li>

                    <?php if ($PERMstaffManager) { ?>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>View Audit Log</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Manage Staff Member</span>
                        </a>
                    </li>
                    <?php } ?>
                </ul>

                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">View Staff Profile</a></li>
                    <?php if ($PERMstaffManager) { ?>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">View Audit Log</a></li>
                    <li class="nav-item"><a id="tab-3" data-toggle="tab" href="#tab-content-3" class="nav-link show">Manage Staff Member</a></li>
                    <?php } ?>
                </ul>
                <?php } ?>

            <div class="tab-content">
                <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="card text-center"><div class="card-header">General Information</div>
                            <div class="card-body">
                                <p><b>Staff Name: </b><?php echo $staffname; ?> </p>
                                <p><b>Discord: </b><?php echo $discord; ?> </p>
                                <p><b>Rockstar: </b><?php echo $rockstar; ?> </p>
                                <p><b>Staff Panel Rank: </b><?php echo $staffgroupname; ?></p>
                                <p><b>Staff Account Created: </b><?php echo $created; ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card text-center">
                            <div class="card-header"><?php echo $staffname; ?>'s Characters</div>
                            <div class="card-body">
                                <table class="mb-0 table table-hover">
                                    <thead>
                                        <th>Character Name</th>
                                        <th>Citizen ID</th>
                                        <th>Last Active</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $character = $pdo->query("SELECT * FROM players WHERE license='$rockstar'");
                                            foreach($character as $newrow){
                                                $json = $newrow["charinfo"];
                                                $charactername = json_decode($json);

                                            echo
                                            '<td><a id="accentcolor" href="characterInfo?citizenid=' . $newrow['citizenid'] . '">'. $charactername->{'firstname'}. ' '.$charactername->{'lastname'}. '</td>
                                            <td>'. $newrow['citizenid'] .'</td>
                                            <td>'. $newrow['last_updated'] .'</td>
                                            </tr>';
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card text-center">
                            <div class="card-header">Statistics</div>
                                    <div class="card-body">
                                    <p><b>Playtime: </b><?php echo $d; ?> Days, <?php echo $h; ?> Hours, <?php echo $m; ?> Minutes</p>
                                    <p><b>Created Notes: </b><?php echo $NotesCreatedStat; ?> </p>
                                    <p><b>Kicks Submitted: </b><?php echo $KicksCreatedStat; ?> </p>
                                    <p><b>Bans Submitted: </b> <?php echo $BansCreatedStat; ?>  </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title">Audit Log</div>
                                    <table id="basic-datatable" class="table dt-responsive table-hover nowrap">
                                        <thead>
                                            <tr>
                                                <th><b>#</b></th>
                                                <th>Time</th>
                                                <th>Type</th>
                                                <th>Audit Log</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $auditlog = $pdo->query("SELECT * FROM adminpanel_auditlogs WHERE staffid ='$staffId' ORDER BY time");
                                            foreach($auditlog as $newrow){
                                                $auditid = $newrow["id"];
                                                $time = $newrow["time"];
                                                $timestamp = gmdate("Y-m-d H:i:s", $time);
                                                $target = $newrow["target"];
                                                $data = $newrow["data"]; $data2 = $newrow["data2"];
                                                $type = $newrow["type"];
                                                switch($type)
                                                {
                                                    case "inventory_wipe": $typelabel = "Character Inventory Wipe"; break;
                                                    case "change_bank": $typelabel = "Character Bank"; break;
                                                    case "change_name": $typelabel = "Character Name"; break;
                                                    case "change_number": $typelabel = "Character Number"; break;
                                                    case "ban": $typelabel = "Player Ban"; break;
                                                    case "kick": $typelabel = "Player Kick"; break;
                                                    case "note": $typelabel = "Player Note"; break;
                                                    case "vehicle_change_garage": $typelabel = "Vehicle Garage"; break;
                                                    case "vehicle_change_plates": $typelabel = "Vehicle License Plates"; break;
                                                    case "property_changetier": $typelabel = "Property Tier"; break;
                                                }

                                                $staffid = $newrow["staffid"];
                                                $staffsearch = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$staffid'");
                                                foreach($staffsearch as $newrow2){
                                                    $staffusername = $newrow2["username"];
                                                }

                                                if($type == "inventory_wipe"){
                                                    $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                                    foreach($charactername as $character){
                                                        $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                        $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                        $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> inventory was wiped by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "change_bank") {
                                                    $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                                    foreach($charactername as $character){
                                                        $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                        $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                        $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> bank amounts were changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "change_name") {
                                                    $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                                    foreach($charactername as $character){
                                                        $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                        $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                        $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> character name was changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "change_number") {
                                                    $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                                    foreach($charactername as $character){
                                                        $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                        $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                        $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> phone number was changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "ban") {
                                                    $player = $pdo->query("SELECT playername FROM adminpanel_players WHERE id='$target'");
                                                    foreach($player as $playerow){
                                                        $playername = $playerow["playername"];
                                                        $auditlogformatted = "<a href=".PANEL_URL."/players/info?playerId=".$target.">".$playername."</a> was banned by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "kick") {
                                                    $player = $pdo->query("SELECT playername FROM adminpanel_players WHERE id='$target'");
                                                    foreach($player as $playerow){
                                                        $playername = $playerow["playername"];
                                                        $auditlogformatted = "<a href=".PANEL_URL."/players/info?playerId=".$target.">".$playername."</a> was kicked from the server by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "note") {
                                                    $player = $pdo->query("SELECT playername FROM adminpanel_players WHERE id='$target'");
                                                    foreach($player as $playerow){
                                                        $playername = $playerow["playername"];
                                                        $auditlogformatted = "<a href=".PANEL_URL."/players/info?playerId=".$target.">".$playername."</a> has had a note made on profile by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "vehicle_change_garage") {
                                                    $vehicle = $pdo->query("SELECT * FROM player_vehicles WHERE id='$target'");
                                                    foreach($vehicle as $vehiclerow){
                                                        $vehicleplate = $vehiclerow["plate"];
                                                        $auditlogformatted = "Vehicle with plate <a href=".PANEL_URL."/vehicles/info?id=".$target.">".$vehicleplate."</a> garage has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "vehicle_change_plates") {
                                                    $vehicle = $pdo->query("SELECT * FROM player_vehicles WHERE id='$target'");
                                                    foreach($vehicle as $vehiclerow){
                                                        $vehicleplate = $vehiclerow["plate"];
                                                        $auditlogformatted = "Vehicle with plate <a href=".PANEL_URL."/vehicles/info?id=".$target.">".$vehicleplate."</a> license plates has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } elseif ($type == "property_changetier") {
                                                    $property = $pdo->query("SELECT label FROM houselocations WHERE id='$target'");
                                                    foreach($property as $propertyrow){
                                                        $propertylabel = $propertyrow["label"];
                                                        $auditlogformatted = "Property <a href=".PANEL_URL."/properties/info?propertyId=".$target.">".$propertylabel."</a> tier has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                                    }
                                                } else {
                                                    $auditlogformatted = "N/A";
                                                    $button = "";
                                                }

                                            echo 
                                            '<tr">
                                                <td><b>'. $auditid .'</b></td>
                                                <td>'. $timestamp .'</td>
                                                <td>'. $typelabel .'</td>
                                                <td>'. $auditlogformatted .'</td>
                                            </tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                if ($masterstatus == "1") { ?>
                    <div class="tab-pane tabs-animation fade" id="tab-content-3" role="tabpanel">
                        <p>You cannot manage this account as it is the master account.</p>
                    </div>
                <?php
                } else { ?>
                <div class="tab-pane tabs-animation fade" id="tab-content-3" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="card text-center">
                                <div class="card-header">Account Status</div>
                                    <div class="card-body">
                                        <p><b>Staff Name: </b><?php echo $staffname; ?> </p>
                                        <p><b>Discord: </b><?php echo $discord; ?> </p>
                                        <p><b>Rockstar: </b><?php echo $rockstar; ?> </p>
                                        <p><b>Active Status: </b><?php echo $active; ?> </p>
                                        <p><b>Password Changes: </b><?php echo $pchanges; ?> </p>
                                        <p><b>Account Created: </b><?php echo $created; ?> </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card text-center">
                                <div class="card-header">Change Account Status</div>
                                    <div class="card-body">
                                        <p>If a staff member no longer required access to the panel, <b>do not delete their account</b>. You will deactivate the account on this page here. You can reactivate an account on this page aswell.</p>
                                        <p><b>Active Status: </b><?php echo $active; ?> </p>
                                        <a href="" button data-toggle="modal" data-target="#accountStatus" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE ACCOUNT STATUS</a></button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Manage Account</div>
                                        <div class="card-body">
                                        <a href="" button data-toggle="modal" data-target="#namePassword" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE USERNAME / IDENTIFIERS</a></button>
                                        <a href="" button data-toggle="modal" data-target="#changeGroup" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE GROUP</a></button>
                                        <a href="" button data-toggle="modal" data-target="#changePassword" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE PASSWORD</a></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } include "../../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>
<script type="text/javascript" src="../../assets/scripts/main.js"></script>
</body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
</html>

<!-- Change Username/Password Modal -->
<div class="modal fade" id="namePassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Manage Staff Member</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post">
                <div class="alert alert-warning fade show" role="alert"><strong>Please Note:</strong> Make sure to check the group is the correct group you want the user to have!</div>
                
                <!-- USERNAME -->
                <h5 class="card-title">General Information</h5>
                <div class="position-relative row form-group"><label for="username" class="col-sm-2 col-form-label">Username</label>
                    <div class="col-sm-10"><input name="username" id="username" value="<?php echo $staffname; ?>" class="form-control"></div>
                </div>

                <!-- STAFF IDENTIFIERS -->
                <h5 class="card-title">Staff Identifiers</h5>
                <div class="position-relative row form-group"><label for="discordid" class="col-sm-2 col-form-label">Discord</label>
                    <div class="col-sm-10"><input name="discordid" id="discordid" class="form-control" value="<?php echo $discord; ?>"></div>
                </div>
                <div class="position-relative row form-group"><label for="rockstar" class="col-sm-2 col-form-label">Rockstar</label>
                    <div class="col-sm-10"><input name="rockstar" id="rockstar" class="form-control" value="<?php echo $rockstar; ?>"></div>
                </div>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit" value="Submit" class="btn btn-primary">Update Information</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Change Group Modal -->
<div class="modal fade" id="changeGroup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Staff Member Group</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post">
        
                <!-- STAFF GROUP DROPDOWN -->
                <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Group</label>
                    <div class="col-sm-10">
                        <select name="group"class="form-control">
                            <?php  
                                $group = $pdo->query("SELECT * FROM adminpanel_groups");
                                foreach($group as $newrow){
                            ?>
                            <option value="<?php echo$newrow['id'] ?>"><?php echo $newrow['groupname'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit_group" value="Submit" class="btn btn-primary">Update Group</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Staff Member Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post">
        
                <div class="position-relative row form-group"><label for="password" class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10"><input name="password" id="password" value="" class="form-control"></div>
                </div>
                <div class="position-relative row form-group"><label for="confirm_password" class="col-sm-2 col-form-label">Confirm Password</label>
                    <div class="col-sm-10"><input name="confirm_password" id="confirm_password" value="" class="form-control"></div>
                </div>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit_password" value="Submit" class="btn btn-primary">Update Password</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Account Status -->
<div class="modal fade" id="accountStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Account Status</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post">
        
                <div class="custom-checkbox custom-control"><input <?php if ($accountisactive == 1) {echo "checked";}?> name="accountStatusH" type="checkbox" id="accountStatusH" class="custom-control-input">
                    <label class="custom-control-label" for="accountStatusH"><h6>Account Active</label>
                </div>
                <br>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit_status" value="Submit" class="btn btn-primary">Update Account Status</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>