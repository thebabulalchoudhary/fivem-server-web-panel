<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$panelurl = PANEL_URL;
$mygroup = $_SESSION['group'];
$navperms = $pdo->query("SELECT staffmanager FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($navperms as $row){
    if ($row["staffmanager"] == 0){
        header("Location: $panelurl/dashboard");
    }
}

$PERMcreateStaffAccounts = false;
$perm2 = $pdo->query("SELECT createstaffaccounts FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm2 as $row){
    if ($row['createstaffaccounts'] == 1){
    $PERMcreateStaffAccounts = true;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Staff Manager</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../../assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-shield icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Staff Manager 
                                <div class="page-title-subheading">On this page you can view all active/inactive staff members, direct your self to a staff profile or make a new staff account
                            </div>
                        </div>
                    </div>
                    <div class="page-title-actions">
                        <button type="button" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="mb-2 mr-2 dropdown-toggle btn btn-lg btn-outline-primary">
                            Staff Manager
                        </button>
                        <div href="" tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(64px, 37px, 0px);">
                            <button href="" button data-toggle="modal" data-target="#createAccount"type="button" tabindex="0" class="dropdown-item">Create Staff Account</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="alert alert-warning fade show" role="alert">Please Note: Do not delete staff member accounts (This includes directly from the database). If you wish to revoke someone's permission to the panel, deactivate their account on their staff profile page. De-activating a staff account will stop them from being able to login to the panel</div>
            <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>Active Staff Accounts</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Inactive Staff Accounts</span>
                        </a>
                    </li>
                </ul>
                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">Active Staff Accounts</a></li>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">Inactive Staff Accounts</a></li>
                </ul>
                <?php } ?>

            <div class="tab-content">
                <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                <div class="main-card mb-3 card">
                        <div class="card-body">
                            <table class="mb-0 table table-hover">
                                <thead>
                                    <tr>
                                        <th>Staff ID</th>
                                        <th>Staff Name</th>
                                        <th>License (Rockstar License)</th>
                                        <th>Discord ID</th>
                                        <th>Staff Group</th>
                                        <th>Account Created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $uniqueuser = $pdo->query("SELECT * FROM adminpanel_staff WHERE active='1'");
                                        foreach($uniqueuser as $newrow){
                                            $groupid = $newrow['groupid'];
                                            $avatar = $newrow["avatar"];

                                        $uniqueuser2 = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID='$groupid'");
                                        foreach($uniqueuser2 as $row) {
                                            $groupname = $row["groupname"];
                                        }
                                        
                                        echo 
                                        '<td>'. $newrow['id'] .'</td>
                                        <td><img width="26" class="rounded-circle mr-1" src="'.PANEL_URL.'/assets/images/avatars/'.$avatar.'"><a id="accentcolor" href="'.PANEL_URL.'/settings/staff/info?staffId=' . $newrow['id'] . '">'. $newrow['username'].'</td>
                                        <td>'. $newrow['rockstar'] .'</td>
                                        <td>'. $newrow['discord'] .'</td>
                                        <td>'. $groupname .'</td>
                                        <td>'. $newrow['created'] .'</td>
                                        </tr>';
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                    <div class="main-card mb-3 card">
                        <div class="card-body"> 
                            <table class="mb-0 table table-hover">
                                <thead>
                                    <tr>
                                        <th>Staff ID</th>
                                        <th>Staff Name</th>
                                        <th>License (Rockstar License)</th>
                                        <th>Discord ID</th>
                                        <th>Staff Group</th>
                                        <th>Account Created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $uniqueuser = $pdo->query("SELECT * FROM adminpanel_staff WHERE active='0'");
                                        foreach($uniqueuser as $newrow){
                                            $groupid = $newrow['groupid'];
                                            $avatar = $newrow['avatar'];

                                        $uniqueuser2 = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID='$groupid'");
                                        foreach($uniqueuser2 as $row) {
                                            $groupname = $row["groupname"];
                                        }
                                        
                                        echo 
                                        '<td>'. $newrow['id'] .'</td>
                                        <td><img width="26" class="rounded-circle mr-1" src="'.PANEL_URL.'/assets/images/avatars/'.$avatar.'"><a id="accentcolor" href="'.PANEL_URL.'/settings/staff/info?staffId=' . $newrow['id'] . '">'. $newrow['username'].'</td>
                                        <td>'. $newrow['rockstar'] .'</td>
                                        <td>'. $newrow['discord'] .'</td>
                                        <td>'. $groupname .'</td>
                                        <td>'. $newrow['created'] .'</td>
                                        </tr>';
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php include "../../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>
<script type="text/javascript" src="../../assets/scripts/main.js"></script>
</body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
</html>
<!-------------------------->
<!-- Create Account Modal -->
<!-------------------------->
<div class="modal fade" id="createAccount" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Staff Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <?php
                if ($PERMcreateStaffAccounts == "true") { ?>
                <div class="createAccount">
                    <form class="" action="<?php echo PANEL_URL?>/functions/forms/staff_createaccount.php" method="post">

                        <!-- USERNAME -->
                        <div class="position-relative row form-group"><label for="username" class="col-sm-2 col-form-label">Username</label>
                            <div class="col-sm-10"><input name="username" id="username" class="form-control"></div>
                        </div>

                        <!-- PASSWORD -->
                        <div class="position-relative row form-group"><label for="password" class="col-sm-2 col-form-label">Password</label>
                            <div class="col-sm-10"><input name="password" type="password" class="form-control"></div>
                        </div>

                        <!-- STAFF GROUP DROPDOWN -->
                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Group</label>
                            <div class="col-sm-10">
                                <select name="group"class="form-control">
                                    <?php  
                                        $group = $pdo->query("SELECT * FROM adminpanel_groups");
                                        foreach($group as $newrow){
                                    ?>
                                    <option value="<?php echo$newrow['id'] ?>"><?php echo$newrow['groupname'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <!-- STAFF IDENTIFIERS -->
                        <h5 class="card-title">Staff Identifiers</h5>
                        <div class="position-relative row form-group"><label for="discordid" class="col-sm-2 col-form-label">Discord</label>
                            <div class="col-sm-10"><input name="discordid" id="discordid" class="form-control" value="discord:"></div>
                        </div>
                        <div class="position-relative row form-group"><label for="rockstar" class="col-sm-2 col-form-label">Rockstar</label>
                            <div class="col-sm-10"><input name="rockstar" id="rockstar" class="form-control" value="license:"></div>
                        </div>

                        <!-- SUBMIT BUTTON -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Create New Account</button></div>
                        </div>
                    </form>
                </div>
                <?php
                } else { ?>
                    <p>You do not have permission to create new staff accounts.</p>
                <?php }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".createAccount form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".createAccount form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".createAccount form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/staffManager";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>