<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$panelurl = PANEL_URL;
$mygroup = $_SESSION['group'];
$navperms = $pdo->query("SELECT groupmanager FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($navperms as $row){
    if ($row["groupmanager"] == 0){
        header("Location: $panelurl/dashboard");
    }
}

if (isset($_POST['submitgroup'])){
    $groupNameCreated = htmlentities($_POST['group_name']);
    $pdo->query("INSERT INTO adminpanel_groups SET groupname = '$groupNameCreated'");

    // Send Discord Web Hook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = GROUP_CHANGE_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "GROUP CHANGE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "STAFF GROUP CREATED",
                "type" => "rich",
                "description" => "**$staffusername** has created a new staff group with the name **$groupNameCreated**",
                "url" => "$starturl",
                "color" => hexdec( HEX_CODE )
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/staffGroups");
}


$PERMcreateStaffGroups = false;
$perm2 = $pdo->query("SELECT createstaffgroups FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm2 as $row){
    if ($row["createstaffgroups"] == 1){
        $PERMcreateStaffGroups = true;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Staff Groups</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../../assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-id icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Staff Groups
                                <div class="page-title-subheading">This page shows every staff group and the permissions they have.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                    <a href="" button data-toggle="modal" data-target="#createGroup" button class="mb-2 mr-2 btn-transition btn btn-outline-primary">CREATE NEW GROUP</a></button><br>
                    <br><div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="main-card mb-3 card"><div class="card-header">Manage Staff Groups</div>
                            <div class="card-body">
                                <table class="mb-0 table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Group ID</th>
                                            <th>Group Name</th>
                                            <th>Edit Permissions/Group Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $uniqueuser = $pdo->query("SELECT * FROM adminpanel_groups");
                                            foreach($uniqueuser as $newrow){
                                            
                                            echo 
                                            '<td>'. $newrow['id'] .'</td>
                                            <td>'. $newrow['groupname'] .'</td>
                                            <td> <div class="widget-content-left">
                                            <a href="'.PANEL_URL.'/settings/groups/info?groupId='.$newrow['id'].'"><button class="mb-2 mr-2 btn-transition btn btn-outline-primary">Edit '. $newrow['groupname'] .' Group</button></a></div></td>
                                            </tr>';
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php 
            include "../../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>

<script type="text/javascript" src="../../assets/scripts/main.js"></script>
</body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
</html>

<!---------------------->
<!-- Create new group -->
<!---------------------->
<div class="modal fade" id="createGroup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create New Group</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                    if ($PERMcreateStaffGroups) { ?>
                        <form class="" method="post" action="#">

                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Name</label>
                                <div class="col-sm-10"><input class="form-control" name="group_name"></div>
                            </div>

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" name="submitgroup" value="submitName" class="btn btn-primary">Create New Group</button></div>
                            </div>
                        </form>
                    <?php
                    } else { ?>
                        <p>You do not have permission to create new groups.</p>
                    <?php }
                ?>
            </div>
        </div>
    </div>
</div>