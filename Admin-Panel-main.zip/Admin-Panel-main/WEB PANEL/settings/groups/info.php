<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$group = $_GET["groupId"];
$result = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID='$group'");
foreach($result as $row) 
{
    $groupname = $row["groupname"];

    /* PERMISSIONS BELOW */
    $editPhoneNumber = $row["phonenumber"];
    $editBankAmounts = $row["bankamounts"];
    $editVehiclePlate = $row["licenseplates"];
    $editParkedGarage = $row["parkedgarage"];
    $createNotes = $row["createnote"];
    $createKicks = $row["submitkick"];
    $banPlayer = $row["submitban"];
    $manageNotes = $row["managenotes"];
    $manageKicks = $row["managekicks"];
    $manageBans = $row["managebans"];
    $staffmanager = $row["staffmanager"];
    $createaccounts = $row["createstaffaccounts"];
    $groupmanager = $row["groupmanager"];
    $creategroups = $row["createstaffgroups"];
    $editCharName = $row["editcharname"];
    $wipeCharInventory = $row["wipeinventory"];
    $vehiclestate = $row["vehiclestate"];
    $propertytier = $row["propertytier"];
    $auditlog = $row["auditlog"];
}

if (isset($_POST['submit'])){
    $group = $_GET["groupId"];
    $editPhoneNumber = 0; if(isset($_POST['editPhoneNumber'])){$editPhoneNumber = 1;};
    $editBankAmounts = 0; if(isset($_POST['editBankAmounts'])){$editBankAmounts = 1;};
    $editVehiclePlate = 0; if(isset($_POST['editVehiclePlate'])){$editVehiclePlate = 1;};
    $editParkedGarage = 0; if(isset($_POST['editParkedGarage'])){$editParkedGarage = 1;};
    $createNotes = 0; if(isset($_POST['createNotes'])){$createNotes = 1;};
    $createKicks = 0; if(isset($_POST['createKicks'])){$createKicks = 1;};
    $banPlayer = 0; if(isset($_POST['banPlayer'])){$banPlayer = 1;};
    $manageNotes = 0; if(isset($_POST['manageNotes'])){$manageNotes = 1;};
    $manageKicks = 0; if(isset($_POST['manageKicks'])){$manageKicks = 1;};
    $manageBans = 0; if(isset($_POST['manageBans'])){$manageBans = 1;};
    $staffmanager = 0; if(isset($_POST['staffmanager'])){$staffmanager = 1;};
    $createaccounts = 0; if(isset($_POST['createaccounts'])){$createaccounts = 1;};
    $groupmanager = 0; if(isset($_POST['groupmanager'])){$groupmanager = 1;};
    $creategroups = 0; if(isset($_POST['creategroups'])){$creategroups = 1;};
    $editCharName = 0; if(isset($_POST['editCharName'])){$editCharName = 1;};
    $wipeCharInventory = 0; if(isset($_POST['wipeCharInventory'])){$wipeCharInventory = 1;};
    $vehiclestate = 0; if(isset($_POST['vehiclestate'])){$vehiclestate = 1;};
    $propertytier = 0; if(isset($_POST['propertytier'])){$propertytier = 1;};
    $auditlog = 0; if(isset($_POST['auditlog'])){$auditlog = 1;};

    $stmt = $pdo->prepare('UPDATE adminpanel_groups SET phonenumber = ?, bankamounts = ?, licenseplates = ?, parkedgarage = ?, createnote = ?, submitkick = ?, submitban = ?, managenotes = ?, managekicks = ?, managebans = ?, staffmanager = ?, createstaffaccounts = ?, groupmanager = ?, createstaffgroups = ? WHERE id=?');
    $stmt->execute([ $editPhoneNumber, $editBankAmounts, $editVehiclePlate, $editParkedGarage, $createNotes, $createKicks, $banPlayer, $manageNotes, $manageKicks, $manageBans, $staffmanager, $createaccounts, $groupmanager, $creategroups, $group ]);

    $stmt2 = $pdo->prepare('UPDATE adminpanel_groups SET editcharname = ?, wipeinventory = ?, vehiclestate = ?, propertytier = ?, auditlog = ? WHERE id=?');
    $stmt2->execute([ $editCharName, $wipeCharInventory, $vehiclestate, $propertytier, $auditlog, $group ]);


    // Send Discord Web Hook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = GROUP_CHANGE_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "GROUP CHANGE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "STAFF GROUP PERMISSIONS CHANGED",
                "type" => "rich",
                "description" => "**$staffusername** has edited the permissions for the group **$groupname**",
                "url" => "$starturl",
                "color" => hexdec( HEX_CODE )
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/settings/groups/info?groupId=$group");
}

if (isset($_POST['submitname'])){
    $group = $_GET["groupId"];
    $groupNameUpdated = htmlentities($_POST['group_name']);
    $pdo->query("UPDATE adminpanel_groups SET groupname = '$groupNameUpdated' WHERE ID='$group'");

    // Send Discord Web Hook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = GROUP_CHANGE_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "GROUP CHANGE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "STAFF GROUP NAME CHANGED",
                "type" => "rich",
                "description" => "**$staffusername** has edited the group name for **$groupNameUpdated**",
                "url" => "$starturl",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Group ID",
                        "value" => "$group",
                        "inline" => true
                    ],
                    [
                        "name" => "Old Group Name",
                        "value" => "$groupname",
                        "inline" => true
                    ],
                    [
                        "name" => "New Group Name",
                        "value" => "$groupNameUpdated",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/groupInfo?groupId=$group");
}

$mygroup = $_SESSION['group']; $PERMgroupManager = "false"; 
$perm = $pdo->query("SELECT * FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){if ($row['groupmanager'] == "1") {$PERMgroupManager = "true";}else{$PERMgroupManager = "false";}}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Group Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../../assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-menu icon-gradient qb-core">
                                </i>
                            </div>
                            <div>Group Information
                                <div class="page-title-subheading">This page shows all information about any selected group
                                </div>
                            </div>
                        </div>
                        <div class="page-title-actions">
                            <button type="button" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="mb-2 mr-2 dropdown-toggle btn btn-lg btn-outline-primary">
                                Manage <?php echo $groupname; ?> Group
                            </button>
                            <div href="" tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(64px, 37px, 0px);">
                                <button href="" button data-toggle="modal" data-target="#manageName"type="button" tabindex="0" class="dropdown-item">Change Group Name</button>
                                <button href="" button data-toggle="modal" data-target="#viewStaff"type="button" tabindex="0" class="dropdown-item">View Staff In Group</button>
                            </div>
                        </div>
                    </div>
                </div>   

                <?php
                if ($PERMgroupManager == "true") { ?>
                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <form class="" method="post" action="#">
                            <div class="row">   
                                <div class="col-lg-3">
                                    <div class="card">
                                        <div class="card-header">Character Management</div>
                                            <div class="card-body no-padding">
                                                <div class="custom-checkbox custom-control">
                                                    <input <?php if ($editPhoneNumber == 1) {echo "checked";}?> name="editPhoneNumber" type="checkbox" id="editPhoneNumber" class="custom-control-input">
                                                    <label class="custom-control-label" for="editPhoneNumber"><h6>Edit Character Phone Number</label>
                                                </div>

                                                <div class="custom-checkbox custom-control">
                                                    <input <?php if ($editBankAmounts == 1) {echo "checked";}?> name="editBankAmounts" type="checkbox" id="editBankAmounts" class="custom-control-input">
                                                    <label class="custom-control-label" for="editBankAmounts"><h6>Edit Character Bank Amounts</label>
                                                </div>

                                                <div class="custom-checkbox custom-control">
                                                    <input <?php if ($editCharName == 1) {echo "checked";}?> name="editCharName" type="checkbox" id="editCharName" class="custom-control-input">
                                                    <label class="custom-control-label" for="editCharName"><h6>Edit Character Name</label>
                                                </div> 

                                                <div class="custom-checkbox custom-control">
                                                    <input <?php if ($wipeCharInventory == 1) {echo "checked";}?> name="wipeCharInventory" type="checkbox" id="wipeCharInventory" class="custom-control-input">
                                                    <label class="custom-control-label" for="wipeCharInventory"><h6>Wipe Character Inventory</label>
                                                </div>
                                            <br><br><br>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="card">
                                        <div class="card-header">Vehicle Management</div>
                                            <div class="card-body no-padding">
                                                
                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($editVehiclePlate == 1) {echo "checked";}?> name="editVehiclePlate" type="checkbox" id="editVehiclePlate" class="custom-control-input">
                                                <label class="custom-control-label" for="editVehiclePlate"><h6>Edit Vehicle License Plate</label>
                                            </div>
                                            
                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($editParkedGarage == 1) {echo "checked";}?> name="editParkedGarage" type="checkbox" id="editParkedGarage" class="custom-control-input">
                                                <label class="custom-control-label" for="editParkedGarage"><h6>Edit Vehicle Parked Garage</label>
                                            </div>

                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($vehiclestate == 1) {echo "checked";}?> name="vehiclestate" type="checkbox" id="vehiclestate" class="custom-control-input">
                                                <label class="custom-control-label" for="vehiclestate"><h6>Edit Vehicle State</label>
                                            </div>
                                            <br><br><br><br><br>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="card">
                                        <div class="card-header">Punishment Management</div>
                                            <div class="card-body no-padding">
                                                <div class="custom-checkbox custom-control"><input <?php if ($createNotes == 1) {echo "checked";}?> name="createNotes" type="checkbox" id="createNotes" class="custom-control-input">
                                                    <label class="custom-control-label" for="createNotes"><h6>Create New Note</label>
                                                </div>

                                                <div class="custom-checkbox custom-control"><input <?php if ($createKicks == 1) {echo "checked";}?> name="createKicks" type="checkbox" id="createKicks" class="custom-control-input">
                                                    <label class="custom-control-label" for="createKicks"><h6>Submit New Kick</label>
                                                </div>

                                                <div class="custom-checkbox custom-control"><input <?php if ($banPlayer == 1) {echo "checked";}?> name="banPlayer" type="checkbox" id="banPlayer" class="custom-control-input">
                                                    <label class="custom-control-label" for="banPlayer"><h6>Submit New Ban</label>
                                                </div>

                                                <div class="custom-checkbox custom-control"><input <?php if ($manageNotes == 1) {echo "checked";}?> name="manageNotes" type="checkbox" id="manageNotes" class="custom-control-input">
                                                    <label class="custom-control-label" for="manageNotes"><h6>Manage Notes</label>
                                                </div>

                                                <div class="custom-checkbox custom-control"><input <?php if ($manageKicks == 1) {echo "checked";}?> name="manageKicks" type="checkbox" id="manageKicks" class="custom-control-input">
                                                    <label class="custom-control-label" for="manageKicks"><h6>Manage Kicks</label>
                                                </div>

                                                <div class="custom-checkbox custom-control"><input <?php if ($manageBans == 1) {echo "checked";}?> name="manageBans" type="checkbox" id="manageBans" class="custom-control-input">
                                                    <label class="custom-control-label" for="manageBans"><h6>Manage Bans</label>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="card">
                                        <div class="card-header">Property Management</div>
                                            <div class="card-body no-padding">
                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($propertytier == 1) {echo "checked";}?> name="propertytier" type="checkbox" id="propertytier" class="custom-control-input">
                                                <label class="custom-control-label" for="propertytier"><h6>Edit Property Tier</label>
                                            </div>
                                            <br><br><br><br><br><br><br><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="card">
                                        <div class="card-header">Staff & Group Management</div>
                                            <div class="card-body no-padding">
                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($staffmanager == 1) {echo "checked";}?> name="staffmanager" type="checkbox" id="staffmanager" class="custom-control-input">
                                                <label class="custom-control-label" for="staffmanager"><h6>View Staff Audit Logs & Manage Accounts</label>
                                            </div>

                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($createaccounts == 1) {echo "checked";}?> name="createaccounts" type="checkbox" id="createaccounts" class="custom-control-input">
                                                <label class="custom-control-label" for="createaccounts"><h6>Create Staff Accounts</label>
                                            </div>
                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($groupmanager == 1) {echo "checked";}?> name="groupmanager" type="checkbox" id="groupmanager" class="custom-control-input">
                                                <label class="custom-control-label" for="groupmanager"><h6>Access Group Manager</label>
                                            </div>

                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($creategroups == 1) {echo "checked";}?> name="creategroups" type="checkbox" id="creategroups" class="custom-control-input">
                                                <label class="custom-control-label" for="creategroups"><h6>Create Staff Groups</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="card">
                                        <div class="card-header">Other Panel Management</div>
                                            <div class="card-body no-padding">
                                            <div class="custom-checkbox custom-control">
                                                <input <?php if ($auditlog == 1) {echo "checked";}?> name="auditlog" type="checkbox" id="auditlog" class="custom-control-input">
                                                <label class="custom-control-label" for="auditlog"><h6>View Audit Log</label>
                                            </div>

                                            <br><br><br><br><br>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-header text-center"></div>
                                            <div class="card-body text-center no-padding">
                                                
                                            <div><button type="submit" name="submit" value="Submit" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">Update Permissions</button></div>
                                            <br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    <?php } else { ?>
                <p>You do not have permission to view the group manager.</p>
            <?php } include "../../inserts/insert_footer.php"; ?> 
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="../../assets/scripts/main.js"></script>
</body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
</html>

<!-- Manage Name -->
<div class="modal fade" id="manageName" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Group Name</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" action="#">

                <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10"><input class="form-control" name="group_name" value="<?php echo $groupname; ?>"></div>
                    </div>

                    <!-- SUBMIT BUTTON -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <div class="col-sm-10 offset-sm-2"><button type="submit" name="submitname" value="submitName" class="btn btn-primary">Update Name</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!------------------------->
<!-- View Staff In Group -->
<!------------------------->
<div class="modal fade" id="viewStaff" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Staff in <?php echo$groupname;?> Group</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="mb-0 table table-hover">
                    <thead>
                        <tr>
                            <th>Staff ID</th>
                            <th>Staff Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php
                                $staffwithgroup = $pdo->query("SELECT * FROM adminpanel_staff WHERE groupid='$group'");
                                foreach($staffwithgroup as $newrow){
                                echo 
                                '<td>'. $newrow['id'] .'</td>
                                <td><a id="accentcolor" href="staffInfo.php?staffId=' . $newrow['id'] . '">'. $newrow['username'].'</td>
                                </tr>';
                                }
                            ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>