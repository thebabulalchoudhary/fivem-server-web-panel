<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$panelurl = PANEL_URL;
$mygroup = $_SESSION['group'];
$navperms = $pdo->query("SELECT auditlog FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($navperms as $row){
    if ($row["auditlog"] == 0){
        header("Location: $panelurl/dashboard");
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Audit Log</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
    <link href="../assets/libs/datatables/datatables.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-drawer icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Audit Log
                                <div class="page-title-subheading">This page shows the audit log for all staff actions.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title">Audit Log (PREVIOUS <?php echo AUDIT_LOG_NUMBER ?> LOGS)(NEWEST FIRST)</div>
                            <table id="basic-datatable" class="table dt-responsive table-hover nowrap">
                                <thead>
                                    <tr>
                                        <th><b>#</b></th>
                                        <th>Time</th>
                                        <th>Type</th>
                                        <th>Audit Log</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $auditloglimit = AUDIT_LOG_NUMBER;
                                    $auditlog = $pdo->query("SELECT * FROM adminpanel_auditlogs ORDER BY time DESC LIMIT $auditloglimit");
                                    foreach($auditlog as $newrow){
                                        $auditid = $newrow["id"];
                                        $time = $newrow["time"];
                                        $timestamp = gmdate("Y-m-d H:i:s", $time);
                                        $target = $newrow["target"];
                                        $data = $newrow["data"]; $data2 = $newrow["data2"];
                                        $type = $newrow["type"];
                                        switch($type)
                                        {
                                            case "inventory_wipe": $typelabel = "Character Inventory Wipe"; break;
                                            case "change_bank": $typelabel = "Character Bank"; break;
                                            case "change_name": $typelabel = "Character Name"; break;
                                            case "change_number": $typelabel = "Character Number"; break;
                                            case "ban": $typelabel = "Player Ban"; break;
                                            case "kick": $typelabel = "Player Kick"; break;
                                            case "note": $typelabel = "Player Note"; break;
                                            case "vehicle_change_garage": $typelabel = "Vehicle Garage"; break;
                                            case "vehicle_change_plates": $typelabel = "Vehicle License Plates"; break;
                                            case "property_changetier": $typelabel = "Property Tier"; break;
                                            case "vehicle_change_state": $typelabel = "Vehicle State"; break;
                                        }

                                        $staffid = $newrow["staffid"];
                                        $staffsearch = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$staffid'");
                                        foreach($staffsearch as $newrow2){
                                            $staffusername = $newrow2["username"];
                                        }

                                        if($type == "inventory_wipe"){
                                            $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                            foreach($charactername as $character){
                                                $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> inventory was wiped by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "change_bank") {
                                            $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                            foreach($charactername as $character){
                                                $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> bank amounts were changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "change_name") {
                                            $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                            foreach($charactername as $character){
                                                $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> character name was changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "change_number") {
                                            $charactername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$target'");
                                            foreach($charactername as $character){
                                                $charinfo = $character["charinfo"]; $charinfodata = json_decode($charinfo);
                                                $firstname = $charinfodata->{"firstname"}; $lastname = $charinfodata->{"lastname"};
                                                $auditlogformatted = "<a href=".PANEL_URL."/characters/info?citizenid=".$target.">".$firstname." ".$lastname."(".$target.")</a> phone number was changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "ban") {
                                            $player = $pdo->query("SELECT playername FROM adminpanel_players WHERE id='$target'");
                                            foreach($player as $playerow){
                                                $playername = $playerow["playername"];
                                                $auditlogformatted = "<a href=".PANEL_URL."/players/info?playerId=".$target.">".$playername."</a> was banned by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "kick") {
                                            $player = $pdo->query("SELECT playername FROM adminpanel_players WHERE id='$target'");
                                            foreach($player as $playerow){
                                                $playername = $playerow["playername"];
                                                $auditlogformatted = "<a href=".PANEL_URL."/players/info?playerId=".$target.">".$playername."</a> was kicked from the server by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "note") {
                                            $player = $pdo->query("SELECT playername FROM adminpanel_players WHERE id='$target'");
                                            foreach($player as $playerow){
                                                $playername = $playerow["playername"];
                                                $auditlogformatted = "<a href=".PANEL_URL."/players/info?playerId=".$target.">".$playername."</a> has had a note made on profile by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "vehicle_change_garage") {
                                            $vehicle = $pdo->query("SELECT * FROM player_vehicles WHERE id='$target'");
                                            foreach($vehicle as $vehiclerow){
                                                $vehicleplate = $vehiclerow["plate"];
                                                $auditlogformatted = "Vehicle with plate <a href=".PANEL_URL."/vehicles/info?id=".$target.">".$vehicleplate."</a> garage has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "vehicle_change_plates") {
                                            $vehicle = $pdo->query("SELECT * FROM player_vehicles WHERE id='$target'");
                                            foreach($vehicle as $vehiclerow){
                                                $vehicleplate = $vehiclerow["plate"];
                                                $auditlogformatted = "Vehicle with plate <a href=".PANEL_URL."/vehicles/info?id=".$target.">".$vehicleplate."</a> license plates has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "property_changetier") {
                                            $property = $pdo->query("SELECT label FROM houselocations WHERE id='$target'");
                                            foreach($property as $propertyrow){
                                                $propertylabel = $propertyrow["label"];
                                                $auditlogformatted = "Property <a href=".PANEL_URL."/properties/info?propertyId=".$target.">".$propertylabel."</a> tier has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } elseif ($type == "vehicle_change_state") {
                                            $vehicle = $pdo->query("SELECT * FROM player_vehicles WHERE id='$target'");
                                            foreach($vehicle as $vehiclerow){
                                                $vehicleplate = $vehiclerow["plate"];
                                                $auditlogformatted = "Vehicle with plate <a href=".PANEL_URL."/vehicles/info?id=".$target.">".$vehicleplate."</a> state has been changed by <a href=".PANEL_URL."/settings/staff/info?staffId=".$staffid."> $staffusername"; 
                                            }
                                        } else {
                                            $auditlogformatted = "N/A";
                                            $button = "";
                                        }

                                    echo 
                                    '<tr">
                                        <td><b>'. $auditid .'</b></td>
                                        <td>'. $timestamp .'</td>
                                        <td>'. $typelabel .'</td>
                                        <td>'. $auditlogformatted .'</td>
                                    </tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            

            <!-- FOOTER -->
            <?php include "../inserts/insert_footer.php"; ?> 
        </div>
    </div>
    </div>
    <script type="text/javascript" src="../assets/scripts/main.js"></script></body>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/libs/morris-js/morris.min.js"></script>
</html>