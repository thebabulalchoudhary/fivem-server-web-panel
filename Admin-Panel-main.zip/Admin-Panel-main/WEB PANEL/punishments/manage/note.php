<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$noteid = $_GET["noteId"];
$result = $pdo->query("SELECT * FROM adminpanel_notes WHERE noteid='$noteid'");
foreach($result as $row) 
{
    $punishedplayer = $row["punished_player"];
    $punishedby = $row["punished_by"];
    $reason = $row["punish_reason"];
    $timestamp = $row["punished_time"];
}

$result2 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$punishedby'");
foreach($result2 as $row2) {$staffname = $row2["username"];}

$result3 = $pdo->query("SELECT * FROM adminpanel_players WHERE id='$punishedplayer'");
foreach($result3 as $row3) {$punsihedplayer = $row3["playername"];}

if (isset($_POST['submit'])){
    $noteReasonUpdated = htmlentities($_POST['note_reason']);

    $stmt = $pdo->prepare('UPDATE adminpanel_notes SET punish_reason = ?  WHERE noteid = ?');
    $stmt->execute([ $noteReasonUpdated, $noteid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = NOTE_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "NOTE UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "NOTE REASON UPDATED",
                "type" => "rich",
                "description" => "**$staffusername** has updated the note reason on note ID: **$noteid**",
                "url" => "$starturl/manageNote?NoteId=$noteid",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Old Note Reason",
                        "value" => "$reason",
                        "inline" => true
                    ],
                    [
                        "name" => "New Note Reason",
                        "value" => "$noteReasonUpdated",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/manageNote?noteId=$noteid");
}

if (isset($_POST['delete_note'])){
    $stmt = $pdo->prepare('DELETE FROM adminpanel_notes WHERE noteid = ?');
    $stmt->execute([ $noteid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = NOTE_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "NOTE UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "NOTE DELETED",
                "type" => "rich",
                "description" => "**$staffusername** has deleted the note with the note ID: **$noteid**",
                "url" => "$starturl/playerInfo?playerId=$punishedplayer",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Punished Player",
                        "value" => "$punsihedplayer",
                        "inline" => true
                    ],
                    [
                        "name" => "Originally Punished By",
                        "value" => "$staffname",
                        "inline" => true
                    ],
                    [
                        "name" => "Note Issue Date",
                        "value" => "$timestamp",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/noteslist");
}

$panelurl = PANEL_URL;
$mygroup = $_SESSION['group'];
$perm = $pdo->query("SELECT managenotes FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["managenotes"] == 0){
        header("Location: $panelurl/dashboard");
    }
}
?>
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Manage Note</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-menu icon-gradient qb-core">
                                </i>
                            </div>
                            <div>Manage Note
                                <div class="page-title-subheading">On this page, you can manage any note!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>   

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Note Information</div>
                                        <div class="card-body">
                                        <p><b>Note ID: </b><?php echo $noteid; ?> </p>
                                        <p><b>Punished Player: </b><a href="playerInfo?playerId=<?php echo $punishedplayer; ?>"><?php echo $punsihedplayer; ?> </p></a>
                                        <p><b>Punishing Staff Member: <a href="staffInfo?staffId=<?php echo $punishedby; ?>"></b><?php echo $staffname; ?> </p></a>
                                        <p><b>Note Issue Date: </b><?php echo $timestamp; ?> </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">Note Reason</div>
                                        <div class="card-body">
                                        <p><?php echo $reason; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Manage Note</div>
                                        <div class="card-body">
                                        <a href="" button data-toggle="modal" data-target="#changeNoteReason" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE NOTE REASON</a></button>
                                        <a href="" button data-toggle="modal" data-target="#deleteNote" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">DELETE NOTE</a></button>
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            <?php include "../../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>

<script type="text/javascript" src="../../assets/scripts/main.js"></script></body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
<script src="../../assets/libs/morris-js/morris.min.js"></script>
</html>

<!-- Change Note Reason -->
<div class="modal fade" id="changeNoteReason" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Note Reason</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <!-- NOTE REASON -->
                <div class="position-relative form-group"><label for="exampleText" class="">Note Reason</label>
                <textarea name="note_reason" id="exampleText" class="form-control"><?php echo $reason ?></textarea></input></div>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit" value="Submit" class="btn btn-primary">Change Note Reason</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Note -->
<div class="modal fade" id="deleteNote" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete Note</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <p><b>WARNING:</b> Deleting the note will remove it from the player's note history and remove the note from existence. There is no way to revert this action after.</p>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="delete_note" name="delete_note" value="Submit" class="btn btn-primary">Delete Note</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>