<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$banid = $_GET["banId"];
$currentime = time();
$result = $pdo->query("SELECT * FROM adminpanel_bans WHERE banid='$banid'");
foreach($result as $row) 
{
    $reason = $row["reason"];
    $bannedby = $row["bannedby"];
    $bannedplayer = $row["userid"];
    $banissued = $row["ban_issued"];
    $banexpiry = $row["banned_until"];
    $activenumber = $row["active"];
}
$banissuedformatted = gmdate("Y-m-d H:i:s", $banissued);
if ($banexpiry == "0") {
    $banexpiryformatted = "Permenant";
} else {
    $banexpiryformatted = gmdate("Y-m-d H:i:s", $banexpiry);
}

if ($activenumber == "1") {
    if ($banexpiry >= $currentime){
        $activestatus = "Active";
    }
    elseif ($banexpiry == "0") {
        $activestatus = "Active";
      }
    else {
        $activestatus = "Expired";
    }
} 
elseif ($activenumber == "0") {
    $activestatus = "Unbanned";
}

$result2 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$bannedby'");
foreach($result2 as $row2) {$staffname = $row2["username"];}

$result3 = $pdo->query("SELECT * FROM adminpanel_players WHERE id='$bannedplayer'");
foreach($result3 as $row3) {$punsihedplayer = $row3["playername"];}



if (isset($_POST['submit'])){
    $banreasonUpdated = htmlentities($_POST['ban_reason']);

    $stmt = $pdo->prepare('UPDATE adminpanel_bans SET reason = ?  WHERE banid = ?');
    $stmt->execute([ $banreasonUpdated, $banid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = BAN_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "BAN UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "BAN REASON UPDATED",
                "type" => "rich",
                "description" => "**$staffusername** has updated the ban reason on ban ID: **$banid**",
                "url" => "$starturl/manageBan?banId=$banid",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Old Ban Reason",
                        "value" => "$reason",
                        "inline" => true
                    ],
                    [
                        "name" => "New Ban Reason",
                        "value" => "$banreasonUpdated",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/manageBan?banId=$banid");
}

if (isset($_POST['submit_unban'])){
    $stmt = $pdo->prepare('UPDATE adminpanel_bans SET active = ?  WHERE banid = ?');
    $stmt->execute([ "0", $banid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = BAN_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "BAN UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "BAN REVOKED",
                "type" => "rich",
                "description" => "**$staffusername** has revoked the ban with the ban ID: **$banid**",
                "url" => "$starturl/manageBan?banId=$banid",
                "color" => hexdec( HEX_CODE ),
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/manageBan?banId=$banid");
}

if (isset($_POST['submit_expirychange'])){
    if ((htmlentities($_POST['ban_days']) == "0") && (htmlentities($_POST['ban_hours']) == "0")) {
        $banlength = "0";
        $banlengthformatted = "Permenant";
    } else {
        $banDays = htmlspecialchars($_POST['ban_days']) * 86400;
        $banHours = htmlspecialchars($_POST['ban_hours'] * 3600);
        $banlength = time() + $banDays + $banHours;
        $banlengthformatted = gmdate("Y-m-d H:i:s", $banlength);
    }
    $stmt = $pdo->prepare('UPDATE adminpanel_bans SET banned_until = ?  WHERE banid = ?');
    $stmt->execute([ $banlength, $banid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = BAN_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "BAN UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "BAN EXPIRY DATE CHANGED",
                "type" => "rich",
                "description" => "**$staffusername** has updated the ban expiry date on ban ID: **$banid**",
                "url" => "$starturl/manageBan?banId=$banid",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Old Expiry Date",
                        "value" => "$banexpiryformatted",
                        "inline" => true
                    ],
                    [
                        "name" => "New Expiry Date",
                        "value" => "$banlengthformatted",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/manageBan?banId=$banid");
}

if (isset($_POST['delete_ban'])){
    $stmt = $pdo->prepare('DELETE FROM adminpanel_bans WHERE banid = ?');
    $stmt->execute([ $banid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = BAN_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "BAN UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "BAN DELETED",
                "type" => "rich",
                "description" => "**$staffusername** has deleted the ban with the ban ID: **$banid**",
                "url" => "$starturl/playerInfo?playerId=$bannedplayer",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Banned Player",
                        "value" => "$punsihedplayer",
                        "inline" => true
                    ],
                    [
                        "name" => "Originally Banned By",
                        "value" => "$staffname",
                        "inline" => true
                    ],
                    [
                        "name" => "Ban Issue Date",
                        "value" => "$banissuedformatted",
                        "inline" => true
                    ],
                    [
                        "name" => "Ban Expiry Date",
                        "value" => "$banexpiryformatted",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: ".PANEL_URL."/banlist");
}

$panelurl = PANEL_URL;
$mygroup = $_SESSION['group'];
$perm = $pdo->query("SELECT managebans FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["managebans"] == 0){
        header("Location: $panelurl/dashboard");
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Manage Ban</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../../assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-menu icon-gradient qb-core">
                                </i>
                            </div>
                            <div>Manage Ban
                                <div class="page-title-subheading">On this page, you can manage any ban!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>   

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Ban Information</div>
                                        <div class="card-body">
                                        <p><b>Ban ID: </b><?php echo $banid; ?> </p>
                                        <p><b>Banned Player: </b><a href="playerInfo?playerId=<?php echo $bannedplayer; ?>"><?php echo $punsihedplayer; ?> </p></a>
                                        <p><b>Banning Staff Member: <a href="staffInfo?staffId=<?php echo $bannedby; ?>"></b><?php echo $staffname; ?> </p></a>
                                        <p><b>Ban Active Status: </b><?php echo $activestatus; ?> </p>
                                        <p><b>Banning Issue Date: </b><?php echo $banissuedformatted; ?> </p>
                                        <p><b>Banning Expiry Date: </b><?php echo $banexpiryformatted; ?> </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">Ban Reason</div>
                                        <div class="card-body">
                                        <p><?php echo $reason; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Manage Ban</div>
                                        <div class="card-body">
                                        <a href="" button data-toggle="modal" data-target="#unbanPlayer" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">UNBAN/REVOKE BAN</a></button>
                                        <a href="" button data-toggle="modal" data-target="#changeBanReason" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE BAN REASON</a></button>
                                        <a href="" button data-toggle="modal" data-target="#changeBanDuration" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">UPDATE BAN EXPIRY DATE</a></button>
                                        <a href="" button data-toggle="modal" data-target="#deleteBan" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">DELETE BAN</a></button>
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            <?php include "../../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>

<script type="text/javascript" src="../../assets/scripts/main.js"></script></body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
<script src="../../assets/libs/morris-js/morris.min.js"></script>
</html>

<!-- Change Ban Reason -->
<div class="modal fade" id="changeBanReason" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Ban Reason</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <!-- BAN REASON -->
                <div class="position-relative form-group"><label for="exampleText" class="">Ban Reason</label>
                <textarea name="ban_reason" id="exampleText" class="form-control"><?php echo $reason ?></textarea></input></div>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit" value="Submit" class="btn btn-primary">Change Ban Reason</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Unban Player -->
<div class="modal fade" id="unbanPlayer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Unban Player</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <?php
                if ($activenumber == "1") { ?>
                    <p>Are you sure you want to revoke this ban? This means that the player will be able to reconnect to the server.</p>

                    <!-- SUBMIT BUTTON -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit_unban" value="Submit" class="btn btn-primary">Unban Player</button></div>
                    </div>
                <?php
                } else { ?>
                    <p>This player has already been unbanned meaning you cannot proceed with this action. If you want to re-instate this ban, create a new ban.</p>
                <?php
                }
                ?>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Change Ban Duration -->
<div class="modal fade" id="changeBanDuration" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Ban Duration</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <?php

                if ($activestatus == "Active") { ?>
                    <p>This ban is currently active and can have the expiry date changed.</p>

                    <h5 class="card-title">BAN LENGTH</h5>
                    <h5 class="card-subtitle">If you want to permenantly ban the user, leave days and hours as 0</h5>
                    
                    <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Days</label>
                        <div class="col-sm-10"><input class="form-control" name="ban_days" type="number" required="text" placeholder="How many days do you want to ban the user for?"></div>
                    </div>

                    <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Hours</label>
                        <div class="col-sm-10"><input class="form-control" name="ban_hours" type="number" required="text" placeholder="How many hours would you like to add?"></div>
                    </div>

                    <!-- SUBMIT BUTTON -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit_expirychange" value="Submit" class="btn btn-primary">Update Expiry Date</button></div>
                    </div>
                <?php
                } 
                elseif ($activestatus == "Expired") { ?>
                    <p>This ban has already expired. This means you will have to create a new ban if you wish to update the expiry date.</p>
                <?php
                } else {
                ?>
                    <p>This ban has already been revoked/Someone has already revoked/unbanned the player. This means you will have to create a new ban if you wish to update the expiry date.</p>
                <?php }?>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Ban -->
<div class="modal fade" id="deleteBan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete Ban</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <p><b>WARNING:</b> Deleting the ban will remove it from the player's ban history and remove the ban from existence. There is no way to revert this action after.</p>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="delete_ban" name="delete_ban" value="Submit" class="btn btn-primary">Delete Ban</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>