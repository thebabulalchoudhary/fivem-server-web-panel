<?php
include '../../config/config.php';
include '../../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$kickid = $_GET["kickId"];
$result = $pdo->query("SELECT * FROM adminpanel_kicks WHERE ID='$kickid'");
foreach($result as $row) 
{
    $kicked_player_id = $row['kicked_player'];
    $punishedbyid = $row['punishedby'];
    $reason = $row["kickreason"];
    $timestamp = $row["timestamp"];
}

$result2 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$punishedbyid'");
foreach($result2 as $row2) {$punishingstaffmember = $row2["username"];}

$result3 = $pdo->query("SELECT * FROM adminpanel_players WHERE id='$kicked_player_id'");
foreach($result3 as $row3) {$playerpunishedusername = $row3["playername"];}

if (isset($_POST['submit'])){
    $kickReasonUpdated = htmlentities($_POST['kick_reason']);

    $stmt = $pdo->prepare('UPDATE adminpanel_kicks SET kickreason = ?  WHERE ID = ?');
    $stmt->execute([ $kickReasonUpdated, $kickid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = KICK_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "KICk UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "KICK REASON UPDATED",
                "type" => "rich",
                "description" => "**$staffusername** has updated the kick reason on kick ID: **$kickid**",
                "url" => "$starturl/manageKick?kickId=$kickid",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Old Kick Reason",
                        "value" => "$reason",
                        "inline" => true
                    ],
                    [
                        "name" => "New Kick Reason",
                        "value" => "$kickReasonUpdated",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: /manageKick?kickId=$kickid");
}

if (isset($_POST['delete_kick'])){
    $stmt = $pdo->prepare('DELETE FROM adminpanel_kicks WHERE ID = ?');
    $stmt->execute([ $kickid ]);

    //Send Discord Webhook
    $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = KICK_UPDATED_LOGS;
    $hookObject = json_encode([
        "content" => "",
        "username" => "KICK UPDATE LOGS",
        "avatar_url" => AVATAR_URL,
        "tts" => false,
        "embeds" => [
            [
                "title" => "KICK DELETED",
                "type" => "rich",
                "description" => "**$staffusername** has deleted the kick with the kick ID: **$kickid**",
                "url" => "$starturl/manageKick?kickId=$kickid",
                "color" => hexdec( HEX_CODE ),
                "fields" => [
                    [
                        "name" => "Punished Player",
                        "value" => "$playerpunishedusername",
                        "inline" => true
                    ],
                    [
                        "name" => "Originally Punished By",
                        "value" => "$punishingstaffmember",
                        "inline" => true
                    ],
                    [
                        "name" => "Issue Date",
                        "value" => "$timestamp",
                        "inline" => true
                    ],
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    $ch = curl_init();
    curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
    $response = curl_exec( $ch );curl_close( $ch );
    header("Location: /kicklist");
}

$panelurl = PANEL_URL;
$mygroup = $_SESSION['group'];
$perm = $pdo->query("SELECT managekicks FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["managekicks"] == 0){
        header("Location: $panelurl/dashboard");
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Manage Kick</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-menu icon-gradient qb-core">
                                </i>
                            </div>
                            <div>Manage Kick
                                <div class="page-title-subheading">On this page, you can manage any kick!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>   

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Kick Information</div>
                                        <div class="card-body">
                                        <p><b>Kick ID: </b><?php echo $kickid; ?> </p>
                                        <p><b>Punished Player: </b><a href="playerInfo?playerId=<?php echo $kicked_player_id; ?>"><?php echo $playerpunishedusername; ?> </p></a>
                                        <p><b>Punishing Staff Member: <a href="staffInfo?staffId=<?php echo $punishedbyid; ?>"></b><?php echo $punishingstaffmember; ?> </p></a>
                                        <p><b>Issue Date: </b><?php echo $timestamp; ?> </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">Kick Reason</div>
                                        <div class="card-body">
                                        <p><?php echo $reason; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Manage Note</div>
                                        <div class="card-body">
                                        <a href="" button data-toggle="modal" data-target="#changeKickReason" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE KICK REASON</a></button>
                                        <a href="" button data-toggle="modal" data-target="#deleteKick" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">DELETE KICk</a></button>
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            <?php include "../../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>

<script type="text/javascript" src="../../assets/scripts/main.js"></script></body>
<script src="../../assets/js/vendor.min.js"></script>
<script src="../../assets/js/app.min.js"></script>
<script src="../../assets/libs/morris-js/morris.min.js"></script>
</html>

<!-- Change Kick Reason -->
<div class="modal fade" id="changeKickReason" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Kick Reason</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <!-- KICK REASON -->
                <div class="position-relative form-group"><label for="exampleText" class="">Kick Reason</label>
                <textarea name="kick_reason" id="exampleText" class="form-control"><?php echo $reason ?></textarea></input></div>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit" value="Submit" class="btn btn-primary">Change Kick Reason</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete kick -->
<div class="modal fade" id="deleteKick" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete Kick</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post" autocomplete="off">

                <p><b>WARNING:</b> Deleting the kick will remove it from the player's kick history and remove the kick from existence. There is no way to revert this action after.</p>

                <!-- SUBMIT BUTTON -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <div class="col-sm-10 offset-sm-2"><button type="delete_kick" name="delete_kick" value="Submit" class="btn btn-primary">Delete kick</button></div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>