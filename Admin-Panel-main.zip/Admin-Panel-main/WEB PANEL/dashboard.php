<?php
include 'config/config.php';
include 'functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$result = $pdo->query("SELECT count(*) FROM players"); 
$Stat1 = $result->fetchColumn();

$result2 = $pdo->query("SELECT count(*) FROM adminpanel_players"); 
$Stat2 = $result2->fetchColumn();

$json = file_get_contents('http://'.SERVER_IP.':'.SERVER_PORT.'/players.json');
$data = json_decode($json, true);
$Stat3 = 0;
foreach($data as $row){
    $Stat3++;
}

$ssl=array("ssl"=>array("verify_peer"=>false, "verify_peer_name"=>false,),);  
$apiversion = file_get_contents('https://api.iv-studios.net/adminpanel_version.json', false, stream_context_create($ssl));
$panelversion = VERSION;
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Dashboard</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="assets/images/logo-fav.png">
    <link href="assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <!-- 
                    <div class="search-wrapper">
                        <div class="input-holder">
                            <input type="text" class="search-input" placeholder="Search characters or users">
                            <button class="search-icon"><span></span></button>
                        </div>
                        <button class="close"></button>
                    </div>   -->
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "inserts/insert_profile.php"; ?>
            </div>
        </div>
             
        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "inserts/insert_navBar.php"; ?> 

        <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-menu icon-gradient qb-core">
                            </i>
                        </div>
                        <div>Dashboard
                            <div class="page-title-subheading">This dashboard shows all statistics about your server and is the main home page of the admin panel!
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            // Please don't delete me or you wont know when to update :( 
            // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(
            if($apiversion > $panelversion){  // Please don't delete me or you wont know when to update :(
                echo '<li class="list-group-item-danger list-group-item"><b>WARNING:</b> 
                This version of the panel is outdated. You are on v'.$panelversion.' and the latest version is currently v'.$apiversion.'. 
                To resolve this issue please read the Innovative Studios or make a ticket!</li><br>';
            }   // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(
            if($panelversion > $apiversion){  // Please don't delete me or you wont know when to update :(
                echo '<li class="list-group-item-warning list-group-item"><b>WARNING:</b> 
                You are using an experimental version of the admin panel. You may encounter some issues. 
                If you do not think this warning should be displayed please contact Innovative Studios by creating a ticket in the discord!</li><br>';
            }   // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(
            // Please don't delete me or you wont know when to update :(

            ?>

        <div class="row">
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Total Characters</div>
                                <div class="widget-subheading">Number of unique characters created on the server.</div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-numbers text-danger"><?php echo $Stat1; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Total Users</div>
                                <div class="widget-subheading">Number of unique players that have joined the server.</div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-numbers text-danger"><?php echo $Stat2; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Total Online Players</div>
                                <div class="widget-subheading">Total number of players online.</div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-numbers text-danger"><?php echo $Stat3; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 offset-md-3">
            <div class="card text-center">
                <div class="card-header">Punishments</div>
                    <div class="card">
                        <canvas
                            id="myChart" 
                            width="727" 
                            height="363" 
                            style="display: block; width: 727px; height: 363px;" 
                            class="chartjs-render-monitor">
                        </canvas>
                    </div>
                </div>
            </div>
        </div>
            <?php include "inserts/insert_footer.php"; ?> 
        </div>
    </div>
</body>
<script type="text/javascript" src="./assets/scripts/main.js"></script>

<?php
$bans = $pdo->query("SELECT count(*) FROM adminpanel_bans"); 
$bansfetch = $bans->fetchColumn();

$kicks = $pdo->query("SELECT count(*) FROM adminpanel_kicks"); 
$kicksfetch = $kicks->fetchColumn();

$notes = $pdo->query("SELECT count(*) FROM adminpanel_notes"); 
$notesfetch = $notes->fetchColumn();
?>
<script>
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Bans', 'Kicks', 'Notes'],
        datasets: [{
            label: 'Punishment Statistics',
            data: [<?php echo $bansfetch ?>, <?php echo $kicksfetch ?>, <?php echo $notesfetch ?>,0],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(255, 99, 132, 1)',
                'rgba(255, 99, 132, 1)',
            ],
            borderWidth: 1
        }]
    },
});
</script>
</html>