<?php
include 'config/config.php';
include 'functions/main.php';
CheckUserLoggedIn($pdo);

if($_SESSION['passwordchanges'] > 0){
    header("Location: ".PANEL_URL."/dashboard");
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Change Password</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="assets/images/logo-fav.png">
    <link href="assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "inserts/insert_profile.php"; ?>
            </div>
        </div>
             
        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "inserts/insert_navBar.php"; ?> 

        <div class="app-main__outer">
        <div class="app-main__inner">
            <br>
            <div class="col-md-5 offset-md-3">
                <div class="card text-center">
                    <div class="card-body">
                        <?php if($_SESSION['name'] == "MasterAccount"){ ?>
                            <h4><b>Change Your Username & Password</b></h4>
                            <p>As this is your first account on the admin panel you want to change the username and password! You cannot access any other page until you do this.</p>
                            <br>
                            <div class="changepass">
                                <form action="functions/forms/changepassword.php" method="post">
                                    <div class="position-relative row form-group"><label for="password" class="col-sm-2 col-form-label">Username</label>
                                        <div class="col-sm-10"><input name="username" type="text" id="username" value="<?php echo $_SESSION['name'] ?>" class="form-control" required></div>
                                    </div>
                                    <div class="position-relative row form-group"><label for="password" class="col-sm-2 col-form-label">Password</label>
                                        <div class="col-sm-10"><input name="password" type="password" id="password" value="" class="form-control" required></div>
                                    </div>
                                    <div class="position-relative row form-group"><label for="confirm_password" class="col-sm-2 col-form-label">Confirm Password</label>
                                        <div class="col-sm-10"><input name="confirm_password" type="password" id="confirm_password" value="" class="form-control" required></div>
                                    </div>

                                    <!-- SUBMIT BUTTON -->
                                    <div class="modal-footer">
                                        <div class="col-sm-12 offset-sm-5">
                                            <button type="submit" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">Change Username & Password</button>
                                        </div>
                                    </div>
                                    <div class="errormessage"></div>
                                </form>
                            </div>
                        <?php } else { ?>
                        <h4><b>Change Your Password</b></h4>
                        <p>Because this is either your first time logging into the Admin panel or you have not changed your password before you are required to change your password before you can access any page. You can do this on the form below!</p>
                        <br>
                        <div class="changepass">
                            <form action="functions/forms/changepassword.php" method="post">
                                <div class="position-relative row form-group"><label for="password" class="col-sm-2 col-form-label">Password</label>
                                    <div class="col-sm-10"><input name="password" type="password" id="password" value="" class="form-control" required></div>
                                </div>
                                <div class="position-relative row form-group"><label for="confirm_password" class="col-sm-2 col-form-label">Confirm Password</label>
                                    <div class="col-sm-10"><input name="confirm_password" type="password" id="confirm_password" value="" class="form-control" required></div>
                                </div>

                                <!-- SUBMIT BUTTON -->
                                <div class="modal-footer">
                                    <div class="col-sm-12 offset-sm-5">
                                        <button type="submit" class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">Change Password</button>
                                    </div>
                                </div>
                                <div class="errormessage"></div>
                            </form>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <!-- FOOTER -->
            <?php include "inserts/insert_footer.php"; ?> 
        </div>
    </div>
    <script type="text/javascript" src="./assets/scripts/main.js"></script>
</body>
<script>
document.querySelector(".changepass form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changepass form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changepass form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/dashboard";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>
</html>