<?php
include 'config/config.php';
include 'functions/main.php';

if (isset($_SESSION['loggedin'])) {
    header('Location: '.PANEL_URL.'/dashboard');
    exit;
} else {
	header('Location: '.PANEL_URL.'/login');
}
?>