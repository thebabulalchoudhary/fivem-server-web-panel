<?php
include 'config/config.php';
include 'functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Recent Disconnections</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="assets/images/logo-fav.png">
    <link href="assets/main.css" rel="stylesheet">
    <link href="assets/libs/datatables/datatables.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-delete-user icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Recent Disconnections
                                <div class="page-title-subheading">This page displays player disconnections on the current restart.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="alert alert-dark fade show" role="alert"><b>Please Note:</b> The Server ID column is the user's id that disconnected from the server.</div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body"><div class="card-title">Recent Disconnections</div>
                            <table id="recentDisconnections" class="display" style="width:100%">
                                <thead>
                                    <th>Server ID</th>
                                    <th>Player Name</th>
                                    <th>License (Rockstar License)</th>
                                    <th>Disconnect Reason</th>
                                </thead>
                                <tbody>
                                <?php
                                    $disconnection = $pdo->query("SELECT * FROM adminpanel_disconnections");
                                    foreach($disconnection as $newrow){
                                        $rockstar = $newrow['license'];

                                    $accountowner = $pdo->query("SELECT * FROM adminpanel_players WHERE license='$rockstar'");
                                    foreach($accountowner as $newrow2){
                                        $accountid = $newrow2['id'];
                                        $user = $newrow2['playername'];
                                    }
                                    
                                    echo 
                                    '<tr>
                                    <td>'. $newrow['serverid'] .'</td>
                                    <td><a href="'.PANEL_URL.'/players/info?playerId=' . $newrow2['id'] . '">'. $newrow2['playername'].'</td>
                                    <td>'. $newrow['license'] .'</td>
                                    <td>'. $newrow['reason'] .'</td>
                                    </tr>';
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- FOOTER -->
            <?php include "inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>

<script type="text/javascript" src="./assets/scripts/main.js"></script></body>
<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/app.min.js"></script>

<script src="assets/libs/datatables/datatables.min.js"></script>
</html>
<script>
    $(document).ready( function () {
    $('#recentDisconnections').DataTable();
} );
</script>