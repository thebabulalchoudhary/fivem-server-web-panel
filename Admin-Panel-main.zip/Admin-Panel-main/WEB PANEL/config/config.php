<?php
////////////////////
// PANEL SETTINGS //
////////////////////
define("VERSION", "2.0.0"); // Panel Version (NEVER TOUCH THIS UNLESS UPADTING OR TOLD TO)
define("FRAMEWORK", "QBCORE"); // This will either be: "QBCORE" or "ESX" 
define("USER_PANEL", false); // Coming Soon! Will be for the new user panel website which will fully sync with the admin panel! 

//////////////////////////
// DATABASE CREDENTIALS //
//////////////////////////
define("db_host", ""); // Use the IP of the server your DATABASE is hosted on (MySQL)
define("db_user", ""); // Database Username
define("db_pass", ""); // Database User Password
define("db_name", ""); // Database Name
define("db_charset", "utf8"); // DO NOT touch this unless you advised to or you know what you are doing

//////////////////////////////
// SERVER BRAND INFORMATION //
//////////////////////////////
define("SERVER_NAME", "Admin Panel V2"); // Your FiveM Server Name (This shows on: Tabs, Title of every page, Discord Embeds)
define("SERVER_DESCRIPTION", "Description about your server!"); // Description of your server (This will also show on a Discord embed)
define("PANEL_URL", "http://localhost/adminpanel"); // The URL to access your website; DO NOT INCLUDE A FOLLOWING SLASH

////////////////////////////
// SERVER CONNECTION INFO //
////////////////////////////
define("SERVER_IP", ""); // The IP you use to connect to your FiveM Server
define("SERVER_PORT", "30120"); // The port you use to connect to your FiveM Server
define("SERVER_RCON_PASS", "PASSWORD"); // The RCON Password which is set in your FiveM server.cfg (Check documentation for full setup)

//////////////////////////
// OTHER CONFIG OPTIONS //
//////////////////////////

define("NAV_BAR_STYLE", "NEW"); // Either: NEW or OLD (MUST BE CAPS)(EXAMPLES: https://imgur.com/a/z1X6S4Q)
define("ALLOW_GIFS", true); // Either: "true" or "false" (Allow people to have GIFs as profile pictures?)
define("AUDIT_LOG_NUMBER", 50); // Number of logs to show on the main audit log page (Default is 50)
define("SHOW_PLAYERS_ONLINE", true); // Either "true" or "false" (Shows number of online players on navigation bar)
define("PERSONAL_INV_SLOTS", 40); // Number of personal inventory slots your server allows
define("PROPERTY_INV_SLOTS", 60); // Number of property inventory slots your server allows for player houses
define("APARTMENT_INV_SLOTS", 90); // Number of apartment inventory slots your server allows for apartments
define("VEHICLE_TRUNK_INV_SLOTS", 90); // Number of trunk inventory slots your server allows on vehicles
define("VEHICLE_GLOVEBOX_INV_SLOTS", 90); // Number of glovebox inventory slots your server allows for vehicles


//////////////////////////
// DISCORD LOG SETTINGS //
//////////////////////////
define("AVATAR_URL", "https://i.imgur.com/OKwpbYX.png"); // The profile picture for your discord webhooks
define("HEX_CODE", "000"); // The HEX code that will show on the embed (By Default 000 is black)

// ALL TYPES OF WEBHOOKS (INSERT DISCORD WEBHOOK IN EACH ONE)
define("LOGIN_LOGS", ""); // Notification when a staff logs into the panel
define("NOTE_LOGS", ""); // Webhook for when a note is created
define("NOTE_UPDATED_LOGS", ""); // Webhook for when notes are changed
define("KICK_LOGS", ""); // Webhook for when a kick is made
define("KICK_UPDATED_LOGS", ""); // Webhook for when a kick is changed
define("BAN_LOGS", ""); // Webhook for when a ban has been submitted
define("BAN_UPDATED_LOGS", ""); // Webhook for when a ban has been updated
define("PHONE_NUMBER_LOGS", ""); // Webhook for when a phone number has been changed
define("CHARACTER_NAME_LOGS", ""); // Webhook for when a character name has been changed
define("BANK_CHANGE_LOGS", ""); // Webhook for when a character"s bank amounts have been changed
define("VEHICLE_PLATE_CHANGE_LOGS", ""); // Webhook for when a vehicle"s plate has been changed
define("VEHICLE_GARAGE_CHANGE_LOGS", ""); // Webhook for when a vehicle"s parked garage has been changed
define("PROPERTY_TIER_LOGS", ""); // Webhook for when a vehicle"s parked garage has been changed
define("ACCOUNT_CREATED_LOGS", ""); // Webhook for when a staff account on the panel has been created
define("ACCOUNT_UPDATED_LOGS", ""); // Webhook for when staff account on the panel has been changed
define("GROUP_CHANGE_LOGS", ""); // Webhook for when a panel staff group has been changed

////////////////////////////////////////
// ALL VEHICLE GARAGES ON YOUR SERVER //
////////////////////////////////////////
// For example, below are from default qb-garages resource -> https://github.com/qbcore-framework/qb-garages/blob/main/config.lua
$GARAGES = array(
	[
        "garage_name" => "motelgarage",
        "garage_label" => "Motel Garage",
    ],
	[
        "garage_name" => "sapcounsel",
        "garage_label" => "San Andreas Parking",
    ],
    [
        "garage_name" => "spanishave",
        "garage_label" => "Spanish Ave Parking",
    ],
    [
        "garage_name" => "caears24",
        "garage_label" => "Caears 24 Parking",
    ],
    [
        "garage_name" => "airportp",
        "garage_label" => "Airport Parking",
    ],
    [
        "garage_name" => "pillboxgarage",
        "garage_label" => "Pillbox Garage Parking",
    ],
);
////////////////////
// VEHICLE STATES //
////////////////////
// Default vehicle states which show on vehicle info -> Manage State page
$VEHICLESTATES = array(
	[
        "id" => 0, // This is what gets changed in database
        "label" => "Vehicle Out", // Just the label for what it does
    ],
	[
        "id" => 1, // This is what gets changed in database
        "label" => "Vehicle Stored", // Just the label for what it does
    ],
    [
        "id" => 2, // This is what gets changed in database
        "label" => "Vehicle Impounded", // Just the label for what it does
    ]
);

///////////////////////////////////
// DEBUG SETTINGS (DO NOT TOUCH) //
///////////////////////////////////
ini_set("display_errors", 0); // DO NOT touch this unless advised to
ini_set("display_startup_errors", 0); // DO NOT touch this unless advised to
?>