<?php
include '../../config/config.php';
include '../../functions/main.php';
include '../../functions/lua/jobs.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$jobname = $_GET["job"];
foreach($jobsList as $newrow){
    $arrayname = $newrow["job_name"];
    if($arrayname == $jobname){
        $joblabel = $newrow["job_label"];
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Job Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../../assets/images/logo-fav.png">
    <link href="../../assets/main.css" rel="stylesheet">
    <link href="../../assets/libs/datatables/datatables.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
                <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-id icon-gradient qb-core">
                                </i>
                            </div>
                                <div>Job Information - <?php echo $joblabel; ?>
                                    <div class="page-title-subheading">This page displays information about a job and allows you to view people in that job.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>General Information</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Players With Job</span>
                        </a>
                    </li>
                </ul>
                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">General Information</a></li>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">Players with Job</a></li>
                </ul>
                <?php } ?>

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="row">   
                            <div class="col-lg-3 offset-md-4">
                                <div class="card text-center">
                                    <div class="card-header">General Information</div>
                                        <div class="card-body">
                                        <p><b>Job Name: </b><?php echo $jobname; ?> </p>
                                        <p><b>Job Label: </b><?php echo $joblabel; ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>  
                        <br>
                        <div class="row">
                            <div class="col-lg-3 offset-md-4">
                                <div class="card text-center">
                                    <div class="card-header">All Job Grades</div>
                                        <div class="card-body">
                                        <table class="mb-0 table table-hover">
                                            <thead>
                                                <th>#</th>
                                                <th>Job Grade</th>
                                                <th>Job Grade Payment</th>
                                            </thead>
                                            <tbody>
                                                <?php
                                                foreach($jobsList as $newrow){
                                                    $job = $newrow["job_name"];
                                                    if($job == $jobname){
                                                        $rawData = $newrow["job_grades"];
                                                        foreach($rawData as $key => $value){
                                                            $gradekey = $key;
                                                            $gradename = $value["name"];
                                                            $gradepayment = $value["payment"];
                                                            
                                                            echo 
                                                            '<tr>
                                                            <td>'. $gradekey .'</td>
                                                            <td>'. $gradename .'</td>
                                                            <td>$'. $gradepayment .'</td>
                                                            </tr>';
                                                        }
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                        <div class="row">
                            <div class="col-5 offset-md-3">
                                <div class="card">
                                    <div class="card-body"><div class="card-title">All Players with <?php echo $joblabel; ?> Job</div>
                                        <table id="playerJobs" class="display" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>Character Name</th>
                                                    <th>Character Job Grade</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $player = $pdo->query("SELECT citizenid,charinfo,job FROM players");
                                                    foreach($player as $newrow2){
                                                        $jsonjob = $newrow2["job"];
                                                        $jobdecode = json_decode($jsonjob);
                                                        $jobnamefetch = $jobdecode->{"name"};
                                                        if($jobnamefetch == $jobname){
                                                            $jsoncharinfo = $newrow2["charinfo"];
                                                            $infodecode = json_decode($jsoncharinfo);

                                                    echo 
                                                    '<tr>
                                                    <td><a id="accentcolor" href="'.PANEL_URL.'/characters/info.php?citizenid=' . $newrow2["citizenid"] . '">'. $infodecode->{'firstname'}. ' '.$infodecode->{'lastname'}. ' ('. $newrow2["citizenid"].')</td>
                                                    <td>'. $jobdecode->{"grade"}->{"name"} .'</td>
                                                    </tr>';
                                                    }}
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include "../../inserts/insert_footer.php"; ?> 
            </div>
        </div>
    </div>
</div>

    <script type="text/javascript" src="../../assets/scripts/main.js"></script></body>
    <script src="../../assets/js/vendor.min.js"></script>
    <script src="../../assets/js/app.min.js"></script>
    <script src="../../assets/libs/morris-js/morris.min.js"></script>
    <script src="../../assets/libs/datatables/datatables.min.js"></script>
</html>
<script>
    $(document).ready( function () {
    $('#playerJobs').DataTable({});
} );
</script>