<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$apartmentid = $_GET["id"];
$result = $pdo->query("SELECT * FROM apartments WHERE id = '$apartmentid'");
foreach($result as $row) 
{
    $apartmentid = $row["id"];
    $owner = $row["citizenid"];
    $apartmentname = $row["name"];
    $apartmentlabel = $row["label"];
    $apartmenttype = $row["type"];
}

$result2 = $pdo->query("SELECT charinfo from players WHERE citizenid = '$owner'");
foreach($result2 as $row2){
    $charinfo = $row2["charinfo"];
    $decodeinfo = json_decode($charinfo);
    $firstname = $decodeinfo->{"firstname"};
    $lastname = $decodeinfo->{"lastname"};
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Apartment Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
    <link href="../assets/libs/datatables/datatables.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-drawer icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Apartment Information - <?php echo $apartmentlabel ?>
                                <div class="page-title-subheading">This page shows all the information about a specific apartment.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>General Information</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Apartment Inventory</span>
                        </a>
                    </li>
                </ul>
                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">General Information</a></li>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">Apartment Inventory</a></li>
                </ul>
                <?php } ?>

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="col-lg-4 offset-md-4">
                            <div class="card text-center">
                                <div class="card-header">General Information</div>
                                    <div class="card-body">
                                    <p><b>Apartment ID: </b><?php echo $apartmentid; ?> </p>
                                    <p><b>Apartment Name:</b> <?php echo $apartmentname; ?></p>
                                    <p><b>Apartment Label:</b> <?php echo $apartmentlabel; ?></p>
                                    <p><b>Apartment Owner: </b> <a href="<?php echo PANEL_URL; ?>/characters/info?citizenid=<?php echo $owner; ?>"><?php echo $firstname; ?> <?php echo $lastname; ?></a></p>
                                    <p><b>Apartment Type: </b><?php echo $apartmenttype; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                        <div class ="d-flex justify-content-center overflow-auto inventory-scroll-bar inventory-container">
                            <div class="d-flex justify-content-start flex-wrap inventory">
                                <?php
                                $inventory = $pdo->query("SELECT stash,items FROM stashitems WHERE stash = '$apartmentname'");

                                if($inventory->rowCount() > 0){
                                    foreach($inventory as $row){
                                        $fetchInventory = $row["items"];
                                        $inventoryItems = json_decode($fetchInventory);
                                        for($i = 1; $i <= APARTMENT_INV_SLOTS; $i++){
                                            $exists = false;
                                            foreach($inventoryItems as $row2){
                                                $itemname = $row2->{'name'};
                                                $itemlabel = $row2->{'label'};
                                                $itemamount = $row2->{'amount'};
                                                $itemslot = $row2->{'slot'};
                                                if($i==$itemslot){
                                                    $exists = true;
                                                    echo'
                                                    <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'">
                                                        <div class="d-flex inventory-icon flex-column align-items-between" style="background-image: url(../assets/images/inventory/'.$itemname.'.png)">
                                                            <div class="d-flex justify-content-between inventory-details">
                                                                <div class="d-flex justify-content inventory-slot">'.$i.'</div>
                                                                <div class="d-flex justify-content-end inventory-item-quantity">x'.$itemamount.'</div>
                                                            </div>
                                                            <div class="d-flex justify-content-center align-items-end inventory-item-name">'.$itemlabel.'</div>
                                                        </div>
                                                    </div>';
                                                    break;
                                                }
                                            }
                                            if($exists == false){
                                                echo'
                                                <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'"> 
                                                    <div class="d-flex inventory-slot">'.$i.'</div>
                                                </div>';
                                            }
                                        }
                                    }
                                } else { 
                                ?>
                                <br>
                                <p>This apartment does not have an inventory.</p>
                                <?php } ?>
                            </div>
                        </div> 
                    </div>
                </div>
            <!-- FOOTER -->
            <?php include "../inserts/insert_footer.php"; ?> 
        </div>
    </div>
    </div>
    <script type="text/javascript" src="../assets/scripts/main.js"></script></body>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
</html>
