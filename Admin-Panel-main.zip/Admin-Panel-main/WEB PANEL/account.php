<?php
include 'config/config.php';
include 'functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$myaccount = $_SESSION['id'];
$result = $pdo->query("SELECT * FROM adminpanel_staff WHERE ID = '$myaccount'");
foreach($result as $row) 
{
    $username = $row["username"];
    $rockstar = $row["rockstar"];
    $discordID = $row["discord"];
    $groupID = $row["groupid"];
}

$result2 = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID = '$groupID'");
foreach($result2 as $row2){
    $groupname = $row2["groupname"];
}

if (isset($_POST['submit_password'])){
    $passwordhtmlentity = $_POST['password'];
    $passwordconfirmhtmlentity = $_POST['confirm_password'];

    if ($passwordhtmlentity == $passwordconfirmhtmlentity) {
        $stmt = $pdo->prepare('UPDATE adminpanel_staff SET password = ? WHERE id = ?');
        $password = password_hash($passwordhtmlentity, PASSWORD_DEFAULT);
        $stmt->execute([ $password, $myaccount ]);

        //Send Discord Webhook
            $staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = ACCOUNT_UPDATED_LOGS;
            $hookObject = json_encode([
                "content" => "",
                "username" => "ACCOUNT UPDATED LOGS",
                "avatar_url" => AVATAR_URL,
                "tts" => false,
                "embeds" => [
                    [
                        "title" => "STAFF MEMBER CHANGED PASSWORD",
                        "type" => "rich",
                        "description" => "**$staffusername** has changed their password",
                        "url" => "$starturl",
                        "color" => hexdec( HEX_CODE ),
                    ]
                ]

            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            $ch = curl_init();
            curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
            $response = curl_exec( $ch );curl_close( $ch );
            header("Location: ".PANEL_URL."/account");
        } 
    else {
        header("Location: ".PANEL_URL."/account");
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Manage Account</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="assets/images/logo-fav.png">
    <link href="assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                    </div>
                        <ul class="header-menu nav">  
                    </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
            <div class="app-sidebar sidebar-shadow">
                <div class="app-header__logo">
                    <div class="logo-src"></div>
                    <div class="header__pane ml-auto">
                        <div>
                            <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="app-header__mobile-menu">
                    <div>
                        <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>

                <div class="app-header__menu">
                    <span>
                        <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                            <span class="btn-icon-wrapper">
                                <i class="fa fa-ellipsis-v fa-w-6"></i>
                            </span>
                        </button>
                    </span>
                </div>    

                <!-- NAVIGATION BAR -->
                <?php include "inserts/insert_navBar.php"; ?> 

                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-id icon-gradient qb-core">
                                </i>
                            </div>
                                <div>My Account
                                    <div class="page-title-subheading">This page displays information and statistics about your account and allows you to make changes to your account!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-5 offset-md-3">
                    <div class="card text-center">
                            <div class="card-body">
                            <h4><b>Account Name </b></h4>
                            <h5><?php echo $username; ?> </h5>
                        </div>
                    </div>
                </div>

                <br>

                <div class="col-md-5 offset-md-3">
                    <div class="card text-center">
                            <div class="card-body">
                            <h4><b>Account Password </b></h4><br>
                            <a href="" button data-toggle="modal" data-target="#changePassword" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CHANGE PASSWORD</a></button>
                        </div>
                    </div>
                </div>

                <br>

                <div class="col-md-5 offset-md-3">
                    <div class="card text-center">
                            <div class="card-body">
                            <h4><b>Other Account Information</b></h4><br>
                            <h6><b>Permission Group:</b> <?php echo $groupname ?></h6>
                            <h6><b>Discord ID:</b> <?php echo $discordID ?></h6>
                            <h6><b>Rockstar License:</b> <?php echo $rockstar ?></h6>
                        </div>
                    </div>
                </div>

                <br>

                <div class="col-md-5 offset-md-3">
                    <div class="card text-center">
                        <div class="card-body">
                            <h4><b>Account Profile Picture </b></h4><br>
                            <div class="profilepic">
                                <form class="" action="functions/forms/profilepicture.php" method="post" enctype="multipart/form-data">
                                    <div class="position-relative form-check-inline">
                                        <input type="file" name="fileToUpload" id="fileToUpload">
                                    </div>
                                    <div class="position-relative form-check-inline">
                                        <button type="submit" class="btn btn-primary">Update Profile Picture</button>
                                    </div>
                                    <br>
                                    <br>
                                </form>
                                <div class="errormessage"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include "inserts/insert_footer.php"; ?> 
            </div>
        </div>
    </div>
</div>
    <script type="text/javascript" src="./assets/scripts/main.js"></script>
</body>
<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/app.min.js"></script>

<script>
document.querySelector(".profilepic form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".profilepic form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".profilepic form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/account";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>
</html>

<!-- Change Password Modal -->
<div class="modal fade" id="changePassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Your Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" method="post">
                    <div class="position-relative row form-group"><label for="password" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10"><input name="password" type="password" id="password" value="" class="form-control" required></div>
                    </div>
                    <div class="position-relative row form-group"><label for="confirm_password" class="col-sm-2 col-form-label">Confirm Password</label>
                        <div class="col-sm-10"><input name="confirm_password" type="password" id="confirm_password" value="" class="form-control" required></div>
                    </div>

                    <!-- SUBMIT BUTTON -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <div class="col-sm-10 offset-sm-2"><button type="submit" name="submit_password" value="Submit" class="btn btn-primary">Update Password</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>