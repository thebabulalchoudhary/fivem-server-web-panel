<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$vehicle = $_GET["id"];
$result = $pdo->query("SELECT * FROM player_vehicles WHERE id = '$vehicle'");
foreach($result as $row) 
{
    $vehicleid = $row["id"];
    $citizenid = $row["citizenid"];
    $realplate = $row["plate"];
    $fakeplate = $row["fakeplate"];
    $model = $row["vehicle"];
    $modelhash = $row["hash"];
    $garage = $row["garage"];
    $fuel = $row["fuel"];
    $engine = $row["engine"];
    $body = $row["body"];
    $mileage = $row["drivingdistance"];
    $mileagecalculated = $mileage / 7;
    $mileageformatted = number_format($mileagecalculated, 2, '.', ' ');
    $state = $row["state"];
}

foreach($VEHICLESTATES as $newrow){
    if($newrow["id"] == $state){
        $stateformatted = $newrow["label"];
    }
}

$playername = $pdo->query("SELECT charinfo FROM players WHERE citizenid = '$citizenid'");
foreach($playername as $row2) 
{
    $jsoncharinfo = $row2["charinfo"];
    $charinfo = json_decode($jsoncharinfo);
    $charfirst = $charinfo->{'firstname'};
    $charlast = $charinfo->{'lastname'};
}

$mygroup = $_SESSION['group']; 
$PERMchangeLicensePlates = false; 
$PERMchangeParkedGarage = false;
$PERMchangestate = false;
$perm = $pdo->query("SELECT licenseplates,parkedgarage,vehiclestate FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["licenseplates"] == 1){
        $PERMchangeLicensePlates = true;
    }
    if ($row["parkedgarage"] == 1){
        $PERMchangeParkedGarage = true;
    }
    if ($row["vehiclestate"] == 1){
        $PERMchangestate = true;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Vehicle Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-car icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Vehicle Information - <?php echo $realplate; ?> (<?php echo $charfirst; ?> <?php echo $charlast; ?>)
                                <div class="page-title-subheading">This page displays information on a specific vehicle. If nothing shows go back to the Search Vehicles tab and try again.
                            </div>
                        </div>
                    </div>

                    <div class="page-title-actions">
                        <button type="button" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="mb-2 mr-2 dropdown-toggle btn btn-lg btn-outline-primary">
                            Manage <?php echo $realplate; ?> (<?php echo $charfirst; ?> <?php echo $charlast; ?>)
                        </button>
                        <div href="" tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(64px, 37px, 0px);">
                            <button href="" button data-toggle="modal" data-target="#changePlates"type="button" tabindex="0" class="dropdown-item">Change License Plates</button>
                            <button href="" button data-toggle="modal" data-target="#changeGarage"type="button" tabindex="0" class="dropdown-item">Change Parked Garage</button>
                            <button href="" button data-toggle="modal" data-target="#changeState"type="button" tabindex="0" class="dropdown-item">Change Vehicle State</button>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>Vehicle Information</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Trunk Inventory</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-3" data-toggle="tab" href="#tab-content-3">
                            <span>Glovebox Inventory</span>
                        </a>
                    </li>
                </ul>
                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">Vehicle Information</a></li>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">Trunk Inventory</a></li>
                    <li class="nav-item"><a id="tab-3" data-toggle="tab" href="#tab-content-3" class="nav-link show">Glovebox Inventory</a></li>
                </ul>
                <?php } ?>

            <div class="tab-content">
                <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-4 offset-md-2">
                            <div class="card text-center">
                                <div class="card-header">General Information</div>
                                    <div class="card-body">
                                    <p><b>Owned By:</b> <a href="<?php echo PANEL_URL ?>/characters/info?citizenid=<?php echo $citizenid; ?>"><?php echo $charfirst; ?> <?php echo $charlast; ?> (<?php echo $citizenid; ?>)</a></p>
                                    <p><b>License Plate: </b><?php echo $realplate; ?> </p>
                                    <p><b>Fake Plate (If Applicable): </b><?php echo $fakeplate; ?> </p>
                                    <p><b>Vehicle State: </b><?php echo $stateformatted; ?> </p>
                                    <p><b>Vehicle Model (Hash): </b><?php echo $model . ' '; ?>(<?php echo $modelhash; ?>) </p>
                                    <p><b>Current Garage: </b><?php echo $garage; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card text-center">
                                <div class="card-header">Vehicle Info</div>
                                    <div class="card-body">
                                    <p><b>Fuel Level: </b><?php echo $fuel; ?>% </p>
                                    <p><b>Engine Status: </b><?php echo $engine; ?> / 1000</p>
                                    <p><b>Body Status: </b><?php echo $body; ?> / 1000</p>
                                    <p><b>Distance Driven: </b><?php echo $mileageformatted . ' Miles'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                    <div class ="d-flex justify-content-center overflow-auto inventory-scroll-bar inventory-container">
                        <div class="d-flex justify-content-start flex-wrap inventory">
                            <?php
                            $inventory = $pdo->query("SELECT plate,items FROM trunkitems WHERE plate = '$realplate'");

                            if($inventory->rowCount() > 0){
                                foreach($inventory as $row){
                                    $fetchInventory = $row["items"];
                                    $inventoryItems = json_decode($fetchInventory);
                                    for($i = 1; $i <= VEHICLE_TRUNK_INV_SLOTS; $i++){
                                        $exists = false;
                                        foreach($inventoryItems as $row2){
                                            $itemname = $row2->{'name'};
                                            $itemlabel = $row2->{'label'};
                                            $itemamount = $row2->{'amount'};
                                            $itemslot = $row2->{'slot'};
                                            if($i==$itemslot){
                                                $exists = true;
                                                echo'
                                                <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'">
                                                    <div class="d-flex inventory-icon flex-column align-items-between" style="background-image: url(../assets/images/inventory/'.$itemname.'.png)">
                                                        <div class="d-flex justify-content-between inventory-details">
                                                            <div class="d-flex justify-content inventory-slot">'.$i.'</div>
                                                            <div class="d-flex justify-content-end inventory-item-quantity">x'.$itemamount.'</div>
                                                        </div>
                                                        <div class="d-flex justify-content-center align-items-end inventory-item-name">'.$itemlabel.'</div>
                                                    </div>
                                                </div>';
                                                break;
                                            }
                                        }
                                        if($exists == false){
                                            echo'
                                            <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'"> 
                                                <div class="d-flex inventory-slot">'.$i.'</div>
                                            </div>';
                                        }
                                    }
                                }
                            } else { 
                            ?>
                            <br>
                            <p>This vehicle does not have a trunk inventory.</p>
                            <?php } ?>
                        </div>
                    </div> 
                </div>
                <div class="tab-pane tabs-animation fade" id="tab-content-3" role="tabpanel">
                    <div class ="d-flex justify-content-center overflow-auto inventory-scroll-bar inventory-container">
                        <div class="d-flex justify-content-start flex-wrap inventory">
                            <?php
                            $inventory = $pdo->query("SELECT plate,items FROM gloveboxitems WHERE plate = '$realplate'");

                            if($inventory->rowCount() > 0){
                                foreach($inventory as $row){
                                    $fetchInventory = $row["items"];
                                    $inventoryItems = json_decode($fetchInventory);
                                    for($i = 1; $i <= VEHICLE_GLOVEBOX_INV_SLOTS; $i++){
                                        $exists = false;
                                        foreach($inventoryItems as $row2){
                                            $itemname = $row2->{'name'};
                                            $itemlabel = $row2->{'label'};
                                            $itemamount = $row2->{'amount'};
                                            $itemslot = $row2->{'slot'};
                                            if($i==$itemslot){
                                                $exists = true;
                                                echo'
                                                <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'">
                                                    <div class="d-flex inventory-icon flex-column align-items-between" style="background-image: url(../assets/images/inventory/'.$itemname.'.png)">
                                                        <div class="d-flex justify-content-between inventory-details">
                                                            <div class="d-flex justify-content inventory-slot">'.$i.'</div>
                                                            <div class="d-flex justify-content-end inventory-item-quantity">x'.$itemamount.'</div>
                                                        </div>
                                                        <div class="d-flex justify-content-center align-items-end inventory-item-name">'.$itemlabel.'</div>
                                                    </div>
                                                </div>';
                                                break;
                                            }
                                        }
                                        if($exists == false){
                                            echo'
                                            <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'"> 
                                                <div class="d-flex inventory-slot">'.$i.'</div>
                                            </div>';
                                        }
                                    }
                                }
                            } else { 
                            ?>
                            <br>
                            <p>This vehicle does not have a glovebox inventory.</p>
                            <?php } ?>
                        </div>
                    </div> 
                </div>
            </div>
            <!-- FOOTER -->
            <?php include "../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>
<script type="text/javascript" src="../assets/scripts/main.js"></script>
</body>
<script src="../assets/js/vendor.min.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/morris-js/morris.min.js"></script>
</html>

<!------------------->
<!-- Change Plates -->
<!------------------->
<div class="modal fade" id="changePlates" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change License Plates</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                    if ($PERMchangeLicensePlates) { ?>
                    <div class="changeplates">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/vehicle_changeplates.php" method="post">

                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Real Plate</label>
                                <div class="col-sm-10"><input class="form-control" name="real_plate" required="text" value="<?php echo $realplate; ?>"></div>
                            </div>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Fake Plate</label>
                                <div class="col-sm-10"><input class="form-control" name="fake_plate" value="<?php echo $fakeplate; ?>"></div>
                            </div>
                            <input type="hidden" name="vehicleid" value="<?php echo $vehicleid ?>">

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Update License Plates</button></div>
                            </div>
                        </form>
                    </div>
                    <?php
                    } else { ?>
                        <p>You do not have permission to change vehicle license plates</p>
                    <?php }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changeplates form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changeplates form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changeplates form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/vehicles/info?id=<?php echo $vehicleid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!------------------->
<!-- Change Garage -->
<!------------------->
<div class="modal fade" id="changeGarage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Vehicle Garage</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                    if ($PERMchangeParkedGarage) { ?>
                    <div class="changegarage">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/vehicle_changegarage.php" method="post">
                            <p><b>Current Garage: </b><?php echo $garage; ?></p>
                            <div class="position-relative row form-group">
                                <label class="col-sm-2 col-form-label">Garage</label>
                                <div class="col-sm-10">
                                    <select name="garagechange"class="form-control">
                                        <?php  
                                            foreach($GARAGES as $newrow){
                                        ?>
                                        <option value="<?php echo $newrow['garage_name'] ?>"><?php echo $newrow['garage_label'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <input type="hidden" name="vehicleid" value="<?php echo $vehicleid ?>">
                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Update Parked Garage</button></div>
                            </div>
                        </form>
                    </div>
                    <?php
                    } else { ?>
                        <p>You do not have permission to change vehicle parked garage.</p>
                    <?php }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changegarage form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changegarage form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changegarage form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/vehicles/info?id=<?php echo $vehicleid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!------------------->
<!-- Change State  -->
<!------------------->
<div class="modal fade" id="changeState" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Vehicle State</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                    if ($PERMchangestate) { ?>
                    <div class="changestate">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/vehicle_changestate.php" method="post">
                            <input type="hidden" name="vehicleid" value="<?php echo $vehicleid ?>">
                            <li class="list-group-item-warning list-group-item"><b>Please Note:</b> Be careful when changing a vehicle's state as it can cause issues and break the vehicle if you chose a state that does not make sense.</li>
                            <br>
                            <div class="position-relative row form-group">
                                <label class="col-sm-2 col-form-label">State</label>
                                <div class="col-sm-10">
                                    <select name="statechange"class="form-control">
                                        <?php  
                                            foreach($VEHICLESTATES as $newrow){
                                        ?>
                                        <option value="<?php echo $newrow['id'] ?>"><?php echo $newrow['label'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Update Vehicle State</button></div>
                            </div>
                        </form>
                    </div>
                    <?php
                    } else { ?>
                        <p>You do not have permission to change vehicle states.</p>
                    <?php }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changestate form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changestate form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changestate form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/vehicles/info?id=<?php echo $vehicleid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>