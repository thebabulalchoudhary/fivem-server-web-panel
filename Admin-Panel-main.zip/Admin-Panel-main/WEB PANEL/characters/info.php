<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$citizenid = $_GET["citizenid"];
$character = $pdo->query("SELECT * FROM players WHERE citizenid = '$citizenid'");
foreach($character as $row){
    $charid = $row["id"];
    $rockstar = $row["license"];
    $owner = $row["name"];
    $lastplayed = $row["last_updated"];
    $jsoncharinfo = $row["charinfo"];
    $charinfo = json_decode($jsoncharinfo);
    $jsonmetadata = $row["metadata"];
    $metadata = json_decode($jsonmetadata);
    $jsonmoney= $row["money"];
    $money = json_decode($jsonmoney);
    $jsonjob= $row["job"];
    $job = json_decode($jsonjob);    
    $jsongang= $row["gang"];
    $gang = json_decode($jsongang);
    $bank = $money->{'bank'};
    $bankformatted = number_format($bank);
    $cash = $money->{'cash'};
    $cashformatted = number_format($cash);
    $genderjson = $charinfo->{'gender'};
    $gender = "";
    switch($genderjson)
    {
        case "1":
            $gender = "Female";
            break;
        case "0":
            $gender = "Male";
            break;
    }

}

$savingsformatted = "No Savings Account";
$savings = $pdo->query("SELECT * FROM bank_accounts WHERE citizenid = '$citizenid' AND account_type = 'Savings'");
foreach($savings as $row2){
    if($savings){
        $savingsamount = $row2["amount"];
        $savingsformatted = "$" . number_format($savingsamount) . " ";
    }
}

$user = $pdo->query("SELECT * FROM adminpanel_players WHERE license = '$rockstar'");
foreach($user as $row){
    $playername = $row["playername"];
    $accountid = $row["id"];
    $discord = $row["discord"];
}

$playerOnline = false;
$serverConnection = file_get_contents('http://'.SERVER_IP.':'.SERVER_PORT.'/players.json');
$serverData = json_decode($serverConnection, true);
foreach($serverData as $row) 
{
    $identifiersArray = $row["identifiers"];
    $identifiers = json_encode($identifiersArray);
    $split = explode(",", $identifiers);
    foreach($split as $row2){
        if(strpos($row2, "license:") !== false){
            $onlineLicense = substr($row2, 1, -1);
            if($onlineLicense == $rockstar){
                $playerOnline = true;
                $OnlineServerID = $row["id"];
                break;
            }
        }
    }
}

$mygroup = $_SESSION['group']; 
$PERMchangePhoneNumber = false; 
$PERMchangeBankAmounts = false;
$PERMchangeCharName = false;
$PERMwipeInventory = false;
$perm = $pdo->query("SELECT phonenumber,bankamounts,editcharname,wipeinventory FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["phonenumber"] == 1) {
        $PERMchangePhoneNumber = true;
    }
    if ($row["bankamounts"] == 1) {
        $PERMchangeBankAmounts = true;
    }
    if ($row["editcharname"] == 1) {
        $PERMchangeCharName = true;
    }
    if ($row["wipeinventory"] == 1) {
        $PERMwipeInventory = true;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Character Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
   </head>
<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
                <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-id icon-gradient qb-core">
                                </i>
                            </div>
                                <div>Character Information - <?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>
                                    <div class="page-title-subheading">This page displays information on a specific character. If nothing shows go back to the Search Characters tab and try again.
                                </div>
                            </div>
                        </div>
                        
                        <div class="page-title-actions">
                            <button type="button" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="mb-2 mr-2 dropdown-toggle btn btn-lg btn-outline-primary">
                                Manage <?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>
                            </button>
                            <div href="" tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(64px, 37px, 0px);">
                                <button href="" button data-toggle="modal" data-target="#changeNumber"type="button" tabindex="0" class="dropdown-item">Change Phone Number</button>
                                <button href="" button data-toggle="modal" data-target="#changeBank"type="button" tabindex="0" class="dropdown-item">Change Bank Amounts</button>
                                <button href="" button data-toggle="modal" data-target="#changeName"type="button" tabindex="0" class="dropdown-item">Change Character Name</button>
                                <button href="" button data-toggle="modal" data-target="#wipeInventory"type="button" tabindex="0" class="dropdown-item">Wipe Inventory</button>
                            </div>
                        </div>
                    </div>
                </div>  

                <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>General Information</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Owned Vehicles</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-3" data-toggle="tab" href="#tab-content-3">
                            <span>Owned Properties/Apartments</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-4" data-toggle="tab" href="#tab-content-4">
                            <span>Bank Statements</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-5" data-toggle="tab" href="#tab-content-5">
                            <span>View Inventory</span>
                        </a>
                    </li>
                <!-- COMING SOON                    
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-5" data-toggle="tab" href="#tab-content-5">
                            <span>Last Location</span>
                        </a>
                    </li> 
                -->
                </ul>
                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">General Information</a></li>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">Owned Vehicles</a></li>
                    <li class="nav-item"><a id="tab-3" data-toggle="tab" href="#tab-content-3" class="nav-link show">Owned Properties/Apartments</a></li>
                    <li class="nav-item"><a id="tab-4" data-toggle="tab" href="#tab-content-4" class="nav-link show">Bank Statements</a></li>
                    <li class="nav-item"><a id="tab-5" data-toggle="tab" href="#tab-content-5" class="nav-link show">View Inventory</a></li>
                    <!-- COMING SOON
                    <li class="nav-item"><a id="tab-5" data-toggle="tab" href="#tab-content-5" class="nav-link show">Last Location</a></li> 
                    -->
                </ul>
                <?php } ?>

                <?php if($playerOnline){ ?>
                <div class="card text-center">
                    <div class="card-header">
                        <div class="card-body">
                            This character is currently online (ID: <?php echo $OnlineServerID; ?>)
                        </div>
                    </div>
                </div>
                <br>
                <?php } ?>

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="row">   
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">General Information (Out-Of-Character)</div>
                                        <div class="card-body">
                                        <p><b>Character ID: </b><?php echo $charid; ?> </p>
                                        <p><b>Owned By:</b> <a href="<?php echo PANEL_URL ?>/players/info?playerId=<?php echo $accountid; ?>"><?php echo $playername; ?></a></p>
                                        <p><b>Citizen ID:</b> <?php echo $citizenid; ?></p>
                                        <p><b>Rockstar:</b> <?php echo $rockstar; ?></p>
                                        <p><b>Discord ID:</b> <?php echo $discord; ?></p>
                                        <p><b>Last Played:</b> <?php echo $lastplayed; ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">General Information (In-Character)</div>
                                        <div class="card-body">
                                        <p><b>Character Name:</b> <?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?></p>
                                        <p><b>Nationality:</b> <?php echo $charinfo->{'nationality'}; ?></p>
                                        <p><b>Gender:</b> <?php echo $gender; ?></p>
                                        <p><b>Birthdate:</b> <?php echo $charinfo->{'birthdate'}; ?></p>
                                        <p><b>Phone Number:</b> <?php echo $charinfo->{'phone'}; ?></p>
                                        <p><b>Blood Type:</b> <?php echo $metadata->{'bloodtype'}; ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Banking Information</div>
                                        <div class="card-body">
                                        <p><b>Account Number:</b> $<?php echo $charinfo->{'account'}; ?></p>
                                        <p><b>Wallet ID:</b> $<?php echo $metadata->{'walletid'}; ?></p>
                                        <p><b>Bank:</b> $<?php echo $bankformatted; ?></p>
                                        <p><b>Savings:</b> <?php echo $savingsformatted; ?></p>
                                        <p><b>Cash:</b> $<?php echo $cashformatted; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Job Information</div>
                                        <div class="card-body">
                                        <p><b>Job:</b> <a href="<?php echo PANEL_URL ?>/occupations/jobs/manage?job=<?php echo $job->{'name'}; ?>"><?php echo $job->{'label'}; ?></a></p>
                                        <p><b>Job Grade:</b> <?php echo $job->{'grade'}->{'name'} ?></p>
                                        <p><b>Job Payment:</b> $<?php echo $job->{'payment'}; ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Gang Information</div>
                                        <div class="card-body">
                                        <p><b>Gang Name:</b> <?php echo $gang->{'label'}; ?></p>
                                        <p><b>Gang Rank:</b> <?php echo $gang->{'grade'}->{'name'}; ?></p>
                                        <p><b>Is Boss?</b> <?php echo $gang->{'isboss'}; ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card text-center">
                                    <div class="card-header">Apartments</div>
                                        <div class="card-body">
                                        <table class="mb-0 table table-hover">
                                            <thead>
                                                <th>#</th>
                                                <th>Apartment Label</th>
                                                <th>Apartment Name</th>
                                                <th>Apartment Type</th>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $apartment = $pdo->query("SELECT * FROM apartments WHERE citizenid='$citizenid'");
                                                    foreach($apartment as $newrow){
                                                    
                                                    echo 
                                                    '<tr>
                                                        <td>'. $newrow['id'] .'</td>
                                                        <td><a id="accentcolor" href="'.PANEL_URL.'/apartments/info?id=' . $newrow['id'] . '">'. $newrow["label"].'</td>
                                                        <td>'. $newrow['name'] .'</td>
                                                        <td>'. $newrow['type'] .'</td>
                                                    </tr>';
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                        <div class="col-lg-7 offset-md-2">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="header-title"><b><?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>'s Vehicles</b></h4>
                                    <table class="mb-0 table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Vehicle ID</th>
                                            <th>License Plate</th>
                                            <th>Vehicle Model</th>
                                            <th>Vehicle Model Hash</th>
                                            <th>Current Garage</th>
                                        </tr>
                                    </thead>
                                        <tbody>
                                            <?php
                                                $uniquevehicle = $pdo->query("SELECT * FROM player_vehicles WHERE citizenid='$citizenid'");
                                                foreach($uniquevehicle as $newrow){
                                                
                                                echo 
                                                    '<td>'. $newrow['id'] .'</td>
                                                    <td><a id="accentcolor" href="'.PANEL_URL.'/vehicles/info?id=' . $newrow['id'] . '">'. $newrow['plate'].'</td>
                                                    <td>'. $newrow['vehicle'] .'</td>
                                                    <td>'. $newrow['hash'] .'</td>
                                                    <td>'. $newrow['garage'] .'</td>
                                                    </tr>';
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-3" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-body"><div class="card-title"><?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>'s Properties</b></div>
                                        <table class="mb-0 table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Property ID</th>
                                                <th>Property</th>
                                                <th>Property Tier</th>
                                                <th>Property Value</th>
                                            </tr>
                                        </thead>
                                            <tbody>
                                                <?php
                                                    $uniqueproperty = $pdo->query("SELECT * FROM player_houses WHERE citizenid='$citizenid'");
                                                    foreach($uniqueproperty as $newrow){
                                                        $houseid = $newrow['id'];
                                                        $uniqueproperty2 = $pdo->query("SELECT * FROM houselocations WHERE id='$houseid'");
                                                            foreach($uniqueproperty2 as $newrow2){
                                                                $houselabel = $newrow2["label"];
                                                                $value = number_format($newrow2["price"]);
                                                            }
                                                    echo 
                                                        '<tr>
                                                        <td>'. $newrow['id'] .'</td>
                                                        <td><a id="accentcolor" href="'.PANEL_URL.'/properties/info?propertyId=' . $newrow['id'] . '">'. $houselabel.'</td>
                                                        <td>Tier '. $newrow2['tier'] .'</td>
                                                        <td>$'. $value .'</td>
                                                        </tr>';
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-body"><div class="card-title"><?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>'s Apartments</b></div>
                                        <table class="mb-0 table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Apartment ID</th>
                                                <th>Apartment Label</th>
                                                <th>Apartment Name</th>
                                                <th>Apartment Type</th>
                                            </tr>
                                        </thead>
                                            <tbody>
                                                <?php
                                                    $apartment = $pdo->query("SELECT * FROM apartments WHERE citizenid='$citizenid'");
                                                    foreach($apartment as $newrow){

                                                    echo 
                                                        '<tr>
                                                        <td>'. $newrow['id'] .'</td>
                                                        <td><a id="accentcolor" href="'.PANEL_URL.'/apartments/info?id=' . $newrow['id'] . '">'. $newrow["label"].'</td>
                                                        <td>'. $newrow['name'] .'</td>
                                                        <td>'. $newrow["type"] .'</td>
                                                        </tr>';
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-4" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="header-title"><b><?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>'s Bank Statements (Withdraw)</b></h4>
                                        <table class="mb-0 table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Time of Transaction</th>
                                                <th>Withdrawn</th>
                                                <th>Account Balance After</th>
                                                <th>Transaction Type</th>
                                            </tr>
                                        </thead>
                                            <tbody>
                                                <?php
                                                    $withdraw = $pdo->query("SELECT * FROM bank_statements WHERE citizenid='$citizenid' AND (deposited = '0') ORDER BY record_id DESC");
                                                    foreach($withdraw as $newrow){
                                                        $withdrawnAmount = number_format($newrow['withdraw']);
                                                        $balanceAfter = number_format($newrow['balance']);
                                                    
                                                    echo 
                                                        '<td>'. $newrow['date'] .'</td>
                                                        <td><b>$'. $withdrawnAmount .'</b></td>
                                                        <td>$'. $balanceAfter .'</td>
                                                        <td>'. $newrow['type'] .'</td>
                                                        </tr>';
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="header-title"><b><?php echo $charinfo->{'firstname'}; ?> <?php echo $charinfo->{'lastname'}; ?>'s Bank Statements (Deposit)</b></h4>
                                        <table class="mb-0 table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Time of Transaction</th>
                                                <th>Deposited</th>
                                                <th>Account Balance After</th>
                                                <th>Transaction Type</th>
                                            </tr>
                                        </thead>
                                            <tbody>
                                                <?php
                                                    $withdraw = $pdo->query("SELECT * FROM bank_statements WHERE citizenid='$citizenid' AND (withdraw = '0') ORDER BY record_id DESC");
                                                    foreach($withdraw as $newrow){
                                                        $depositedAmount = number_format($newrow['deposited']);
                                                        $balanceAfter = number_format($newrow['balance']);
                                                    
                                                    echo 
                                                        '<td>'. $newrow['date'] .'</td>
                                                        <td><b>$'. $depositedAmount .'</b></td>
                                                        <td>$'. $balanceAfter .'</td>
                                                        <td>'. $newrow['type'] .'</td>
                                                        </tr>';
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-5" role="tabpanel">
                        <?php if($playerOnline){ ?>
                        <div class="alert alert-warning fade show" role="alert"><b>WARNING:</b> <?php echo $charinfo->{'firstname'} ?> <?php echo $charinfo->{'lastname'} ?> (<?php echo $citizenid ?>) is currently logged in on the server with the server ID  <?php echo $OnlineServerID; ?>. This means that this inventory screen might not be a live viewing!</div>
                        <br>
                        <?php } ?>

                        <div class ="d-flex justify-content-center overflow-auto inventory-scroll-bar inventory-container">
                            <div class="d-flex justify-content-start flex-wrap inventory">
                                <?php
                                $citizenid = $_GET["citizenid"];
                                $inventory = $pdo->query("SELECT inventory FROM players WHERE citizenid = '$citizenid'");

                                foreach($inventory as $row){
                                    $fetchInventory = $row["inventory"];
                                    $inventoryItems = json_decode($fetchInventory);
                                    for($i = 1; $i <= PERSONAL_INV_SLOTS; $i++){
                                        $exists = false;
                                        foreach($inventoryItems as $row2){
                                            $itemname = $row2->{'name'};
                                            $itemamount = $row2->{'amount'};
                                            $itemslot = $row2->{'slot'};
                                            if($i==$itemslot){
                                                $exists = true;
                                                echo'
                                                <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'">
                                                    <div class="d-flex inventory-icon flex-column align-items-between" style="background-image: url(../assets/images/inventory/'.$itemname.'.png)">
                                                        <div class="d-flex justify-content-between inventory-details">
                                                            <div class="d-flex justify-content inventory-slot">'.$i.'</div>
                                                            <div class="d-flex justify-content-end inventory-item-quantity">x'.$itemamount.'</div>
                                                        </div>
                                                        <div class="d-flex justify-content-center align-items-end inventory-item-name">'.$itemname.'</div>
                                                    </div>
                                                </div>';
                                                break;
                                            }
                                        }
                                        if($exists == false){
                                            echo'
                                            <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'"> 
                                                <div class="d-flex inventory-slot">'.$i.'</div>
                                            </div>';
                                        }
                                    }
                                } ?>
                            </div>
                        </div>             
                    </div> 
                </div>
                <?php include "../inserts/insert_footer.php"; ?> 
            </div>
        </div>
    </div>
</div>
    <script type="text/javascript" src="../assets/scripts/main.js"></script>
</body>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/libs/morris-js/morris.min.js"></script>
</html>

<!------------------------->
<!-- Change Phone Number -->
<!------------------------->
<div class="modal fade" id="changeNumber" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Phone Number</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <?php
            if ($PERMchangePhoneNumber) { 
                if (!$playerOnline){?>
                <div class="changenumber">
                    <form class="" action="<?php echo PANEL_URL?>/functions/forms/char_changenumber.php?inventory=<?php echo $fetchInventory ?>" method="post">

                    <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Number</label>
                        <div class="col-sm-10"><input class="form-control" name="new_number" required="text" type="number" placeholder="##########" value="<?php echo $charinfo->{'phone'}; ?>"></div>
                    </div>
                    <input type="hidden" name="citizenid" value="<?php echo $citizenid ?>">

                    <!-- SUBMIT BUTTON -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Change Phone Number</button></div>
                    </div>
                    </form>
                </div>
                <?php
                } else{ ?>
                    <p>You have permission to change phone numbers but you cannot change the phone number while this player is online.</p>
                <?php }} else { ?>
                    <p>You do not have permission to change character phone numbers.</p>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changenumber form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changenumber form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changenumber form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/characters/info?citizenid=<?php echo $citizenid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!--------------------------------->
<!-- Change Bank Account Amounts -->
<!--------------------------------->
<div class="modal fade" id="changeBank" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Bank Amounts</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <?php
            if ($PERMchangeBankAmounts) { 
                if (!$playerOnline){?>
                <div class="changebank">
                    <form class="" action="<?php echo PANEL_URL?>/functions/forms/char_changebanks.php" method="post">

                    <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Bank</label>
                            <div class="col-sm-10"><input class="form-control" name="bank_amount" required="text" type="number" value="<?php echo $bank; ?>"></div>
                        </div>

                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Cash</label>
                            <div class="col-sm-10"><input class="form-control" name="cash_amount" required="text" type="number" value="<?php echo $cash; ?>"></div>
                        </div>

                        <?php if($savingsformatted !== "No Savings Account"){ ?>
                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Savings</label>
                            <div class="col-sm-10"><input class="form-control" name="savings_amount" required="text" type="number" value="<?php echo $savingsamount; ?>"></div>
                        </div>
                        <?php } ?>
                        <input type="hidden" name="citizenid" value="<?php echo $citizenid ?>">

                        <!-- SUBMIT BUTTON -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Update Bank Amounts</button></div>
                        </div>
                    </form>
                </div>
                <?php
                } else{ ?>
                    <p>You have permission to change bank amounts but you cannot change the bank amounts while this player is online.</p>
                <?php }} else { ?>
                    <p>You do not have permission to change character bank account amounts.</p>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changebank form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changebank form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changebank form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/characters/info?citizenid=<?php echo $citizenid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!--------------------------->
<!-- Change Character Name -->
<!--------------------------->
<div class="modal fade" id="changeName" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Character Name</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                if ($PERMchangeCharName) { 
                    if (!$playerOnline){?>
                    <div class="changename">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/char_changename.php" method="post">

                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Firstname</label>
                                <div class="col-sm-10"><input class="form-control" name="first_name" required="text" value="<?php echo $charinfo->{'firstname'}; ?>"></div>
                            </div>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Lastname</label>
                                <div class="col-sm-10"><input class="form-control" name="last_name" required="text" value="<?php echo $charinfo->{'lastname'}; ?>"></div>
                            </div>
                            <input type="hidden" name="citizenid" value="<?php echo $citizenid ?>">

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" name="change_name" value="Submit" class="btn btn-primary">Update Character Name</button></div>
                            </div>
                        </form>
                    </div>
                <?php
                } else{ ?>
                    <p>You have permission to change character names but you cannot change the character name while this player is online.</p>
                <?php }} else { ?>
                    <p>You do not have permission to change character names.</p>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changename form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changename form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changename form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/characters/info?citizenid=<?php echo $citizenid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!------------------------------>
<!-- Wipe Character Inventory -->
<!------------------------------>
<div class="modal fade" id="wipeInventory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Wipe Inventory</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                if ($PERMwipeInventory) { 
                    if (!$playerOnline){?>
                    <div class="wipeinventory">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/char_wipeinventory.php" method="post">
                            <p>Are you sure you want to <b>wipe the inventory of <?php echo $charinfo->{"firstname"} ?> <?php echo $charinfo->{"lastname"} ?>.</b> This means removing every item from their inventory and there is no going back.

                            <input type="hidden" name="citizenid" value="<?php echo $citizenid ?>">
                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Wipe Inventory</button></div>
                            </div>
                        </form>
                    </div>
                <?php
                } else{ ?>
                    <p>You have permission to wipe character inventories but you cannot wipe the inventory while this player is online.</p>
                <?php }} else { ?>
                    <p>You do not have permission to wipe character inventories.</p>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".wipeinventory form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".wipeinventory form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".wipeinventory form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/characters/info?citizenid=<?php echo $citizenid?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>