<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-right">
                <ul class="nav">
                    <li class="nav-item"><?php echo SERVER_NAME ?> &copy; <?php echo date("Y"); ?>. Made by <a href="https://github.com/aidanohart">aidanohart</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>    