<div class="app-header-right">
    <div class="header-btn-lg pr-0">
        <div class="widget-content p-0">
            <div class="widget-content-wrapper">
                
                <div class="widget-content-left  ml-3 header-user-info">
                    <div class="widget-rightheading"><?=$_SESSION['name']?></div>
                    <div class="widget-rightsubheading"><?=$_SESSION['groupname']?></div>
                </div>

                <div class="widget-content-left">
                    <div class="btn-group">
                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                            <img width="42" class="rounded-circle" src="<?php echo PANEL_URL; ?>/assets/images/avatars/<?=$_SESSION['avatar']?>" alt="">
                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                        </a>
                        <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                            <a href="<?php echo PANEL_URL; ?>/account" button type="button" tabindex="0" class="dropdown-item">Manage Account</button></a>
                            <div tabindex="-1" class="dropdown-divider"></div>
                            <a href="<?php echo PANEL_URL; ?>/functions/logout.php" button type="button" tabindex="0" class="dropdown-item">Log Out</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>        
</div>