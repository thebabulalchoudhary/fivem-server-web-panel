<?php
$mygroup = $_SESSION["group"];
$seePanelManagementTitle = false;  
$PERMstaffManager = false;
$PERMgroupManager = false;
$PERMauditlog = false;
$navperms = $pdo->query("SELECT groupmanager,staffmanager,auditlog FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($navperms as $row){
    if ($row["groupmanager"] == 1){
        $PERMgroupManager = true;
        $seePanelManagementTitle = true;
    }
    if ($row["staffmanager"] == 1){
        $PERMstaffManager = true;
        $seePanelManagementTitle = true;
    }
    if ($row["auditlog"] == 1){
        $PERMauditlog = true;
        $seePanelManagementTitle = true;
    }
}



$onlineplayersnav = "";
if(SHOW_PLAYERS_ONLINE){
    $json = file_get_contents('http://'.SERVER_IP.':'.SERVER_PORT.'/players.json');
    $data = json_decode($json, true);
    $Stat3 = 0;
    foreach($data as $row){
        $Stat3++;
    }
    $onlineplayersnav = "(".$Stat3.")";
}
?>
<div class="scrollbar-sidebar">
    <div class="app-sidebar__inner">
        <ul class="vertical-nav-menu">
            
        <li class="app-sidebar__heading">General</li>

            <li><a href="<?php echo PANEL_URL ?>/dashboard"><i class="metismenu-icon pe-7s-home"></i>Dashboard</a></li>

            <li class="app-sidebar__heading">Out-Of-Character Management</li>

                <li><a href="<?php echo PANEL_URL ?>/players/search"><i class="metismenu-icon pe-7s-users"></i>Search All Players</a></li>

                <li><a href="<?php echo PANEL_URL ?>/onlineplayers"><i class="metismenu-icon pe-7s-drawer"></i>Currently Online <?php echo $onlineplayersnav; ?></a></li>

                <li><a href=""><i class="metismenu-icon pe-7s-diamond"></i>All Player Punishments<i class="metismenu-state-icon pe-7s-angle-down caret-left"></i></a>
                <ul>
                    <li><a href="<?php echo PANEL_URL ?>/punishments/bans"><i class="metismenu-icon"></i>Player Bans</a></li> 
                    <li><a href="<?php echo PANEL_URL ?>/punishments/kicks"><i class="metismenu-icon"></i>Player Kicks</a></li>  
                    <li><a href="<?php echo PANEL_URL ?>/punishments/notes"><i class="metismenu-icon"></i>Player Notes</a></li>
                </ul>

                <li><a href="<?php echo PANEL_URL ?>/disconnections"><i class="metismenu-icon pe-7s-delete-user"></i>Recent Disconnections</a></li>

            <li class="app-sidebar__heading">In-Character Management</li>

                <li><a href="<?php echo PANEL_URL ?>/characters/search"><i class="metismenu-icon pe-7s-users"></i>View all Characters</a></li>

                <li><a href="<?php echo PANEL_URL ?>/vehicles/list"><i class="metismenu-icon pe-7s-car"></i>View all Vehicles</a>

                <li><a href=""><i class="metismenu-icon pe-7s-home"></i>View all Properties<i class="metismenu-state-icon pe-7s-angle-down caret-left"></i></a>
                <ul>
                    <li><a href="<?php echo PANEL_URL ?>/properties/search"><i class="metismenu-icon"></i>All properties</a></li>
                    <li><a href="<?php echo PANEL_URL ?>/apartments/search"><i class="metismenu-icon"></i>All Apartments</a></li>
                </ul>

                <li><a href=""><i class="metismenu-icon pe-7s-folder"></i>View all Occupations<i class="metismenu-state-icon pe-7s-angle-down caret-left"></i></a>
                <ul>
                    <li><a href="<?php echo PANEL_URL ?>/occupations/jobs/search"><i class="metismenu-icon"></i>All Jobs</a></li>
                    <li><a href="<?php echo PANEL_URL ?>/occupations/gangs/search"><i class="metismenu-icon"></i>All Gangs</a></li>
                </ul>

                <li><a href=""><i class="metismenu-icon pe-7s-diamond"></i>Leaderboards<i class="metismenu-state-icon pe-7s-angle-down caret-left"></i></a>  
                <ul>
                    <li><a href="<?php echo PANEL_URL ?>/leaderboards/richestcharacters"><i class="metismenu-icon"></i>Richest Characters</a></li> 
                    <li><a href="<?php echo PANEL_URL ?>/leaderboards/playtime"><i class="metismenu-icon"></i>Most Playtime</a></li>
                </ul>
            </li>

            <?php
            if ($seePanelManagementTitle) { ?>
                <li class="app-sidebar__heading">Panel Management</li>
            <?php
            }
            ?>

            <?php
            if ($PERMstaffManager) { ?>
                <li><a href="<?php echo PANEL_URL ?>/settings/staff/manage"><i class="metismenu-icon pe-7s-users"></i>Manage Staff</a></li>
            <?php
            } 
            ?>

            <?php
            if ($PERMgroupManager) { ?>
                <li><a href="<?php echo PANEL_URL ?>/settings/groups/manage"><i class="metismenu-icon pe-7s-menu"></i>Manage Staff Groups</a></li>
            <?php
            } 
            ?>

            <?php
            if ($PERMauditlog) { ?>
                <li><a href="<?php echo PANEL_URL ?>/settings/auditlog"><i class="metismenu-icon pe-7s-shield"></i>Audit Log</a></li>
            <?php
            } 
            ?>
            </li>
        </div>
    </div>
</div>   