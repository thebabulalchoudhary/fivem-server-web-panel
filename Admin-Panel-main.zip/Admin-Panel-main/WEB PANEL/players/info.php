<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

//////////////////////////////////
// Variables & Player data code //
//////////////////////////////////
$usersession = $_GET["playerId"];
$result = $pdo->query("SELECT * FROM adminpanel_players WHERE ID = '$usersession'");
foreach($result as $row) 
{
    $userID = $row["id"];
    $playername = $row["playername"];
    $discord = $row["discord"];
    $steam = $row["steam"];
    $license = $row["license"];
    $firstjoin = $row["firstjoin"];
    $firstjoinformatted = gmdate("Y-m-d H:i:s", $firstjoin);
    $playtime = $row["playtime"];

    $d = floor ($playtime / 1440);
    $h = floor (($playtime - $d * 1440) / 60);
    $m = $playtime - ($d * 1440) - ($h * 60);
}

//////////////////////////////////////////////////////
// Check if player is online for kick functionality //
//////////////////////////////////////////////////////
$playerOnline = false;
$serverConnection = file_get_contents('http://'.SERVER_IP.':'.SERVER_PORT.'/players.json');
$serverData = json_decode($serverConnection, true);
foreach($serverData as $row) 
{
    $identifiersArray = $row["identifiers"];
    $identifiers = json_encode($identifiersArray);
    $split = explode(",", $identifiers);
    foreach($split as $row2){
        if(strpos($row2, "license:") !== false){
            $onlineLicense = substr($row2, 1, -1);
            if($onlineLicense == $license){
                $playerOnline = true;
                $OnlineServerID = $row["id"];
                break;
            }
        }
    }
}

$banid = generateBanID(); // Ban ID Variable so everything syncs

/////////////////////////////////////////////////
// Staff Permissions for the players/info Page //
/////////////////////////////////////////////////
$mygroup = $_SESSION['group']; 
$PERMcreateNote = false; 
$perm = $pdo->query("SELECT * FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row['createnote'] == "1"){
        $PERMcreateNote = true;
    } else {
        $PERMcreateNote = false;
    }
}

$PERMcreateBans = false;
$perm2 = $pdo->query("SELECT * FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm2 as $row){
    if ($row['submitban'] == "1"){
        $PERMcreateBans = true;
    } else {
        $PERMcreateBans = false;
    }
}

$PERMcreateKicks = false;
$perm2 = $pdo->query("SELECT * FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm2 as $row){
    if ($row['submitkick'] == "1"){
        $PERMcreateKicks = true;
    } else {
        $PERMcreateKicks = false;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Player Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
                <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-id icon-gradient qb-core">
                                </i>
                            </div>
                                <div>Player Information - <?php echo $playername; ?>(Player ID: <?php echo $userID; ?>)
                                    <div class="page-title-subheading">This page displays information on a specific player. If nothing shows go back to the Search Players tab and try again.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if($playerOnline){ ?>
                <div class="card text-center">
                    <div class="card-header">
                        <div class="card-body">
                            This player is currently online (ID: <?php echo $OnlineServerID; ?>)
                        </div>
                    </div>
                </div>
                <br>
                <?php } ?>

                <div class="tab-content">
                <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="card text-center">
                                <div class="card-header">General Information (Out-Of-Character)</div>
                                    <div class="card-body">
                                    <p><b>Player Name: </b><?php echo $playername; ?> </p>
                                    <p><b>Discord: </b><?php echo $discord; ?> </p>
                                    <p><b>Rockstar: </b><?php echo $license; ?> </p>
                                    <p><b>Steam: </b><?php echo $steam; ?></p>
                                    <p><b>Playtime: </b><?php echo $d; ?> Days, <?php echo $h; ?> Hours, <?php echo $m; ?> Minutes</p>
                                    <p><b>First Joined: </b><?php echo $firstjoinformatted; ?> </p>
                                </div>
                            </div>
                        </div>
                        <div class="main-card col-lg-4 mb-9 card"> <!-- TABLE -->
                            <div class="card-header">List Of <?php echo $playername; ?>'s Characters</div>
                                <div class="card-body no-padding"><h5 class="card-title"></h5>
                                    <table class="mb-0 table table-hover">
                                        <thead>
                                            <th>Character Name</th>
                                            <th>Citizen ID</th>
                                            <th>Last Active</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $character = $pdo->query("SELECT * FROM players WHERE license='$license'");
                                                foreach($character as $newrow){
                                                    $json = $newrow["charinfo"];
                                                    $charactername = json_decode($json);

                                                echo
                                                '<tr>
                                                <td><a id="accentcolor" href="'.PANEL_URL.'/characters/info?citizenid=' . $newrow['citizenid'] . '">'. $charactername->{'firstname'}. ' '.$charactername->{'lastname'}. '</td>
                                                <td>'. $newrow['citizenid'] .'</td>
                                                <td>'. $newrow['last_updated'] .'</td>
                                                </tr>';
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-lg-4">
                            <div class="card text-center">
                                <div class="card-header">Manage User Punishments</div>
                                    <div class="card-body">
                                    <a href="" button data-toggle="modal" data-target="#createBan" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">BAN PLAYER</a></button>
                                    <a href="" button data-toggle="modal" data-target="#createKick" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">KICK PLAYER</a></button>
                                    <a href="" button data-toggle="modal" data-target="#createNote" button class="mb-2 mr-2 btn-transition btn btn-outline-primary btn-block">CREATE NEW NOTE</a></button>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="main-card mb-9 card"> <!-- TABLE -->
                <div class="card-header">List Of <?php echo $playername; ?>'s Notes</div>
                    <div class="card-body"><h5 class="card-title"></h5>
                        <table class="mb-0 table table-hover">
                            <thead>
                            <tr>
                                <th>Note Issued</th>
                                <th>Punished By</th>
                                <th>Note Reason</th>
                                <th>Manage Note</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                            <?php
                                $note = $pdo->query("SELECT * FROM adminpanel_notes WHERE punished_player='$userID' ORDER BY punished_time DESC");
                                foreach($note as $newrow){
                                    $staffid = $newrow['punished_by'];
                                    $punishedtimeformatted = gmdate("Y-m-d H:i:s", $newrow['punished_time']);

                                $note2 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$staffid'");
                                foreach($note2 as $newrow2){
                                    $staffname = $newrow2["username"];
                                }
                                
                                echo 
                                '<td>'. $punishedtimeformatted .'</td>
                                <td><a href="staffInfo?staffId=' . $newrow['punished_by'] . '">'. $staffname.'</td>
                                <td>'. $newrow['punish_reason'] .'</td>
                                <td><a href="'.PANEL_URL.'/punishments/manage/note?noteId='.$newrow['noteid'].'"><button class="mb-1 mr-1 btn-transition btn btn-small btn-outline-primary">Manage Note</button></a></div></td>
                                </tr>';
                                }
                            ?>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <br>
                <div class="main-card mb-9 card"> <!-- TABLE -->
                <div class="card-header">List Of <?php echo $playername; ?>'s Kicks</div>
                    <div class="card-body"><h5 class="card-title"></h5>
                        <table class="mb-0 table table-hover">
                            <thead>
                            <tr>
                                <th>Kick ID</th>
                                <th>Kicked By</th>
                                <th>Kick Issued</th>
                                <th>Kick Reason</th>
                                <th>Manage Kick</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $uniquekick = $pdo->query("SELECT * FROM adminpanel_kicks WHERE kicked_player='$userID'");
                                foreach($uniquekick as $newrow){
                                $kickid = $newrow["ID"];
                                $kicked_player_id = $newrow['kicked_player'];
                                $punishedbyid = $newrow['punishedby'];
                                $reason = $newrow["kickreason"];
                                $timestamp = gmdate("Y-m-d H:i:s", $newrow['kicktime']);

                                $uniquekick2 = $pdo->query("SELECT * FROM adminpanel_players WHERE id='$kicked_player_id'");
                                foreach($uniquekick2 as $newrow2){$kickedplayername = $newrow2["playername"];}

                                $uniquekick3 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$punishedbyid'");
                                foreach($uniquekick3 as $newrow3){$staffkickedname = $newrow3["username"];}

                                echo 
                                '<td>'. $kickid .'</td>
                                <td><a href="staffInfo?staffId=' . $punishedbyid . '">'. $staffkickedname.'</td>
                                <td>'. $timestamp .'</td>
                                <td>'. $reason .'</td>
                                <td><a href="'.PANEL_URL.'/punishments/manage/kick?kickId='.$kickid.'"><button class="mb-1 mr-1 btn-transition btn btn-small btn-outline-primary">Manage Kick</button></a></div></td>
                                </tr>';
                                }
                            ?>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <br>
                <div class="main-card mb-9 card"> <!-- TABLE -->
                <div class="card-header">List Of <?php echo $playername; ?>'s Bans</div>
                    <div class="card-body"><h5 class="card-title"></h5>
                        <table class="mb-0 table table-hover">
                            <thead>
                            <tr>
                                <th>Ban ID</th>
                                <th>Banned By</th>
                                <th>Ban Issued</th>
                                <th>Banned Until</th>
                                <th>Ban Reason</th>
                                <th>Manage Ban</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $currentime = time();

                                $uniqueban = $pdo->query("SELECT * FROM adminpanel_bans WHERE userid='$usersession'");
                                foreach($uniqueban as $newrow){
                                $userbannedid = $newrow["userid"];
                                $bannedbyid = $newrow['bannedby'];
                                $banissued = $newrow['ban_issued'];
                                $banneduntil = $newrow["banned_until"];
                                if ($banneduntil == "0") {
                                    $banlengthformatted = "Permenant";
                                } else {
                                    $banlengthformatted = gmdate("Y-m-d H:i:s", $banneduntil);
                                }

                                $banissuedformatted = gmdate("Y-m-d H:i:s", $banissued);

                                $uniqueban2 = $pdo->query("SELECT * FROM adminpanel_players WHERE id='$userbannedid'");
                                foreach($uniqueban2 as $newrow2){$userbannedname = $newrow2["playername"];}

                                $uniqueban3 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$bannedbyid'");
                                foreach($uniqueban3 as $newrow3){$staffbaname = $newrow3["username"];}

                                echo 
                                '<td>'. $newrow['banid'] .'</td>
                                <td><a href="staffInfo?staffId=' . $newrow['bannedby'] . '">'. $staffbaname.'</td>
                                <td>'. $banissuedformatted .'</td>
                                <td>'. $banlengthformatted .'</td>
                                <td>'. $newrow['reason'] .'</td>
                                <td><a href="'.PANEL_URL.'/punishments/manage/ban?banId='.$newrow['banid'].'"><button class="mb-1 mr-1 btn-transition btn btn-small btn-outline-primary">Manage Ban</button></a></div></td>
                                </tr>';
                                }
                            ?>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            <!-- FOOTER -->
            <?php include "../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>
<script type="text/javascript" src="../assets/scripts/main.js"></script></body>
<script src="../assets/js/vendor.min.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/morris-js/morris.min.js"></script>
</html>

<!----------------->
<!-- Create Note -->
<!----------------->
<div class="modal fade" id="createNote" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create New Note</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <?php
                if ($PERMcreateNote) { ?>
                    <div class="createnote">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/user_note.php" method="post">

                        <h5 class="card-title">User Details</h5>
                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Player</label>
                                <div class="col-sm-10"><input class="form-control" name="player_name" value="<?php echo $playername ?>" readonly></div>
                            </div>
                            
                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Player ID</label>
                                <div class="col-sm-10"><input class="form-control" name="player_id" value="<?php echo $userID ?>" readonly></div>
                            </div>

                            <h5 class="card-title">Note Details</h5>
                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Reason</label>
                                <div class="col-sm-10"><input class="form-control" name="note_reason" required="text" placeholder="Remember to include your note reason!"></div>
                            </div>

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Create Note</button></div>
                            </div>
                        </form>
                    </div>
                <?php
                } else { ?>
                    <p>You do not have permission to create notes.</p>
                <?php }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".createnote form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".createnote form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".createnote form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/players/info?playerId=<?php echo $usersession?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!---------------->
<!-- Create Ban -->
<!---------------->
<div class="modal fade" id="createBan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Submit New Ban</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <?php
                if ($PERMcreateBans) { ?>
                    <div class="createban">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/user_ban.php" method="post">

                        <h5 class="card-title">User Details</h5>
                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Player</label>
                                <div class="col-sm-10"><input class="form-control" name="player_name" value="<?php echo $playername ?>" readonly></div>
                            </div>
                            
                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Player ID</label>
                                <div class="col-sm-10"><input class="form-control" name="player_id" value="<?php echo $userID ?>" readonly></div>
                            </div>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Rockstar License</label>
                                <div class="col-sm-10"><input class="form-control" name="rockstar" value="<?php echo $license ?>" readonly></div>
                            </div>

                            <h5 class="card-title">BAN LENGTH</h5>
                            <h5 class="card-subtitle">If you want to permenantly ban the user, leave days and hours as 0</h5>
                            
                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Days</label>
                                <div class="col-sm-10"><input class="form-control" name="ban_days" type="number" required="text" placeholder="How many days do you want to ban the user for?"></div>
                            </div>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Hours</label>
                                <div class="col-sm-10"><input class="form-control" name="ban_hours" type="number" required="text" placeholder="How many hours would you like to add?"></div>
                            </div>

                            <h5 class="card-title">BAN INFORMATION</h5>
                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Ban ID</label>
                                <div class="col-sm-10"><input class="form-control" name="ban_id" value="<?php echo $banid ?>" readonly></div>
                            </div>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Ban Reason</label>
                                <div class="col-sm-10"><input class="form-control" name="ban_reason" required="text" placeholder="Why is the user being banned?"></div>
                            </div>

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Submit Ban</button></div>
                            </div>
                        </form>
                    </div>
                <?php
                } else { ?>
                    <p>You do not have permission to create bans.</p>
                <?php }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".createban form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".createban form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".createban form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/players/info?playerId=<?php echo $usersession?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>

<!-- Kick Player -->
<div class="modal fade" id="createKick" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Kick Player</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php 
                if ($PERMcreateKicks){
                    if ($playerOnline){
                    ?>
                    <div class="kickplayer">
                        <form class="" action="<?php echo PANEL_URL?>/functions/forms/user_kick.php?playerId=<?php echo $usersession ?>" method="post">

                        <h5 class="card-title">User Details</h5>
                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Player</label>
                                <div class="col-sm-10"><input class="form-control" name="player_name" value="<?php echo $playername ?>" readonly></div>
                            </div>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Rockstar License</label>
                                <div class="col-sm-10"><input class="form-control" name="rockstar" value="<?php echo $license ?>" readonly></div>
                            </div>

                            <h5 class="card-title">KICK INFORMATION</h5>

                            <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Kick Reason</label>
                                <div class="col-sm-10"><input class="form-control" name="kick_reason" required="text" placeholder="Why is the user being kicked?"></div>
                            </div>

                            <!-- SUBMIT BUTTON -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Kick Player</button></div>
                            </div>
                        </form>
                    </div>
                    <?php
                    } else{ ?>
                        <p>This player is not online.</p>
                    <?php } ?>
                <?php
                } else{ ?>
                    <p>You do not have permission to kick players.</p>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".kickplayer form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".kickplayer form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".kickplayer form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/players/info?playerId=<?php echo $usersession?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>