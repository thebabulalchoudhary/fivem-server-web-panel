<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Richest Characters</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
            <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-cash icon-gradient qb-core">
                            </i>
                        </div>
                            <div>Richest Characters
                                <div class="page-title-subheading">This page displays the top 10 richest characters on your server.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content">
            <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card text-center">
                            <div class="card-header">Richest Characters (BANK)</div>
                                <div class="card-body">
                                    <table class="mb-0 table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Character Name</th>
                                            <th>Bank Account Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $bankaccount = $pdo->query("SELECT citizenid,money,charinfo, JSON_EXTRACT(money, '$.bank') AS bank FROM players ORDER BY bank+0 DESC LIMIT 14");
                                            foreach($bankaccount as $newrow){
                                                $bank = $newrow['bank'];
                                                $floatbank = floatval($bank);
                                                $bankformatted = number_format($floatbank);
                                                $cid = $newrow['citizenid'];
                                                $jsoncharinfo = $newrow["charinfo"];
                                                $charinfo = json_decode($jsoncharinfo);

                                            echo 
                                            '<tr>
                                            <td><a id="accentcolor" href="'.PANEL_URL.'/characters/info.php?citizenid=' . $cid . '">'. $charinfo->{'firstname'}. ' '.$charinfo->{'lastname'}. ' ('. $cid.')</td>
                                            <td>$'.$bankformatted.'</td>
                                            </tr>';
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card text-center">
                            <div class="card-header">Richest Characters (Cash)</div>
                                <div class="card-body">
                                <table class="mb-0 table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Character Name</th>
                                            <th>Cash Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $bankaccount = $pdo->query("SELECT citizenid,money,charinfo, JSON_EXTRACT(money, '$.cash') AS cash FROM players ORDER BY cash+0 DESC LIMIT 14");
                                            foreach($bankaccount as $newrow){
                                                $cash = $newrow["cash"];
                                                $floatcash = floatval($cash);
                                                $cashformatted = number_format($floatcash);
                                                $cid = $newrow['citizenid'];
                                                $jsoncharinfo = $newrow["charinfo"];
                                                $charinfo = json_decode($jsoncharinfo);

                                            echo 
                                            '<tr>
                                            <td><a id="accentcolor" href="'.PANEL_URL.'/characters/info.php?citizenid=' . $cid . '">'. $charinfo->{'firstname'}. ' '.$charinfo->{'lastname'}. ' ('. $cid.')</td>
                                            <td>$'.$cashformatted.'</td>
                                            </tr>';
                                            }
                                        ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card text-center">
                            <div class="card-header">Richest Characters (Savings)</div>
                                <div class="card-body">
                                <table class="mb-0 table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Character Name</th>
                                            <th>Savings Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $bankaccount = $pdo->query("SELECT * FROM bank_accounts ORDER BY CAST(amount AS INTEGER) DESC LIMIT 14");
                                            foreach($bankaccount as $newrow){
                                                $cash = $newrow['amount'];
                                                $floatcash = floatval($cash);
                                                $cashformatted = number_format($floatcash);
                                                $cid = $newrow['citizenid'];
                                                $charactername = $pdo->query("SELECT citizenid,charinfo FROM players WHERE citizenid = '$cid'");
                                                foreach($charactername as $newrow2){
                                                    $jsoncharinfo = $newrow2["charinfo"];
                                                    $charinfo = json_decode($jsoncharinfo);
                                                }


                                            echo 
                                            '<tr>
                                            <td><a id="accentcolor" href="'.PANEL_URL.'/characters/info.php?citizenid=' . $cid . '">'. $charinfo->{'firstname'}. ' '.$charinfo->{'lastname'}. ' ('. $cid.')</td>
                                            <td>$'.$cashformatted.'</td>
                                            </tr>';
                                            }
                                        ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <!-- FOOTER -->
            <?php include "../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>
<script type="text/javascript" src="../assets/scripts/main.js"></script></body>
<script src="../assets/js/vendor.min.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/morris-js/morris.min.js"></script>
</html>
