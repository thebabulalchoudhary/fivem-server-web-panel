<?php
session_start();

try {
	$pdo = new PDO('mysql:host=' . db_host . ';dbname=' . db_name . ';charset=' . db_charset, db_user, db_pass);
} catch (PDOException $exception) {
	exit('Connection failed: ' . $exception->getMessage());
}

function CheckUserLoggedIn($pdo) {
	$stmt = $pdo->prepare('SELECT * FROM adminpanel_staff WHERE id = ? AND active = ?');
	$stmt->execute([ $_SESSION['id'], 1 ]);
	$account = $stmt->fetch(PDO::FETCH_ASSOC);
	if ($account) {
		session_regenerate_id();
		$_SESSION['loggedin'] = TRUE;
		$_SESSION['name'] = $account['username'];
		$_SESSION['id'] = $account['id'];
		$_SESSION['group'] = $account['groupid'];
		$_SESSION['discord'] = $account['discord'];
		$_SESSION['rockstar'] = $account['rockstar'];
		$_SESSION['avatar'] = $account['avatar'];
		$_SESSION['passwordchanges'] = $account['passwordchanges'];

		/* TRANSLATE GROUP PRIMARY KEY INTO THE GROUP NAME */
		$groupid2 = $account['groupid'];
		$groupnamequery = $pdo->query("SELECT * FROM adminpanel_groups WHERE id='$groupid2'");
		foreach($groupnamequery as $row){
			$groupname = $row["groupname"];
		}
		$_SESSION['groupname'] = $groupname; /* THEN WE WANT TO MAKE A SESSION VARIABLE LIKE SO */
	} else {
		session_start();
		session_destroy();
		if (isset($_COOKIE['rememberme'])) {
			unset($_COOKIE['rememberme']);
			setcookie('rememberme', '', time() - 3600);
		}
		header("Location: ".PANEL_URL."");
	}
}

function CheckFirstTimeLogin(){
	if($_SESSION['passwordchanges'] == 0){
		header("Location: ".PANEL_URL."/changepassword");
	}
}

function generateBanID($length = 7) {
    $characters = '123456789ABCDEFGHJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>