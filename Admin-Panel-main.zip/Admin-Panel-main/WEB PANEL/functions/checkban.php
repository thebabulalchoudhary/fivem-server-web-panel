<?php
include '../config/config.php';
include 'main.php';

$rockstar = htmlspecialchars($_GET['license']);
$currentime = time();

$result = $pdo->query("SELECT * FROM adminpanel_bans WHERE license='$rockstar' AND active='1' AND (banned_until >='$currentime' OR banned_until ='0')");
$playerbanned = false;
foreach($result as $row)
{
	$bannedby = $row["bannedby"];
	$banneduntil = $row["banned_until"];
	if ($banneduntil == "0") {
        $banlengthformatted = "Permenant";
    } else {
        $banlengthformatted = gmdate("Y-m-d H:i:s", $banneduntil);
    }

	$result2 = $pdo->query("SELECT * FROM adminpanel_staff WHERE id='$bannedby'");
	foreach($result2 as $row2){$bannedbyname = $row2["username"];}

	$playerbanned = true;
	echo json_encode(array(
		"banned" => "true",
		"banid" => $row["banid"],
		"bannedby" => $bannedbyname,
		"reason" => $row["reason"],
		"banexpires" => $banlengthformatted,
	));
}

if($playerbanned == false)
{
	echo json_encode(array(
		"banned" => "false",
	));
}
?>