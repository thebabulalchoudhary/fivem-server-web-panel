<?php
include '../config/config.php';
include 'main.php';

session_start();
session_destroy();
if (isset($_COOKIE['rememberme'])) {
    unset($_COOKIE['rememberme']);
    setcookie('rememberme', '', time() - 3600);
}

header('Location: '.PANEL_URL.'');
?>
