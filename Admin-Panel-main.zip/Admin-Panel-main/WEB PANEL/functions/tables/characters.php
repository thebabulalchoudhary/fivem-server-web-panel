<?php
include '../../config/config.php';
require( 'ssp.class.php' );

$sql_details = array('user' => db_user,'pass' => db_pass,'db' => db_name, 'host' => db_host);
$table = 'players';
$primaryKey = 'citizenid';

$columns = array(
    array( 'db' => 'citizenid', 'dt' => 0),
    array( 'db' => 'charinfo', 'dt' => 1),
    array(
        'db'        => 'license',
        'dt'        => 2,
        'formatter' => function( $d, $row ) {
            try {
            $pdo = new PDO('mysql:host=' . db_host . ';dbname=' . db_name . ';charset=' . db_charset, db_user, db_pass);} catch (PDOException $exception) {exit('Failed to connect to database!');}
            $result = $pdo->query("SELECT id FROM adminpanel_players WHERE license='$d'");
            foreach($result as $row){
                $playerid = $row["id"];
            }

            return $playerid;
        }  
    ),
    array( 'db' => 'charinfo', 'dt' => 3),
    array( 'db' => 'license', 'dt' => 4),
    array( 'db' => 'last_updated', 'dt' => 5),
    array(
        'db'        => 'license',
        'dt'        => 6,
        'formatter' => function( $d, $row ) {
            try {
            $pdo = new PDO('mysql:host=' . db_host . ';dbname=' . db_name . ';charset=' . db_charset, db_user, db_pass);} catch (PDOException $exception) {exit('Failed to connect to database!');}
            $result = $pdo->query("SELECT playername FROM adminpanel_players WHERE license='$d'");
            foreach($result as $row){
                $playername = $row["playername"];
            }

            return $playername;
        }  
    ),
);
 
echo json_encode(SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns ));
