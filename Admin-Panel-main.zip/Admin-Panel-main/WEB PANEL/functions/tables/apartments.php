<?php
include '../../config/config.php';
require( 'ssp.class.php' );

$sql_details = array('user' => db_user,'pass' => db_pass,'db' => db_name, 'host' => db_host);
$table = 'apartments';
$primaryKey = 'id';

$columns = array(
    array( 'db' => 'id', 'dt' => 0),
    array( 'db' => 'label', 'dt' => 1),
    array(
        'db'        => 'citizenid',
        'dt'        => 2,
        'formatter' => function( $d, $row ) {
            try {
            $pdo = new PDO('mysql:host=' . db_host . ';dbname=' . db_name . ';charset=' . db_charset, db_user, db_pass);} catch (PDOException $exception) {exit('Failed to connect to database!');}
            $result = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$d'");
            foreach($result as $row){
                $jsoncharinfo = $row["charinfo"];
                $charinfo = json_decode($jsoncharinfo);
                $charfirst = $charinfo->{'firstname'}; 
                $charlast = $charinfo->{'lastname'};
            }

            return $charfirst." ".$charlast." (".$d.")";
        }  
    ),
    array( 'db' => 'type', 'dt' => 3),
    array( 'db' => 'citizenid', 'dt' => 4),
);
 
echo json_encode(SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns ));
