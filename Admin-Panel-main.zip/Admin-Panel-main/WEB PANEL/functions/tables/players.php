<?php
include '../../config/config.php';
require( 'ssp.class.php' );

$sql_details = array('user' => db_user,'pass' => db_pass,'db' => db_name, 'host' => db_host);
$table = 'adminpanel_players';
$primaryKey = 'id';

$columns = array(
    array( 'db' => 'id', 'dt' => 0),
    array( 'db' => 'playername', 'dt' => 1),
    array( 'db' => 'license', 'dt' => 2),
    array( 'db' => 'discord', 'dt' => 3),
    array( 'db' => 'steam', 'dt' => 4),
    array(
        'db'        => 'firstjoin',
        'dt'        => 5,
        'formatter' => function( $d, $row ) {
            return gmdate("Y-m-d H:i:s", $d);;
        }  
    ),
);
 
echo json_encode(SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns ));
