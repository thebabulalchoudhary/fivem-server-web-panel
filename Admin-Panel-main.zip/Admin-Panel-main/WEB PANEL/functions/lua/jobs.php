<?php
include '../../config/config.php';

function parse_json_txt($s) {
    $s = str_replace(array('"',  "'"), array('"', '"'), $s);
    $s = preg_replace('/(\w+):/i', '"\1":', $s);

    return json_decode($s, true);
}

$luaFileContent = file_get_contents(PANEL_URL."/config/shared/jobs.lua");
$contentParts = explode("QBShared.Jobs =", $luaFileContent);

$objectContent = $contentParts[1];

$objectContent = str_replace("[", "", $objectContent);
$objectContent = str_replace("]", "", $objectContent);
$objectContent = str_replace("=", ":", $objectContent);
$objectContent = str_replace("'", '"', $objectContent);
$objectContent = str_replace(" :", ':', $objectContent);
$objectContent = preg_replace("/}([^,]*),[\S]*([^,]*)}/", '}\1\2}', $objectContent);
$objectContent = preg_replace("/}([^,]*),[\S]*([^,]*)}/", '}\1\2}', $objectContent);
$objectContent = preg_replace("/}([^,]*),[\S]*([^,]*)}/", '}\1\2}', $objectContent);

$jsonObj = parse_json_txt($objectContent);

$jobsList = array();

foreach ($jsonObj as $key=>$value){
    $job = array();
    $job['job_name'] = $key;
    $job['job_label'] = $value['label'];
    $job['job_grades'] = $value['grades'];
    $jobsList[] = $job;
}

/* echo "<pre>";
print_r($jobsList); */
?>