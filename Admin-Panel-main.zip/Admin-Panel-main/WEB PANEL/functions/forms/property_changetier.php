<?php
include '../../config/config.php';
include '../main.php';

$propertyId = htmlentities($_POST['propertyid']);
$staffid = $_SESSION["id"];

$result2 = $pdo->query("SELECT * FROM houselocations WHERE id = '$propertyId'");
foreach($result2 as $row2) {
    $propertyTier = $row2["tier"];
}

$propertyTierUpdated = htmlentities($_POST['property_tier']);
$pdo->query("UPDATE houselocations SET tier = '$propertyTierUpdated' WHERE id='$propertyId'");


$auditlogdata = array('tierbefore' => $propertyTier, 'tierafter' => $propertyTierUpdated);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "property_changetier", $staffid, $propertyId, json_encode($auditlogdata)]);

// Send Discord Web Hook
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = PROPERTY_TIER_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "PROPERTY TIER CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "PROPERTY TIER CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed a property tier",
            "url" => "$starturl/properties/info?propertyId=$propertyId",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Property ID",
                    "value" => "$propertyId",
                    "inline" => true
                ],
                [
                    "name" => "Tier Before / After",
                    "value" => "Tier $propertyTier / Tier $propertyTierUpdated",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>