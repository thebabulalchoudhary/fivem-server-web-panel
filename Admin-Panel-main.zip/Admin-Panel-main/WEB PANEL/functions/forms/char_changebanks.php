<?php
include '../../config/config.php';
include '../main.php';

$citizenid = htmlentities($_POST['citizenid']);
$staffid = $_SESSION["id"];

$JsonQuery2 = $pdo->query("SELECT * FROM players WHERE citizenid = '$citizenid'");
foreach($JsonQuery2 as $row){
    $moneyInfo = $row["money"];
    $data = json_decode($moneyInfo);
    $moneybefore = $data->{"cash"}; $moneybeforeformatted = number_format($moneybefore);
    $bankbefore = $data->{"bank"}; $bankbeforeformatted = number_format($bankbefore);
}

$JsonQuery3 = $pdo->query("SELECT * FROM bank_accounts WHERE citizenid = '$citizenid'");
$savingsbefore = "NO SAVINGS"; $savingsbeforeformatted = "NO SAVINGS";
if($JsonQuery3->rowCount() > 0){
    foreach($JsonQuery3 as $row2){
        $savingsbefore = $row2["amount"];
        $savingsbeforeformatted = number_format($savingsbefore);
    }
}

$cashUpdated = htmlentities($_POST['cash_amount']);
$bankUpdated = htmlentities($_POST['bank_amount']);
$savingsUpdated = htmlentities($_POST['savings_amount']);

$castedCash = floatval($cashUpdated); $newCashFormatted = number_format($castedCash);
$castedBank = floatval($bankUpdated); $newBankFormatted = number_format($castedBank);
$castedSavings = floatval($savingsUpdated); $newSavingsFormatted = number_format($castedSavings);

$moneyArray = array('cash' => $castedCash, 'bank' => $castedBank);
$newJsonString = json_encode($moneyArray);

$pdo->query("UPDATE players SET money = '$newJsonString' WHERE citizenid='$citizenid'");
$pdo->query("UPDATE bank_accounts SET amount = '$castedSavings' WHERE citizenid='$citizenid'");

$auditlogdata = array('cashbefore' => $moneybefore, 'bankbefore' => $bankbefore, 'savingsbefore' => $savingsbefore);
$auditlogdata2 = array('cashafter' => $castedCash, 'bankafter' => $castedBank, 'savingsafter' => $castedSavings);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data, data2) VALUES (?,?,?,?,?,?)');
$stmt2->execute([time(), "change_bank", $staffid, $citizenid, json_encode($auditlogdata), json_encode($auditlogdata2)]);

// Send Discord Web Hook
$charfirst = $charinfo->{'firstname'}; $charlast = $charinfo->{'lastname'}; $charphone = $charinfo->{'phone'};
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = BANK_CHANGE_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "BANK AMOUNT CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "BANK ACCOUNT AMOUNTS CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed the character **$charfirst $charlast($citizenid)** bank account amounts",
            "url" => "$starturl/characterInfo?citizenid=$citizenid",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Cash Before / After",
                    "value" => "$$moneybeforeformatted / $$newCashFormatted",
                    "inline" => true
                ],
                [
                    "name" => "Bank Before / After",
                    "value" => "$$bankbeforeformatted / $$newBankFormatted",
                    "inline" => true
                ],
                [
                    "name" => "Savings Before / After",
                    "value" => "$savingsbeforeformatted / $$newSavingsFormatted",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>