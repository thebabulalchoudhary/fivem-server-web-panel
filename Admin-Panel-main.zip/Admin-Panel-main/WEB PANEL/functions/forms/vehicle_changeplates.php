<?php
include '../../config/config.php';
include '../main.php';

$vehicleid = htmlentities($_POST['vehicleid']);
$staff = $_SESSION['id'];

$realPlateUpdated = htmlentities($_POST['real_plate']);
$fakeplateUpdated = htmlentities($_POST['fake_plate']);

$oldplates = $pdo->query("SELECT plate,fakeplate FROM player_vehicles WHERE id ='$vehicleid'");
foreach($oldplates as $row){
  $oldplate = $row["plate"];
  $oldfakeplate = $row["fakeplate"];
}

$pdo->query("UPDATE player_vehicles SET plate = '$realPlateUpdated' WHERE id='$vehicleid'");
$pdo->query("UPDATE player_vehicles SET fakeplate = '$fakeplateUpdated' WHERE id='$vehicleid'");
$pdo->query("UPDATE trunkitems SET plate = '$realPlateUpdated' WHERE plate='$realplate'");
$pdo->query("UPDATE gloveboxitems SET plate = '$realPlateUpdated' WHERE plate='$realplate'");
/* YOU MAY NEED TO ADD MORE TABLES FOR WHERE THE VEHICLE IS */

$auditlogdata = array('oldplate' => $oldplate, 'newplate' => $realPlateUpdated);
$auditlogdata2 = array('oldfakeplate' => $oldfakeplate, 'newfakeplate' => $fakeplateUpdated);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data, data2) VALUES (?,?,?,?,?,?)');
$stmt2->execute([time(), "vehicle_change_plates", $staff, $vehicleid, json_encode($auditlogdata), json_encode($auditlogdata2)]);

// Send Discord Web Hook
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = VEHICLE_PLATE_CHANGE_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "LICENSE PLATE CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "VEHICLE LICENSE PLATES CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed license plates on the vehicle with plate: **$realplate**",
            "url" => "$starturl/vehicleInfo?id=$vehicleid",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Real License Plate Before / After",
                    "value" => "$oldplate / $realPlateUpdated",
                    "inline" => true
                ],
                [
                    "name" => "Fake License Plate Before / After",
                    "value" => "$oldfakeplate / $fakeplateUpdated",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>