<?php
include '../../config/config.php';
include '../main.php';

//////////////////////////////
// Form entites & variables //
//////////////////////////////
$punishedplayer = htmlentities($_POST['player_id']);
$punishedby = $_SESSION['id'];
$punishedreason = htmlentities($_POST['note_reason']);

$auditlogdata = array('punishedreason' => $punishedreason);

////////////////////////////////////
// Create database entry for note //
////////////////////////////////////
$stmt = $pdo->prepare('INSERT IGNORE INTO adminpanel_notes (punished_player, punished_by, punish_reason, punished_time) VALUES (?,?,?,?)');
$stmt->execute([$punishedplayer, $punishedby, $punishedreason, time()]);

$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "note", $punishedby, $punishedplayer, json_encode($auditlogdata)]);

///////////////////////////
// Send Discord Web Hook //
///////////////////////////
$staffusername = $_SESSION['name'];
$starturl = PANEL_URL;
$url = NOTE_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "NOTE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "NOTE CREATED",
            "type" => "rich",
            "description" => "**$staffusername** has created a note for **$playername**",
            "url" => "$starturl/playerInfo?playerId=$punishedplayer",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Note Reason",
                    "value" => "$punishedreason",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>