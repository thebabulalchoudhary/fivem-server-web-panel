<?php
include '../../config/config.php';
include '../main.php';

$citizenid = htmlentities($_POST['citizenid']);
$staffid = $_SESSION["id"];

$JsonQuery = $pdo->query("SELECT charinfo FROM players WHERE citizenid = '$citizenid'");
foreach($JsonQuery as $row){
    $charinfo = $row["charinfo"];
    $data = json_decode($charinfo, true);
    $data2 = json_decode($charinfo);
    $charfirst = $data2->{"firstname"}; 
    $charlast = $data2->{"lastname"};
}

$firstnameUpdated = htmlentities($_POST['first_name']);
$lastnameUpdated = htmlentities($_POST['last_name']);
$data['firstname'] = "$firstnameUpdated";
$data['lastname'] = "$lastnameUpdated";

$newJsonString = json_encode($data);

$pdo->query("UPDATE players SET charinfo = '$newJsonString' WHERE citizenid='$citizenid'");

$auditlogdata = array('firstname_before' => $charfirst, 'lastname_before' => $charlast);
$auditlogdata2 = array('firstname_after' => $firstnameUpdated, 'lastname_after' => $lastnameUpdated);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data, data2) VALUES (?,?,?,?,?,?)');
$stmt2->execute([time(), "change_name", $staffid, $citizenid, json_encode($auditlogdata), json_encode($auditlogdata2)]);


// Send Discord Web Hook
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = CHARACTER_NAME_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "CHARACTER NAME CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "CHARACTER NAME CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed the character **$citizenid** name",
            "url" => "$starturl/characterInfo?citizenid=$citizenid",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "First Name before / After",
                    "value" => "$charfirst / $firstnameUpdated",
                    "inline" => true
                ],
                [
                    "name" => "Last Name before / After",
                    "value" => "$charlast / $lastnameUpdated",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>