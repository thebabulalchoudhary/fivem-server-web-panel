<?php
include '../../config/config.php';
include '../main.php';


$citizenid = htmlentities($_POST['citizenid']);
$staffid = $_SESSION["id"];

$JsonQuery = $pdo->query("SELECT charinfo FROM players WHERE citizenid = '$citizenid'");
foreach($JsonQuery as $row){
    $CharInfo = $row["charinfo"];
    $data = json_decode($CharInfo, true);
    $data2 = json_decode($CharInfo);
    $charphone = $data2->{"phone"};
}

$phoneNumberUpdated = htmlentities($_POST['new_number']);
$data["phone"] = "$phoneNumberUpdated";
$newJsonString = json_encode($data);

$pdo->query("UPDATE players SET charinfo = '$newJsonString' WHERE citizenid='$citizenid'");

$auditlogdata = array('phone_before' => $charphone, 'phone_after' => $phoneNumberUpdated);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "change_number", $staffid, $citizenid, json_encode($auditlogdata)]);

// Send Discord Web Hook
$charfirst = $charinfo->{'firstname'}; $charlast = $charinfo->{'lastname'}; $charphone = $charinfo->{'phone'};
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = PHONE_NUMBER_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "PHONE NUMBER CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "PHONE NUMBER CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed the character **$charfirst $charlast($citizenid)** phone number",
            "url" => "$starturl/characterInfo?citizenid=$citizenid",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Old Phone Number",
                    "value" => "$charphone",
                    "inline" => true
                ],
                [
                    "name" => "New Phone Number",
                    "value" => "$phoneNumberUpdated",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>