<?php
include '../../config/config.php';
include '../main.php';
include '../classes/q3query.class.php';

//////////////////////////////
// Form entites & variables //
//////////////////////////////
$usersession = $_GET["playerId"];
$punishedby = $_SESSION['id'];
$punishedreason = htmlentities($_POST['kick_reason']);
$punishedplayername = htmlentities($_POST['player_name']);

$auditlogdata = array('punishedreason' => $punishedreason);

///////////////////////////////////////////////////////
// Kick player using RCon (Should already be online) //
///////////////////////////////////////////////////////
$server_ip = SERVER_IP; $server_port = SERVER_PORT;
$con = new q3query($server_ip, $server_port, $success);
if (!$success) {
    die ("Something has gone wrong.");
}
$con->setServerPort($server_ip);
$con->setRconpassword(SERVER_RCON_PASS);
$con->rcon("clientkick " . $OnlineServerID . " Kick reason: " . $punishedreason); 

////////////////////////////////////////
// Create database entry for the kick //
////////////////////////////////////////
$stmt = $pdo->prepare('INSERT IGNORE INTO adminpanel_kicks (kicked_player, punishedby, kickreason, kicktime) VALUES (?,?,?,?)');
$stmt->execute([$usersession , $punishedby, $punishedreason, time()]);

$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "kick", $punishedby, $usersession, json_encode($auditlogdata)]);

///////////////////////////
// Send Discord Web Hook //
///////////////////////////
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = KICK_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "KICK LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "PLAYER KICKED",
            "type" => "rich",
            "description" => "**$staffusername** has kicked **$punishedplayername** from the server",
            "url" => "$starturl/playerInfo?playerId=$usersession",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Kick Reason",
                    "value" => "$punishedreason",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>