<?php
include '../../config/config.php';
include '../main.php';

$myaccount = $_SESSION['id'];
if($_SESSION["name"] == "MasterAccount"){
    $username = $_POST['username'];
}
$pass = $_POST['password'];
$confirmpass = $_POST['confirm_password'];

if ($pass == $confirmpass) {
    $password = password_hash($pass, PASSWORD_DEFAULT);
    
    $stmt1 = $pdo->prepare('UPDATE adminpanel_staff SET password = ? WHERE id = ?');
    $stmt1->execute([ $password, $myaccount ]);

    if($_SESSION["name"] == "MasterAccount"){
        $stmt2 = $pdo->prepare('UPDATE adminpanel_staff SET username = ? WHERE id = ?');
        $stmt2->execute([ $username, $myaccount ]);
    }

    $pdo->query("UPDATE adminpanel_staff SET passwordchanges = passwordchanges + 1 WHERE id='$myaccount'");
    echo 'Success'; // We need this so do not touch
    } 
else {
    echo '<div class="alert alert-danger fade show" role="alert">Your passwords do not match. Please try and confirm your passwords again and ensure everything matches.</div>';
}
?>