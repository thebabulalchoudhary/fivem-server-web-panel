<?php
include '../../config/config.php';
include '../main.php';

$vehicleid = htmlentities($_POST['vehicleid']);
$staff = $_SESSION['id'];

$changedGarage = htmlentities($_POST['garagechange']);
$pdo->query("UPDATE player_vehicles SET garage = '$changedGarage' WHERE id='$vehicleid'");

$auditlogdata = array('newgarage' => $changedGarage);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "vehicle_change_garage", $staff, $vehicleid, json_encode($auditlogdata)]);

// Send Discord Web Hook
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = VEHICLE_GARAGE_CHANGE_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "VEHICLE GARAGE CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "VEHICLE GARAGE CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed the garage for the vehicle with plate: **$realplate**",
            "url" => "$starturl/vehicleInfo?id=$vehicleid",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Previous Location",
                    "value" => "$garage",
                    "inline" => true
                ],
                [
                    "name" => "Updated Location",
                    "value" => "$changedGarage",
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>