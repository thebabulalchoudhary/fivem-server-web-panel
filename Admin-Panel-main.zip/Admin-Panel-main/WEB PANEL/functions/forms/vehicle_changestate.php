<?php
include '../../config/config.php';
include '../main.php';

$vehicleid = htmlentities($_POST['vehicleid']);
$staff = $_SESSION['id'];

$changedState = htmlentities($_POST['statechange']);
$pdo->query("UPDATE player_vehicles SET state = '$changedState' WHERE id='$vehicleid'");

$auditlogdata = array('newstate' => $changedState);
$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "vehicle_change_state", $staff, $vehicleid, json_encode($auditlogdata)]);

// Send Discord Web Hook
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = VEHICLE_GARAGE_CHANGE_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "VEHICLE STATE CHANGE LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "VEHICLE STATE CHANGED",
            "type" => "rich",
            "description" => "**$staffusername** has changed the state of the vehicle with plate: **$realplate**",
            "url" => "$starturl/vehicleInfo?id=$vehicleid",
            "color" => hexdec( HEX_CODE ),
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>