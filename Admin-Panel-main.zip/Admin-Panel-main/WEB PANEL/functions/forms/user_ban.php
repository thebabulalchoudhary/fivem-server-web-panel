<?php
include '../../config/config.php';
include '../main.php';
include '../classes/q3query.class.php';

//////////////////////////////
// Form entites & variables //
//////////////////////////////
$punishedby = $_SESSION['id'];
$userid = htmlentities($_POST['player_id']);
$punishedrockstar = htmlentities($_POST['rockstar']);
$punishedreason = htmlentities($_POST['ban_reason']);
$banid = htmlentities($_POST['ban_id']);
$banlength = "0";
if ((htmlentities($_POST['ban_days']) == "0") && (htmlentities($_POST['ban_hours']) == "0")) {
    $banlength = "0";
    $banlengthformatted = "Permenant";
} else {
    $banDays = htmlspecialchars($_POST['ban_days']) * 86400;
    $banHours = htmlspecialchars($_POST['ban_hours'] * 3600);
    $banlength = time() + $banDays + $banHours;
    $banlengthformatted = gmdate("Y-m-d H:i:s", $banlength);
}

$auditlogdata = array('punishedplayer' => $punishedrockstar, 'punishedreason' => $punishedreason, 'banid' => $banid);

///////////////////////////////////////
// Create database entry for the ban //
///////////////////////////////////////
$stmt = $pdo->prepare('INSERT IGNORE INTO adminpanel_bans (banid, bannedby, userid, license, ban_issued, banned_until, reason) VALUES (?,?,?,?,?,?,?)');
$stmt->execute([$banid, $punishedby, $userid, $punishedrockstar, time(), $banlength, $punishedreason]);

$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "ban", $punishedby, $userid, json_encode($auditlogdata)]);

//////////////////////////////////////////////
// Trigger RCON kick event if player online //
//////////////////////////////////////////////
if ($playerOnline == "true"){
$server_ip = SERVER_IP; $server_port = SERVER_PORT;
$con = new q3query($server_ip, $server_port, $success);
if (!$success) {
    die ("Something has gone wrong.");
}
$con->setServerPort($server_ip);
$con->setRconpassword(SERVER_RCON_PASS);
$con->rcon("clientkick " . $OnlineServerID . " Ban reason: " . $punishedreason);
}

///////////////////////////
// Send Discord Web Hook //
///////////////////////////
$staffusername = $_SESSION['name'];
$starturl = PANEL_URL;
$url = BAN_LOGS;
$hookObject = json_encode([
    "content" => "",
    "username" => "BAN LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "BAN SUBMITTED",
            "type" => "rich",
            "description" => "**$staffusername** has submitted a ban for **$playername**",
            "url" => "$starturl/playerInfo?playerId=$userid",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Ban ID",
                    "value" => "$presetBANID",
                    "inline" => true
                ],
                [
                    "name" => "Ban Expires",
                    "value" => "$banlengthformatted",
                    "inline" => true
                ],
                [
                    "name" => "Punished Player",
                    "value" => "$playername (Player ID: $usersession)",
                    "inline" => true
                ],
                [
                    "name" => "Ban Reason",
                    "value" => "$punishedreason",
                    "inline" => true
                ],
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>