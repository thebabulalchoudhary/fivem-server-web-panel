<?php
include '../../config/config.php';
include '../main.php';

$user = $_SESSION['id']; $uploadOk = 1;
$profile_picture_file = "../../assets/images/avatars/" . basename($_FILES["fileToUpload"]["name"]);
$icon = $_SESSION['avatar'];

/////////////////////////////////////////////////////////
// Check if image file is a actual image or fake image //
/////////////////////////////////////////////////////////
$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
if($check !== false) {
    //echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
} else {
    echo '<div class="alert alert-danger fade show" role="alert">This file is not an image.</div>';
    $uploadOk = 0;
}

//////////////////////////////////
// Check if file already exists //
//////////////////////////////////
if (file_exists($profile_picture_file)) {
    echo '<div class="alert alert-danger fade show" role="alert">This file already exists, rename the file and try again!.</div>';
    $uploadOk = 0;
}

///////////////////////////////////////////////////
// File Formats (Incl. ALLOW_GIFS Config Option) //
///////////////////////////////////////////////////
$imageFileType = strtolower(pathinfo($profile_picture_file,PATHINFO_EXTENSION));

if(ALLOW_GIFS == "TRUE"){
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        echo '<div class="alert alert-danger fade show" role="alert">Only JPG, JPEG, PNG & GIF files are allowed for profile pictures.</div>';
        $uploadOk = 0;
    }
} else {
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        echo '<div class="alert alert-danger fade show" role="alert">Only JPG, JPEG & PNG files are allowed for profile pictures.</div>';
        $uploadOk = 0;
    }
}

/////////////////////
// Check file size //
/////////////////////
if ($_FILES["fileToUpload"]["size"] > 10000000) { // 10MB
    echo '<div class="alert alert-danger fade show" role="alert">The image you have tried uploading is bigger than 10MB.</div>';
    $uploadOk = 0;
}

//////////////////////////
// Code to Upload Image //
//////////////////////////
if ($uploadOk == 0) {
    // File will not upload
} else {
    if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $profile_picture_file)) {
        $icon = htmlspecialchars( basename( $_FILES["fileToUpload"]["name"]));
        $stmt = $pdo->prepare('UPDATE adminpanel_staff SET avatar = ? WHERE id = ?');
        $stmt->execute([ $icon, $user ]);
        echo "Success";
    }
}
?>