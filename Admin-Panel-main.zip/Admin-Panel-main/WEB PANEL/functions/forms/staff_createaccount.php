<?php
include '../../config/config.php';
include '../main.php';

$stmt = $pdo->prepare('INSERT IGNORE INTO adminpanel_staff (username,password,groupid,discord,rockstar) VALUES (?,?,?,?,?)');
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$stmt->execute([ $_POST['username'], $password, $_POST['group'], $_POST['discordid'], $_POST['rockstar']]);

$createdgrpid = $_POST['group'];
$result = $pdo->query("SELECT * FROM adminpanel_groups WHERE ID = '$createdgrpid'");
foreach($result as $row) {$groupName = $row["groupname"];}
// Send Discord Web Hook
$staffusername = $_SESSION['name']; $starturl = PANEL_URL; $url = ACCOUNT_CREATED_LOGS; $usercreated = $_POST['username']; $creatediscord = $_POST['discordid']; $createdrockstar = $_POST['rockstar'];
$hookObject = json_encode([
    "content" => "",
    "username" => "ACCOUNT CREATED LOGS",
    "avatar_url" => AVATAR_URL,
    "tts" => false,
    "embeds" => [
        [
            "title" => "STAFF ACCOUNT CREATED",
            "type" => "rich",
            "description" => "**$staffusername** has created a new staff account with the username **$usercreated**",
            "url" => "$starturl",
            "color" => hexdec( HEX_CODE ),
            "fields" => [
                [
                    "name" => "Account Discord ID",
                    "value" => "$creatediscord",
                    "inline" => true
                ],
                [
                    "name" => "Account Rockstar License",
                    "value" => "$createdrockstar",
                    "inline" => true
                ],
                [
                    "name" => "Account Group",
                    "value" => "$groupName",
                    "inline" => true
                ],
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init();
curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
$response = curl_exec( $ch );curl_close( $ch );

echo "Success";
?>