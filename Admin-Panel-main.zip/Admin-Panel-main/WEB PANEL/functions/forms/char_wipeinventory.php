<?php
include '../../config/config.php';
include '../main.php';

$citizenid = htmlentities($_POST['citizenid']);
$staffid = $_SESSION["id"];
$oldinventory = $pdo->query("SELECT inventory FROM players WHERE citizenid ='$citizenid'");
foreach($oldinventory as $row){
  $echoinventory = $row["inventory"];
}

$stmt1 = $pdo->prepare('UPDATE players SET inventory = ? WHERE citizenid = ?');
$stmt1->execute([ "[]", $citizenid ]);

$stmt2 = $pdo->prepare('INSERT IGNORE INTO adminpanel_auditlogs (time, type, staffid, target, data) VALUES (?,?,?,?,?)');
$stmt2->execute([time(), "inventory_wipe", $staffid, $citizenid, $echoinventory]);

echo "Success"; // Keep this
?>
