<?php
include '../config/config.php';
include 'main.php';

if (!isset($_POST['username'], $_POST['password'])) {
	exit('Please fill both the username and password field!');
}

$stmt = $pdo->prepare('SELECT * FROM adminpanel_staff WHERE username = ?');
$stmt->execute([ $_POST['username'] ]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);
if ($account) {
	if (password_verify($_POST['password'], $account['password'])) {
		if ($account['active'] == '1') {
			session_regenerate_id();
			$_SESSION['loggedin'] = TRUE;
			$_SESSION['name'] = $account['username'];
			$_SESSION['id'] = $account['id'];
			$_SESSION['group'] = $account['groupid'];
			$_SESSION['discord'] = $account['discord'];
			$_SESSION['rockstar'] = $account['rockstar'];
            $_SESSION['avatar'] = $account['avatar'];
            $_SESSION['passwordchanges'] = $account['passwordchanges'];
            
			$groupid2 = $account['groupid'];
			$groupnamequery = $pdo->query("SELECT * FROM adminpanel_groups WHERE id='$groupid2'");
			foreach($groupnamequery as $row){$groupname = $row["groupname"];}
			$_SESSION['groupname'] = $groupname; 

            $staffusername = $account['username'];
            $url = LOGIN_LOGS;
            $hookObject = json_encode([
                "content" => "",
                "username" => "LOGIN LOGS",
                "avatar_url" => AVATAR_URL,
                "tts" => false,
                "embeds" => [
                    [
                        "title" => "USER HAS LOGGED IN",
                        "type" => "rich",
                        "description" => "**$staffusername** has logged into the staff panel",
                        "url" => PANEL_URL,
                        "color" => hexdec( HEX_CODE ),
                    ]
                ]

            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            $ch = curl_init();
            curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
            $response = curl_exec( $ch );curl_close( $ch );

			if (isset($_POST['rememberme'])) {
				$cookiehash = !empty($account['rememberme']) ? $account['rememberme'] : password_hash($account['id'] . $account['username'] . 'yoursecretkey', PASSWORD_DEFAULT);
				$days = 30;
				setcookie('rememberme', $cookiehash, (int)(time()+60*60*24*$days));
				$stmt = $pdo->prepare('UPDATE adminpanel_staff SET rememberme = ? WHERE id = ?');
				$stmt->execute([ $cookiehash, $account['id'] ]);
			}

			echo 'Success';
        } else {
            echo '<div class="alert alert-danger fade show" role="alert">This account is no longer active and this login attempt has been logged. If you feel this is wrong, contact the owner.</div>';
            $staffusername = $account['username'];
            $url = LOGIN_LOGS;
            $hookObject = json_encode([
                "content" => "",
                "username" => "LOGIN LOGS",
                "avatar_url" => AVATAR_URL,
                "tts" => false,
                "embeds" => [
                    [
                        "title" => "UNATHORISED LOGIN ATTEMPT",
                        "type" => "rich",
                        "description" => "**$staffusername** has attempted to login to the staff panel but their account has been deactivated. If this is wrong, you can re-activate their account on the staff manager page.",
                        "url" => PANEL_URL,
                        "color" => hexdec( HEX_CODE ),
                    ]
                ]

            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            $ch = curl_init();
            curl_setopt_array( $ch, [CURLOPT_URL => $url,CURLOPT_POST => true,CURLOPT_POSTFIELDS => $hookObject,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);
            $response = curl_exec( $ch );curl_close( $ch );
            }
    } else {
        echo '<div class="alert alert-danger fade show" role="alert">Incorrect username and/or password.</div>';
    }
} else {
    echo '<div class="alert alert-danger fade show" role="alert">Incorrect username and/or password.</div>';
}
?>