<?php
include '../config/config.php';
include '../functions/main.php';
CheckUserLoggedIn($pdo); CheckFirstTimeLogin();

$propertyId = $_GET["propertyId"];
$result = $pdo->query("SELECT * FROM player_houses WHERE id = '$propertyId'");
foreach($result as $row) 
{
    $propertyId = $row["id"];
    $owner = $row["citizenid"];
    $housename = $row["house"];
}

$result2 = $pdo->query("SELECT * FROM houselocations WHERE id = '$propertyId'");
foreach($result2 as $row2) 
{
    $propertyLabel = $row2["label"];
    $propertyTier = $row2["tier"];
    $ownedStatus = $row2["price"];
    $ownedStatusFormatted = number_format($ownedStatus);
    $propertyOwned = $row2["owned"];
    $forSale;
    switch($propertyOwned)
    {
        case "1": // Because 1 = house is owned so is not for sale
            $forSale = "No";
            break;
        case "0": // Because 0 = house not owned so is for sale
            $forSale = "Yes";
            break;
    }
}

$charOwnerInfo = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$owner'");
foreach($charOwnerInfo as $row3){
    $charinfo = $row3["charinfo"];
    $charinfoDecoded = json_decode($charinfo);
    $firstname = $charinfoDecoded->{"firstname"};
    $lastname = $charinfoDecoded->{"lastname"};
}

$mygroup = $_SESSION["group"];
$PERMpropertytier = false;
$perm = $pdo->query("SELECT propertytier FROM adminpanel_groups WHERE id = '$mygroup'");
foreach($perm as $row){
    if ($row["propertytier"] == 1){
        $PERMpropertytier = true;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo SERVER_NAME;?> | Property Information</title>
    <meta name="description" content="<?php echo SERVER_DESCRIPTION;?>">
    <meta name="author" content="https://github.com/aidanohart">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="shortcut icon" href="../assets/images/logo-fav.png">
    <link href="../assets/main.css" rel="stylesheet">
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header fixed-footer">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        </div>
                            <ul class="header-menu nav">  
                        </ul>     
                </div>
                <!-- NAVIGATION BAR (PROFILE ON TOP LEFT)-->
                <?php include "../inserts/insert_profile.php"; ?>
            </div>
        </div>     

        <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    

            <!-- NAVIGATION BAR -->
            <?php include "../inserts/insert_navBar.php"; ?> 

            <div class="app-main__outer">
                <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-home icon-gradient qb-core">
                                </i>
                            </div>
                                <div>Property Information - <?php echo $propertyLabel; ?>
                                    <div class="page-title-subheading">This page displays information on a specific property.
                                </div>
                            </div>
                        </div>
                        <div class="page-title-actions">
                            <button type="button" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="mb-2 mr-2 dropdown-toggle btn btn-lg btn-outline-primary">
                                Manage <?php echo $propertyLabel; ?>
                            </button>
                            <div href="" tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(64px, 37px, 0px);">
                                <button href="" button data-toggle="modal" data-target="#changeTier"type="button" tabindex="0" class="dropdown-item">Change Property Tier</button>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
                if(NAV_BAR_STYLE == "OLD" ){
                ?>
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a role="tab" class="nav-link active" id="tab-1" data-toggle="tab" href="#tab-content-1">
                            <span>General Information</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a role="tab" class="nav-link" id="tab-2" data-toggle="tab" href="#tab-content-2">
                            <span>Property Inventory</span>
                        </a>
                    </li>
                </ul>
                <?php } else { ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a id="tab-1" data-toggle="tab" href="#tab-content-1" class="nav-link show active">General Information</a></li>
                    <li class="nav-item"><a id="tab-2" data-toggle="tab" href="#tab-content-2" class="nav-link show">Property Inventory</a></li>
                </ul>
                <?php } ?>

                <div class="tab-content">
                    <div class="tab-pane tabs-animation fade show active" id="tab-content-1" role="tabpanel">
                        <div class="col-lg-4 offset-md-4">
                            <div class="card text-center">
                                <div class="card-header">General Information (Out-Of-Character)</div>
                                    <div class="card-body">
                                    <p><b>Property ID: </b><?php echo $propertyId; ?> </p>
                                    <p><b>Property Label:</b> <?php echo $propertyLabel; ?></p>
                                    <p><b>Property Owned By:</b> <a href="<?php echo PANEL_URL; ?>/characters/info?citizenid=<?php echo $owner; ?>"><?php echo $firstname; ?> <?php echo $lastname; ?></a></p>
                                    <p><b>Property Tier: </b>Tier <?php echo $propertyTier; ?></p>
                                    <p><b>Property Value:</b> $<?php echo $ownedStatusFormatted; ?></p>
                                    <p><b>For Sale?</b> <?php echo $forSale; ?></p>
                                </div>
                            </div>
                        </div>

                        <br>

                        <div class="col-lg-4 offset-md-4">
                            <div class="card text-center">
                                <div class="card-header">All Keyholders</div>
                                    <div class="card-body">
                                    <table class="mb-0 table table-hover">
                                        <thead>
                                        <tr>
                                            <th>Character Name</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <?php
                                            $isowner = "";
                                            $i = 0;
                                            $apartment = $pdo->query("SELECT citizenid,keyholders FROM player_houses WHERE id='$propertyId'");
                                            foreach($apartment as $newrow){
                                                $ownercitizenid = $newrow["citizenid"];
                                                $json = $newrow["keyholders"];
                                                $keyholder = json_decode($json);
                                                foreach($keyholder as $newrow2){
                                                    $keyholdercid = $newrow2;
                                                    $i++;
                                                    $keyholdername = $pdo->query("SELECT charinfo FROM players WHERE citizenid='$keyholdercid'");
                                                    foreach($keyholdername as $newrow3){
                                                        $charinfo = $newrow3["charinfo"];
                                                        $charinfoDecoded = json_decode($charinfo);
                                                        $firstname = $charinfoDecoded->{"firstname"};
                                                        $lastname = $charinfoDecoded->{"lastname"};
                                                    }
                                                    if($keyholdercid == $owner){
                                                        $isowner = "";
                                                    } else {
                                                        $isowner = "Remove Keyholder";
                                                    }
                                                echo 
                                                '<tr id="'.$i.'">
                                                <td><a id="accentcolor" href="'.PANEL_URL.'/characters/info.php?citizenid=' . $keyholdercid . '">'. $firstname. ' '.$lastname.' ('.$keyholdercid.') '. '</td>
                                                </tr>';
                                            }}
                                            ?>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                        <div class ="d-flex justify-content-center overflow-auto inventory-scroll-bar inventory-container">
                            <div class="d-flex justify-content-start flex-wrap inventory">
                                <?php
                                $inventory = $pdo->query("SELECT stash,items FROM stashitems WHERE stash = '$housename'");

                                foreach($inventory as $row){
                                    $fetchInventory = $row["items"];
                                    $inventoryItems = json_decode($fetchInventory);
                                    for($i = 1; $i <= PROPERTY_INV_SLOTS; $i++){
                                        $exists = false;
                                        foreach($inventoryItems as $row2){
                                            $itemname = $row2->{'name'};
                                            $itemlabel = $row2->{'label'};
                                            $itemamount = $row2->{'amount'};
                                            $itemslot = $row2->{'slot'};
                                            if($i==$itemslot){
                                                $exists = true;
                                                echo'
                                                <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'">
                                                    <div class="d-flex inventory-icon flex-column align-items-between" style="background-image: url(../assets/images/inventory/'.$itemname.'.png)">
                                                        <div class="d-flex justify-content-between inventory-details">
                                                            <div class="d-flex justify-content inventory-slot">'.$i.'</div>
                                                            <div class="d-flex justify-content-end inventory-item-quantity">x'.$itemamount.'</div>
                                                        </div>
                                                        <div class="d-flex justify-content-center align-items-end inventory-item-name">'.$itemlabel.'</div>
                                                    </div>
                                                </div>';
                                                break;
                                            }
                                        }
                                        if($exists == false){
                                            echo'
                                            <div class="d-flex inventory-item-container" id="inventory-slot-'.$i.'"> 
                                                <div class="d-flex inventory-slot">'.$i.'</div>
                                            </div>';
                                        }
                                    }
                                } ?>
                            </div>
                        </div> 
                    </div>
                </div>
            <!-- FOOTER -->
            <?php include "../inserts/insert_footer.php"; ?> 
        </div>
    </div>
</div>

<script type="text/javascript" src="../assets/scripts/main.js"></script></body>
<script src="../assets/js/vendor.min.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/morris-js/morris.min.js"></script>
</html>

<!-------------------------->
<!-- Change Property Tier -->
<!-------------------------->
<div class="modal fade" id="changeTier" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Property Tier</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php 
                if($PERMpropertytier){
                ?>
                <div class="changetier">
                    <form class="" action="<?php echo PANEL_URL?>/functions/forms/property_changetier.php" method="post">
                        <div class="position-relative row form-group"><label class="col-sm-2 col-form-label">Property Tier</label>
                            <div class="col-sm-10"><input class="form-control" name="property_tier" required="text" type="number" value="<?php echo $propertyTier; ?>"></div>
                        </div>
                        <input type="hidden" name="propertyid" value="<?php echo $propertyId ?>">

                        <!-- SUBMIT BUTTON -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <div class="col-sm-10 offset-sm-2"><button type="submit" class="btn btn-primary">Update Property Tier</button></div>
                        </div>
                    </form>
                </div>
                <?php
                } else {
                ?>
                <p>You do not have permission to change property tiers.
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector(".changetier form").onsubmit = function(event) {
    event.preventDefault();
    var form_data = new FormData(document.querySelector(".changetier form"));
    var xhr = new XMLHttpRequest();
    xhr.open("POST", document.querySelector(".changetier form").action, true);
    xhr.onload = function () {
        if (this.responseText.toLowerCase().indexOf("success") !== -1) {
            window.location.href = "<?php echo PANEL_URL ?>/properties/info?propertyId=<?php echo $propertyId?>";
        } else {
            document.querySelector(".errormessage").innerHTML = this.responseText;
        }
    };
    xhr.send(form_data);
};
</script>