CREATE TABLE IF NOT EXISTS `adminpanel_bans` (
  `banid` varchar(50) NOT NULL,
  `active` int NOT NULL DEFAULT '1',
  `bannedby` int NOT NULL,
  `userid` int NOT NULL DEFAULT '0',
  `license` varchar(50) CHARACTER SET SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Unknown Identifier',
  `ban_issued` bigint NOT NULL DEFAULT '0',
  `banned_until` bigint NOT NULL DEFAULT '0',
  `reason` longtext CHARACTER SET SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`banid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS `adminpanel_auditlogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `time` int NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL DEFAULT '',
  `staffid` int NOT NULL DEFAULT '0',
  `target` varchar(50) NOT NULL DEFAULT '',
  `data` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `data2` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `data3` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `data4` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,

  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS `adminpanel_disconnections` (
  `serverid` int NOT NULL DEFAULT '0',
  `playername` varchar(50) NOT NULL DEFAULT '',
  `license` varchar(50) NOT NULL DEFAULT '',
  `reason` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS `adminpanel_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) NOT NULL DEFAULT '0',
  `phonenumber` int NOT NULL DEFAULT '0',
  `bankamounts` int NOT NULL DEFAULT '0',
  `licenseplates` int NOT NULL DEFAULT '0',
  `parkedgarage` int NOT NULL DEFAULT '0',
  `createnote` int NOT NULL DEFAULT '0',
  `submitkick` int NOT NULL DEFAULT '0',
  `submitban` int NOT NULL DEFAULT '0',
  `managenotes` int NOT NULL DEFAULT '0',
  `managekicks` int NOT NULL DEFAULT '0',
  `managebans` int NOT NULL DEFAULT '0',
  `staffmanager` int NOT NULL DEFAULT '0',
  `createstaffaccounts` int NOT NULL DEFAULT '0',
  `groupmanager` int NOT NULL DEFAULT '0',
  `createstaffgroups` int NOT NULL DEFAULT '0',
  `editcharname` int NOT NULL DEFAULT '0',
  `wipeinventory` int NOT NULL DEFAULT '0',
  `vehiclestate` int NOT NULL DEFAULT '0',
  `propertytier` int NOT NULL DEFAULT '0',
  `auditlog` int NOT NULL DEFAULT '0',

  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

INSERT INTO `adminpanel_groups` (`id`, `groupname`, `phonenumber`, `bankamounts`, `licenseplates`, `parkedgarage`, `createnote`, `submitkick`, `submitban`, `managenotes`, `managekicks`, `managebans`, `staffmanager`, `createstaffaccounts`, `groupmanager`, `createstaffgroups`, `editcharname`, `wipeinventory`, `vehiclestate`, `propertytier`, `auditlog`) VALUES
	(1,'Owner',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),(2,'Admin',0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,0,0),(3,'Moderator',0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

CREATE TABLE IF NOT EXISTS `adminpanel_kicks` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `kicked_player` int DEFAULT NULL,
  `punishedby` int DEFAULT NULL,
  `kickreason` longtext,
  `timestamp` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS `adminpanel_notes` (
  `noteid` int NOT NULL AUTO_INCREMENT,
  `punished_player` int DEFAULT NULL,
  `punished_by` int DEFAULT NULL,
  `punish_reason` longtext,
  `punished_time` int DEFAULT NULL,
  PRIMARY KEY (`noteid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS `adminpanel_players` (
  `id` int NOT NULL AUTO_INCREMENT,
  `license` varchar(55) DEFAULT NULL,
  `steam` varchar(55) DEFAULT NULL,
  `discord` varchar(55) DEFAULT NULL,
  `playername` varchar(55) DEFAULT NULL,
  `playtime` int DEFAULT '0',
  `firstjoin` int DEFAULT NULL,

  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `license` (`license`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS `adminpanel_staff` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `discord` varchar(50) DEFAULT NULL,
  `rockstar` varchar(50) DEFAULT NULL,
  `groupid` int DEFAULT '0',
  `avatar` varchar(50) NOT NULL DEFAULT 'default.png',
  `rememberme` varchar(255) NOT NULL DEFAULT '',
  `firstlogin` int DEFAULT '0',
  `active` int DEFAULT '1',
  `master_account` int DEFAULT '0',
  `passwordchanges` int DEFAULT '0',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;

INSERT INTO `adminpanel_staff` (`username`, `password`, `discord`, `rockstar`, `groupid`, `avatar`, `firstlogin`, `active`, `master_account`, `passwordchanges`) VALUES
	('MasterAccount', '$2y$10$elksYB7oPH/qSYbfVBeSdeIoO.MpRzsDXzRwZKnu15Ih7kYhjhfnq', 'discord:', 'license:', 1, 'default.png', 1, 1, 1, 0);